package wf.state_machine;

import org.jetbrains.annotations.Nullable;

import java.util.concurrent.CompletableFuture;

/**
 * @author Boaz Nahum
 */

class AsyncAction {

    /**
     * todo:boaz:fix: Use the better implemenattion in {@link SMState#betweenEntryExitDo(boolean, boolean, SMUTrigger, SMUTrigger, SMUTrigger, SMStateHandler)}
     *  @param actionContext from which this action was submitted
     * @param cancelByInterrupt
     * @param cancelingTrigger
     * @param successTrigger
     * @param failTrigger
     * @param action
     */
    static <C extends SMHandlerContext> CompletableFuture<Void> runAsync(
        boolean runAsync,
        C actionContext, boolean cancelByInterrupt, @Nullable SMUTrigger cancelingTrigger,
        @Nullable SMUTrigger successTrigger, @Nullable SMUTrigger failTrigger,
        @Nullable Runnable whatToDoCompletionStage, ConsumerThrow<? super C> action) {


        AsyncActionData data = new AsyncActionData();


        Runnable actionWrapper = () -> {

            // in case it was canceled before began async
            if (actionContext.isCanceled()) {
                return;
            }

            data.setRunningThread(Thread.currentThread());
            try {
                try {
                    action.accept(actionContext);
                } catch (RuntimeException e) {
                    throw e;
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            } finally {
                // make sure we won't cancel it after it moved to other task
                data.setRunningThread(null);
            }
        };


        CompletableFuture<Void> mainStage;

        if (runAsync) {
            mainStage = CompletableFuture.runAsync(actionWrapper);
            ((StateMachineImp) actionContext.globalC().sm()).traceAsyncAction(mainStage);
        } else {

            CompletableFuture<Object> dummy = new CompletableFuture<>();

            dummy.complete(null);

            // dummy won't fail, this will run sync
            mainStage = dummy.thenRun(actionWrapper);


        }

        // we use this future and not the completionFuture, because of the self refrence in the body of it
        // in this imp future in data is not used
        data.setFuture(mainStage);

        mainStage.whenComplete((r, e) -> {


            if (whatToDoCompletionStage != null) {
                whatToDoCompletionStage.run();
            }

            CompletableFuture<Void> future = data.getFuture();

            if ((future != null && future.isCancelled()) || actionContext.isCanceled()) {

                cancelThreadAndHandler(data, mainStage, actionContext, cancelByInterrupt);

                if (cancelingTrigger != null) {
                    actionContext.handleTrigger(cancelingTrigger);
                }

                return;
            }

            SMUTrigger t;
            if (e == null) {
                t = successTrigger;

            } else {
                if (failTrigger == null) {
                    t = successTrigger;
                } else {
                    t = failTrigger;
                }
            }

            if (t != null) {
                actionContext.handleTrigger(t);
            }
        });

        return mainStage;

    }

    private static <C extends SMHandlerContext> void cancelThreadAndHandler(AsyncActionData data,
                                                                            CompletableFuture<Void> mainStage,
                                                                            C eventContext,
                                                                            boolean cancelByInterrupt) {

        ((StateHandlerContextImpl)eventContext).setIsCanceled(true);

        mainStage.cancel(false);

        if (cancelByInterrupt) {
            // potential bug here
            //  1. It can be nullified after checking and belong to other thread
            //  2. It might that it is not even started - this will be handled by canceled
            Thread rt = data.getRunningThread();
            if (rt != null) {
                rt.interrupt();
            }
        }
    }

}


