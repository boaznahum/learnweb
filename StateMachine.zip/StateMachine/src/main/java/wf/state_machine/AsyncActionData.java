package wf.state_machine;

import org.jetbrains.annotations.Nullable;

import java.util.concurrent.CompletableFuture;

/**
 * @author Boaz Nahum
 */ // we must not store any transient data,
// this handler may be executed mote than once
// and maybe one from previous running is still running
class AsyncActionData {

    /**
     * Once become non null it won't be nullify
     */
    private volatile CompletableFuture<Void> future;

    @Nullable
    private volatile Thread runningThread;

    //private volatile boolean reachCompletionStage;

    AsyncActionData() {
    }

    @Nullable
    public CompletableFuture<Void> getFuture() {
        return future;
    }

    public void setFuture(CompletableFuture<Void> future) {
        this.future = future;
    }

    @Nullable
    public Thread getRunningThread() {
        return runningThread;
    }

    public void setRunningThread(@Nullable Thread runningThread) {
        this.runningThread = runningThread;
    }

    //public void setReachCompletionStage() {
    //
    //    reachCompletionStage = true;
    //}
}
