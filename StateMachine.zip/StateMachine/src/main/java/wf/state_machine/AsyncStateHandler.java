package wf.state_machine;

import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.concurrent.Future;

/**
 * See {@link SMState#betweenEntryExitDo(boolean, boolean, SMUTrigger, SMUTrigger, SMUTrigger, SMStateHandler)}
 *
 * @author Boaz Nahum
 */

class AsyncStateHandler implements SMStateHandler {

    private final boolean async;
    private final boolean cancelByInterrupt;

    @Nullable
    private final SMUTrigger successTrigger;
    @Nullable
    private final SMUTrigger failureTrigger;

    @Nullable
    private SMUTrigger cancelingTrigger;


    private final SMStateHandler delegatee;


    /**
     * // We trace all handlers that started by this handler
     * // because we have no other way to associate start handler with its exit handler
     */
    private final HashMap<SMStateHandlerContext, Future<Void>> submittedActions = new HashMap<>();


    AsyncStateHandler(boolean async,
                      boolean cancelByInterrupt,
                      @Nullable SMUTrigger successTrigger,
                      @Nullable SMUTrigger failureTrigger,
                      @Nullable SMUTrigger cancelingTrigger,
                      SMStateHandler delegatee) {


        this.async = async;
        this.cancelByInterrupt = cancelByInterrupt;
        this.successTrigger = successTrigger;
        this.failureTrigger = failureTrigger;
        this.delegatee = delegatee;
    }

    @Override
    public void handle(SMStateHandlerContext i) throws Exception {


        Future<Void> future =
            AsyncAction.runAsync(
                async,
                i, cancelByInterrupt, cancelingTrigger, successTrigger, failureTrigger, () -> {
                    synchronized (submittedActions) {
                        // from this point it won't be canceled by exit handler
                        submittedActions.remove(i);
                    }
                }, delegatee::handle
            );

        if (async) {
            synchronized (submittedActions) {
                submittedActions.put(i, future);
            }
        }
    }

    void cancel() {

        ArrayList<Entry<SMStateHandlerContext, Future<Void>>> entries;
        synchronized (submittedActions) {


            // Why we are copying ????
            //  future.cancel() may call the completionFuture above with canceled exception
            // and the later remove from map, so we get concurrent modification exception

            entries = new ArrayList<>(submittedActions.entrySet());
            submittedActions.clear();
        }

        entries.forEach(e -> {
            Future<Void> future = e.getValue();
            // will do nothing if already completed
            future.cancel(false);
        });

    }
}


