package wf.state_machine;

/**
 * A global handler info without specific event info/context
 * @author Boaz Nahum
 */

class BaseHandlerContextImpl implements SMBaseHandlerContext {

    private final SMGlobalContext globalContext;

    BaseHandlerContextImpl(SMGlobalContext globalContext) {
        this.globalContext = globalContext;
    }


    @Override
    public SMGlobalContext getGlobalContext() {
        return globalContext;

    }

}
