package wf.state_machine;

import wf.state_machine.smlogger.SMLogEvent;
import wf.state_machine.smlogger.SMAuditor;

@SuppressWarnings({"ClassReferencesSubclass"})
class BaseStateMachineElement {

    private final StateMachineImp stateMachine;

    BaseStateMachineElement(StateMachineImp stateMachine) {
        this.stateMachine = stateMachine;
    }

    BaseStateMachineElement(BaseStateMachineElement element) {
        this(element.stateMachine);
    }

    final StateMachineImp getWorld() {
        return stateMachine;
    }

    final SMGlobalContext getGlobalContext() {
        return getWorld().getContext();
    }

    final StateMachineImp sm() {
        return stateMachine;
    }

    final boolean isLoggerOn() {
        return getWorld().isLoggerOn();
    }

    final SMAuditor getLogger() {
        return getWorld().getLogger();
    }

    final void logEvent(SMLogEvent logEvent,
                        SMStateVertex source,
                        SMBaseTrigger trigger,
                        SMStateVertex target) {

        // the imp here is due to optimization

        StateMachineImp sm = getWorld();
        SMAuditor logger = sm.getLogger();
        if (logger != null) {
            logger.logEvent(sm, logEvent, source, trigger, target);
        }


        // instead of
        //getWorld().logEvent(logEvent,
        //                    source,
        //                    trigger,
        //                    target);


    }

    final void logEvent(SMLogEvent logEvent,
                        SMStateVertex source,
                        TriggerPacking triggerPacking,
                        SMStateVertex target) {

        if (triggerPacking == null) {
            logEvent(logEvent, source, (SMBaseTrigger)null, target);
            return;
        }

        // the imp here is due to optimization

        StateMachineImp sm = getWorld();
        SMAuditor logger = sm.getLogger();
        if (logger != null) {
            logger.logEvent(sm, logEvent, source, triggerPacking.getTrigger(), target);
        }


        // instead of
        //getWorld().logEvent(logEvent,
        //                    source,
        //                    trigger,
        //                    target);


    }
}