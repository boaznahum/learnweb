package wf.state_machine;

/**
 * Transition with N = 2 branches
 *
 * @author Boaz Nahum
 * @version WI VX.6, V12.0X, ADC V0.95
 */

class BinaryTransition extends PermanentTransition {

    private final TransitionBranch branch0;

    private final TransitionBranch branch1;


    BinaryTransition(StateMachineImp world,
                     SMStateVertexImp target0,
                     SMStateVertexImp target1,
                     SMGuard guard) {

        super(world, guard);


        // in case of nary transition (nTargets>1) you must specify guard
        if (guard == null) {
            throw new SMDefinitionException("In case of more than one target, you must supply a guard");
        }

        branch0 = createAndSetTarget(target0);
        branch1 = createAndSetTarget(target1);

    }

    @Override
    protected TransitionBranch getTransitionBranchNoCheck(int i) {
        if (i == 0) {
            return branch0;
        } else {
            return branch1;
        }
    }

    @Override
    int getN() {
        return 2;
    }
}
