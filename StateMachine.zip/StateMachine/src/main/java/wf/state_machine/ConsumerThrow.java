package wf.state_machine;

/**
 * @author Boaz Nahum
 */

interface ConsumerThrow<T> {

    void accept(T t) throws Exception;
}
