package wf.state_machine;

/**
 * See http://www.graphviz.org/doc/info/attrs.html#a:penwidth
 * for default values and more
 * @author Boaz Nahum
 */

interface DOTAttributesX {

    /**
     * Default is 1.o http://www.graphviz.org/doc/info/attrs.html#a:penwidth
     */
    String SIMPLE_STATE_ACTIVE_LINE_PEN_WIDTH = "2.0";
    String SIMPLE_STATE_ACTIVE_LINE_COLOR = "red";
    String COMPLEX_STATE_ACTIVE_LINE_COLOR = "red";

    /**
     * http://www.graphviz.org/doc/info/attrs.html#k:style
     */
    String REGION_STATE_LINE_STYLE = "dashed";
}
