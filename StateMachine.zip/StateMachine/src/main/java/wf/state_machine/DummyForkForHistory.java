package wf.state_machine;

import wf.state_machine.outputers.dot.DotContext;

class DummyForkForHistory extends Fork {

    DummyForkForHistory(SMConcurrentStateImp parent) {
        super(parent, "$DummyForDeepHistory$");
    }


    @Override
    protected String getDotNoneComplexModeAttributes(DotContext dotContext) {
        //noinspection SpellCheckingInspection
        return "shape=point, style=invis, label=\"\"";
    }
}
