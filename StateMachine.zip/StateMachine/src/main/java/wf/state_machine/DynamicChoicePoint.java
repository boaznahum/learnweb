package wf.state_machine;

import wf.state_machine.outputers.dot.DotContext;

import java.util.LinkedList;
import java.util.List;

/**
 * Dynamic choice point always have path through
 */
final class DynamicChoicePoint extends SMChoicePoint {


    DynamicChoicePoint(SMCompositeStateImp parent,
                       String sid) {
        super(parent, sid);
    }


    @Override
    final String getTypeName() {
        return "Dynamic Choice Point";
    }

    @Override
    SMTransition addOutgoingTransition(SMBaseTrigger trigger, SMTransitionImp t) {
        checkHaveDefaultBranch(t);

        return super.addOutgoingTransition(trigger, t);
    }

    @Override
    LinkedList<SMTransitionSegmentImp> findPathThrough(LinkedList<SMTransitionSegmentImp> pathSoFar,
                                                    SMStateImp beginOfPath,
                                                    SMStateVertex source,
                                                    TriggerPacking triggerPacking) {
        // stop here. Because I'm dynamic choice point
        // when you reach me then you will exit to the selected target
        return pathSoFar;
    }

    @Override
    boolean possiblyImpassable() {
        return false;
    }

    @Override
    protected void checkValid() {
        super.checkValid();

        // dynamic choice point must have outgoing transition
        checkHaveGuaranteedOutgoingTransition(transitions);

    }


    /**
     * @param beginOfPath
     * @param innerTargetState
     * @param statesPath
     * @param sourceState for debug
     * @param triggerPacking
     */
    @Override
    LinkedList<SMStateVertexImp> enterBegin(SMStateImp beginOfPath,
                                            SMStateVertexImp innerTargetState,
                                            LinkedList<SMStateVertexImp> statesPath,
                                            SMStateVertexImp sourceState,
                                            TriggerPacking triggerPacking) {

        statesPath = super.enterBegin(beginOfPath,
                innerTargetState,
                statesPath,
                sourceState,
                triggerPacking);

        getWorld().addInternalSystemTrigger(SystemTrigger.DYNAMIC_CHOICE_EXIT,
                this,
                new HelpExitData(triggerPacking, beginOfPath),
                true);

        return statesPath;
    }

    @Override
    List<SMTransitionSegmentImp> processTrigger(TriggerPacking triggerPacking,
                                           SMStateVertex target,
                                           SMInternalTriggerData internalData,
                                           boolean myEvent) {

        if (!imTargetAndMySystemTrigger(triggerPacking, target, SystemTrigger.DYNAMIC_CHOICE_EXIT)) {
            return null;
        }

        // assume super does nothing with trigger,
        //  if yes we should call it with 'and' trigger too
        super.processTrigger(triggerPacking, target, internalData, myEvent);

        HelpExitData fed = (HelpExitData)internalData;
        TriggerPacking realTrigger = fed.getStepTrigger();
        SMStateImp beginOfPath = fed.getBeginOfPath();

        return transitions.findPathThrough(beginOfPath,
                this,
                realTrigger);

    }


    @Override
    public String getElementName() {
        return "DynamicChoice";
    }

    @Override
    protected String getDotNoneComplexModeAttributes(DotContext dotContext) {

        String a1 = super.getDotNoneComplexModeAttributes(dotContext);

        String a2 = "style=filled";

        return DotContext.concatenateAttributes(a1, a2);


    }

}

