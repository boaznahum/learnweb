package wf.state_machine;

// for debug only

import org.w3c.dom.Element;
import wf.state_machine.outputers.DOMHelper;
import wf.state_machine.outputers.XMLAttributeAndValue;
import wf.state_machine.outputers.XMLContext;
import wf.state_machine.outputers.XMLWriteable;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * A map between {@link SMBaseTrigger} to {@link Transitions}
 */
final class Event2TransitionsMap extends LinkedHashMap<SMBaseTrigger, Transitions> implements XMLWriteable {

    void add(SMBaseTrigger trigger, SMTransitionImp t) {

        Transitions ts = super.get(trigger);

        if (ts == null) {
            ts = new Transitions(t.getWorld());
            super.put(trigger, ts);
        }

        ts.add(t);
    }

    Transitions find(SMBaseTrigger trigger) {
        return super.get(trigger);
    }

    /**
     * SM init {@link StateMachineElementImp}
     *
     * Note:
     * There is already method with the same name in {@link java.util.LinkedHashMap} which is not relevant
     */
    void smInit() {

        for (Transitions transitions : values()) {
            transitions.init();
        }
    }

    // ================ DOM support ===============================


    private XMLWriteable getEventTransitionAsXML(final SMBaseTrigger trigger, final Transitions transitions) {

        return new XMLWriteable() {
            @Override
            public String getElementName() {
                return "trigger";
            }

            @Override
            public XMLAttributeAndValue[] getAttributes() {

                if (trigger == null) {
                    return null;
                } else {
                    return new XMLAttributeAndValue[]{
                        new XMLAttributeAndValue("name", trigger.getName())
                    };
                }
            }

            @Override
            public void writeBody(XMLContext xmlContext, Element inNode) {
                DOMHelper.addAndWrite(xmlContext, transitions, inNode);
            }

        };

    }

    @Override
    public String getElementName() {
        return "events_transitions";
    }

    @Override
    public XMLAttributeAndValue[] getAttributes() {
        return null;
    }

    @Override
    public void writeBody(XMLContext xmlContext, Element inNode) {

        for (Map.Entry<SMBaseTrigger, Transitions> e : super.entrySet()) {
                SMBaseTrigger trigger = e.getKey();
                Transitions ts = e.getValue();

                XMLWriteable asWriteable = getEventTransitionAsXML(trigger, ts);

                DOMHelper.addAndWrite(xmlContext, asWriteable, inNode);
        }

    }

    void writeDotData(XMLContext xmlContext, Element inNode,
                      SMStateVertexImp source) {

        for (Map.Entry<SMBaseTrigger, Transitions> e : super.entrySet()) {
                SMBaseTrigger trigger = e.getKey();
                Transitions ts = e.getValue();

            ts.writeDotData(xmlContext, inNode, source, trigger);

        }
    }


}