package wf.state_machine;

/**
 * @author Boaz Nahum
 */

class EventContextImpl extends BaseHandlerContextImpl implements SMEventContext {


    private final TriggerPacking triggerPacking;

    EventContextImpl(SMGlobalContext globalContext, TriggerPacking triggerPacking) {
        super(globalContext);
        this.triggerPacking = triggerPacking;
    }

    @Override
    public SMBaseTrigger getTrigger() {
        return triggerPacking.getTrigger();
    }

    /**
     * Get the user data that was passed along with {@link #getTrigger()}
     * when calling {@link StateMachine#handleTrigger(SMUTrigger, Object)}
     * or {@link StateMachine#submitTrigger(SMTrigger, Object)}
     */
    @Override
    public Object getTriggerData() {
        return triggerPacking.getUserData();

    }

    TriggerPacking getTriggerPacking() {
        return triggerPacking;
    }
}
