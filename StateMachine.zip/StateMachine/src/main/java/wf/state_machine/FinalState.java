package wf.state_machine;

import wf.state_machine.outputers.dot.DotContext;


final class FinalState extends SMStateImp {

    FinalState(SMCompositeStateImp parent, String sid) {
        super(parent.getWorld(), parent, sid);
    }

    @Override
    final String getTypeName() {
        return "Final";
    }

    //@Override
    //public final boolean isFinalState() {
    //    return true;
    //}

    @Override
    boolean isInFinalState() {
        return true;
    }

    @Override
    SMStateVertexImp getDeepHistory() {
        return null;
    }

    @Override
    void checkIncomingTransitionIsValid(SMStateVertexImp source) {
        super.checkIncomingTransitionIsValid(source);

        if (!isBrotherOrBrotherDescendant(source)) {
            throw new SMDefinitionException("In state '" +
                                            this + "', invalid incoming transition from '" +
                                            source + "'");
        }
    }

    // ============================================
    // DOM Support
    @Override
    public String getElementName() {
        return "FinalState";
    }

    // ============================================


    @Override
    public String getDotLabel() {
        return ""; // we draw label above circle
    }

    // DOT Support
    @Override
    protected String getDotNoneComplexModeAttributes(DotContext dotContext) {

        String s1 = super.getDotNoneComplexModeAttributes(dotContext);

        String label = DotContext.quoteLabel(getDefaultDotLabel());

        String l = "toplabel=" + label;

        String s2;

        //noinspection ConstantIfStatement,ConstantConditions
        if (false) {
            String customImagePath = dotContext.getCustomImagePath("final.png");
            s2 = "shape=none, image=\"" + customImagePath + "\", " +
                 "width=0.1, height=0.1";
        } else {

            String fillColor;
            if (isActive()) {
                fillColor = "red";
            } else {
                fillColor = "black";
            }

            //noinspection SpellCheckingInspection
            s2 = "shape=circle, " +
                 "peripheries=2," +
                 "style=filled, fillcolor=" + fillColor + ",width=0.1, height=0.1";
        }

        return DotContext.concatenateAttributes(s1, s2, l);
    }


}
