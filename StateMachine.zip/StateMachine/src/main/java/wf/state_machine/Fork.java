package wf.state_machine;

import org.w3c.dom.Element;
import wf.state_machine.outputers.XMLContext;
import wf.state_machine.outputers.dot.DotContext;
import wf.state_machine.outputers.dot.DotHelper;

import java.util.LinkedList;
import java.util.List;
import java.util.Map.Entry;
import java.util.TreeMap;

class Fork extends PseudoState {

    static final String DEFAULT_NAME = "F*";


    // a map between an region to it's inner target transition
    private TreeMap<SMStateVertex, SMTransitionImp> mRegionToStateMap;

    Fork(SMConcurrentStateImp parent, String sid) {
        super(parent, sid);

    }

    @Override
    final String getTypeName() {
        return "Fork";
    }


    @Override
    SMTransition addOutgoingTransition(SMBaseTrigger trigger, SMTransitionImp t) {
        super.addOutgoingTransition(trigger, t);

        checkItIsUnary(t);

        setTarget(t);

        return t;
    }

    @Override
    void setIncomingTransition(SMStateVertexImp source) {
        SMConcurrentStateImp parent = (SMConcurrentStateImp)getParentState();

        SMStateVertex brother = parent.findSubStateContainsOrEqInternal(source, true);

        if (brother != null) {
            throw new SMDefinitionException("In " + getTypeAndName() +
                                            ", incoming transition - " +
                                            source.getTypeAndName() +
                                            " - must come from outside concurrent state: " + parent);
        }

    }


    private void setTarget(SMTransitionImp t) {
        SMStateVertex target = t.getBranchTarget(0);

        SMConcurrentStateImp parent = (SMConcurrentStateImp)getParentState();


        SMStateVertexImp region = parent.findSubStateContainsOrEqInternal(target);

        if (region == null || !region.isRegion()) {
            throw new SMDefinitionException("In fork '" + this + "', " +
                                            "Target '" + target +
                                            "' is not region nor is region in concurrent state '" + parent + "'");
        }


        if (mRegionToStateMap == null) {
            mRegionToStateMap = new TreeMap<>();
        }

        SMTransition already = mRegionToStateMap.put(region, t);

        if (already != null) {
            throw new SMDefinitionException("In fork '" + this + "', " +
                                            "Region '" + region + "' already has a target '" + already);
        }
    }

    // this is need by SMConcurrentState.getDeepHistory

    void clear() {
        if (mRegionToStateMap != null) {
            mRegionToStateMap.clear();
        }
    }

    // this is need by SMConcurrentState.getDeepHistory

    boolean isEmpty() {
        return mRegionToStateMap == null || mRegionToStateMap.isEmpty();
    }

    @Override
    protected void init() {
        super.init();

        /**
         * todo: init {@link #mRegionToStateMap}
         */

    }


    @Override
    protected void checkValid() {
        super.checkValid();

        // fork with no outgoing transition is ok,
        //  is like fork in which all targets end on region edge

        // we can't do it in setTarget
        // because maybe target is not yet configured

        if (mRegionToStateMap != null) {

            for (Entry<SMStateVertex, SMTransitionImp> e : mRegionToStateMap.entrySet()) {

                SMComplexStateImp region = (SMComplexStateImp)e.getKey();
                SMTransitionImp t = e.getValue();

                // t must be unary transition !!!
                SMStateVertexImp target = t.getBranchTarget(0);

                //noinspection ObjectEquality
                if (target != region) {
                    List<SMStateVertex> l = target.isAllPathTroughIsInContainer(region,
                                                                                false);

                    if (l != null) {
                        l.add(0, this);

                        throw new SMDefinitionException("In fork '" + this + "', " +
                                                        "there is a possibility of a path ending outside or on region: " +
                                                        pathToString(l));

                    }
                }
            }
        }
    }


    @Override
    public final boolean isFork() {
        return true;
    }


    @Override
    List<SMTransitionSegmentImp> processTrigger(TriggerPacking triggerPacking,
                                             SMStateVertex target,
                                             SMInternalTriggerData internalData,
                                             boolean myEvent) {
        if (!imTargetAndMySystemTrigger(triggerPacking, target, SystemTrigger.FORK_EXIT)) {
            return null;
        }

        // assume super does nothing with trigger,
        //  if yes we should call it with 'and' trigger too
        super.processTrigger(triggerPacking, target, internalData, myEvent);

        List<SMTransitionSegmentImp> path = null;
        // now add segment for all regions
        SMConcurrentStateImp parent = (SMConcurrentStateImp)getParentState();

        HelpExitData fed = (HelpExitData)internalData;
        TriggerPacking realTrigger = fed.getStepTrigger();
        SMStateImp beginOfPath = fed.getBeginOfPath();

        for (SMStateImp region : parent.getSubStatesMap().values()) {

            //SMStateVertex region = state;

            SMTransitionImp regionTransition =
                mRegionToStateMap == null ? null : mRegionToStateMap.get(region);

            LinkedList<SMTransitionSegmentImp> tempPath = null;

            if (regionTransition != null) {
                tempPath = regionTransition.findPathThrough(tempPath,
                                                            beginOfPath,
                                                            this,
                                                            realTrigger);

            }

            // if no path was found(may static choice point with no default branch),
            //  or there was no transition from fork
            //  into region then go to edge of region
            if (tempPath == null) {
                tempPath = new LinkedList<>();

                // because we don't have a real transition,
                // we create a dummy one
                SMTransitionSegmentImp thisSegment =
                    SMTransitionSegmentImp.createSimple(beginOfPath,
                                                     this,
                                                     realTrigger,
                                                     region);

                tempPath.addLast(thisSegment);

                LinkedList<SMTransitionSegmentImp> tempPath2 =
                    region.findPathThrough(tempPath, beginOfPath, this, realTrigger);

                if (tempPath2 == null) {
                    throw new SMDefinitionException("there is must some way to enter region");
                }

                tempPath = tempPath2;
            }

            // now merge it
            path = SMTransitionSegmentImp.add(path, tempPath);
        }

        return path;
    }



    @Override
    LinkedList<SMStateVertexImp> enterBegin(SMStateImp beginOfPath,
                                            SMStateVertexImp innerTargetState,
                                            LinkedList<SMStateVertexImp> statesPath,
                                            SMStateVertexImp sourceState, // for debug
                                            TriggerPacking triggerPacking) {
        
        statesPath = super.enterBegin(beginOfPath,
                                      innerTargetState,
                                      statesPath,
                                      sourceState,
                                      triggerPacking);

        getWorld().addInternalSystemTrigger(SystemTrigger.FORK_EXIT,
                                            this,
                                            new HelpExitData(triggerPacking, beginOfPath),
                                            true);

        return statesPath;
    }


    @Override
    LinkedList<SMTransitionSegmentImp> findPathThrough(LinkedList<SMTransitionSegmentImp> pathSoFar,
                                                    SMStateImp beginOfPath,
                                                    SMStateVertex source,
                                                    TriggerPacking triggerPacking) {
        return pathSoFar; // you will exit when you reach me
    }

    @Override
    boolean possiblyImpassable() {
        return false;
    }

    // ================ DOM support ===============================

    @Override
    public void writeBody(XMLContext xmlContext, Element myNode) {

        if (mRegionToStateMap != null && !mRegionToStateMap.isEmpty()) {


            for (Entry<SMStateVertex, SMTransitionImp> e : mRegionToStateMap.entrySet()) {
                SMTransitionImp transition = e.getValue();

                writeUnNamedTransition(xmlContext, myNode, transition);
                //transition.writeTo(xmlContext, myNode);
            }
        }

        super.writeBody(xmlContext,
                        myNode);    //To change body of overridden methods use File | Settings | File Templates.

    }


    @Override
    public String getElementName() {
        return "Fork";
    }

    /**
     * DoingX_Fx[label="Fork|<1>1|<2>2" shape=record,width=.0];
     */
    @Override
    public String getDotLabel() {
        String label = super.getDotLabel();

        if (label.equals(DEFAULT_NAME)) {
            label = null;
        }

        SMConcurrentState parent = (SMConcurrentState)getParentState();

        return DotHelper.buildRecordLabelForConcurrent(label, parent);
    }


    /**
     * DoingX_Fx[label="Fork|<1>1|<2>2" shape=record,width=.0];
     *
     * @param dotContext
     */
    @Override
    protected String getDotNoneComplexModeAttributes(DotContext dotContext) {
        String s1 = super.getDotNoneComplexModeAttributes(dotContext);
        String s2 = "shape=record, width=.0";

        return DotContext.concatenateAttributes(s1, s2);
    }

    /**
     * The syntax from record is
     * node0:f0 -> node1:n;
     * where f0 and n are the ids we put in <>
     */
    @Override
    public String getDotNameAsSourceOfTransition(SMStateVertex target) {
        String name = super.getDotNameAsSourceOfTransition(target);

        return DotHelper.getRecordSubLabel(name, (SMConcurrentState)getParentState(), target);
    }


}
