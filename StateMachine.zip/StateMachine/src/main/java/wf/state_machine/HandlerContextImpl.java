package wf.state_machine;

import org.jetbrains.annotations.Nullable;

import java.util.concurrent.Future;

/**
 * @author Boaz Nahum
 */

class HandlerContextImpl extends EventContextImpl implements SMHandlerContext {


    private boolean canceled;


    HandlerContextImpl(SMGlobalContext globalContext, TriggerPacking triggerPacking) {
        super(globalContext, triggerPacking);
    }


    @Override
    public boolean isCanceled() {
        return canceled;
    }

    @Override
    public void runSync(SMEventContext context, @Nullable SMUTrigger successTrigger,
                        @Nullable SMUTrigger failureTrigger, SMSimpleHandler action) {


        globalC().runSync(context,
                          successTrigger, failureTrigger, action);


    }

    @Override
    public Future<Void> runAsync(SMEventContext context, boolean cancelByInterrupt, @Nullable SMUTrigger successTrigger,
                                 @Nullable SMUTrigger failureTrigger, SMUTrigger cancelingTrigger,
                                 SMSimpleHandler action) {
        return globalC().runAsync(
            context,
            cancelByInterrupt,
            successTrigger, failureTrigger, cancelingTrigger,
            action);

    }

    /**
     * We put it in hash table, see {@link AsyncStateHandler}
     */
    @Override
    public final int hashCode() {
        return super.hashCode();

    }

    void setIsCanceled(boolean canceled) {
        this.canceled = canceled;
    }

    /**
     * We put it in hash table, see {@link AsyncStateHandler}
     */
    @Override
    public final boolean equals(Object obj) {
        return super.equals(obj);

    }


}
