package wf.state_machine;

import java.util.LinkedList;
import java.util.ListIterator;
import java.util.function.Supplier;


/**
 * a list of Handler
 */
class HandlerList<H extends SMHandler, I extends SMHandlerContext> {

    /**
     * will stay null until first add
     */
    private LinkedList<H> mList;

    private LinkedList<H> ensure() {
        if (mList == null) {
            mList = new LinkedList<>();
        }
        return mList;
    }

    final void addLast(H h) {
        ensure().addLast(h);
    }

    void remove(SMHandler handler) {
        if (mList == null || mList.isEmpty()) {
            return;
        }

        ListIterator<H> i = mList.listIterator();

        while (i.hasNext()) {
            SMHandler h = i.next();

            //noinspection ObjectEquality
            if (h == handler) {
                i.remove();
                return;
            }
        }
    }


    final boolean isEmpty() {
        return (mList == null) || mList.isEmpty();
    }

    final void execute(StateMachineImp world,
                       Supplier<I> dSupplier,
                       SMHandlerExecutor<H,I> executor) {

        if (isEmpty()) {
            return;
        }

        world.ensureValidThreadInStepCall();

        SMGlobalContext eventContext =
            world.getContext();

        for (H h : mList) {

            /**
             * Since we want to support {@link SMStateHandlerContext#isCancled() }
             * we must create instance per handler.
             * See also {@link AsyncStateHandler}
             */
            //eventContext.setHandler(h);

            I data = dSupplier.get();

            executor.execute(eventContext, data, h);
        }
    }


}