package wf.state_machine;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * @author Boaz Nahum
 */

public class HiddenName {

    private static final AtomicInteger c = new AtomicInteger();
    private static final String HIDDEN = "__hidden__";

    private HiddenName() {}

    /**
     * hidden if null or empty
     * @param name
     */
    static String hideIfNull(String name) {

        if (name != null && ! name.isEmpty()) {
            return name;
        }

        return "__hidden__" +  c.incrementAndGet();

    }

    public static boolean isHidden(String name) {

        return name == null || name.isEmpty() || name.startsWith(HIDDEN);


    }
}
