package wf.state_machine;

import wf.state_machine.outputers.dot.DotContext;
import wf.state_machine.outputers.XMLContext;
import org.w3c.dom.Element;

import java.util.LinkedList;

class InitialState extends PseudoState {

    private SMTransitionImp mTransition;

    InitialState(SMCompositeStateImp parent,
                 String sid) {
        super(parent, sid);
    }

    @Override
    final String getTypeName() {
        return "Initial";
    }


    @Override
    protected void checkValid() {
        super.checkValid();

        checkHaveGuaranteedOutgoingTransition(mTransition);

        // also check target is in parent container
        checkTargetIsInParent(mTransition);
    }

    @Override
    protected void init() {
        super.init();
    }


    @Override
    void setIncomingTransition(SMStateVertexImp source) {
        throw new SMDefinitionException("In " + getTypeAndName() +
                                        " no incoming transition are allowed");
    }

    @Override
    SMTransition addOutgoingTransition(SMBaseTrigger trigger, SMTransitionImp t) {

        super.addOutgoingTransition(trigger, t);

        checkAlreadyHasOutgoingTransition(mTransition);

        checkItIsUnary(t);

        mTransition = t;

        return t;
    }


    /**
     * find a path to destination target
     * return a list of SMTransitionSegment
     * if return null then no path trough this state
     */
    @Override
    LinkedList<SMTransitionSegmentImp> findPathThrough(LinkedList<SMTransitionSegmentImp> pathSoFar,
                                                    SMStateImp beginOfPath,
                                                    SMStateVertex source,
                                                    TriggerPacking triggerPacking) {
        return mTransition.findPathThrough(pathSoFar,
                beginOfPath,
                this,
                triggerPacking);
    }

    @Override
    boolean possiblyImpassable() {
        return false;
    }

    // ================ DOM support ===============================

    @Override
    public void writeBody(XMLContext xmlContext, Element myNode) {

        if (xmlContext.getDotContext() != null) {
            xmlContext.getDotContext().addDotComment(myNode, "Initial State");
        }

        super.writeBody(xmlContext, myNode);    //To change body of overridden methods use File | Settings | File Templates.

        writeDotBody(xmlContext, myNode);
    }

    private void writeDotBody(XMLContext xmlContext, Element myNode) {


        writeUnNamedTransition(xmlContext, myNode, mTransition);
    }

    @Override
    public String getElementName() {
        return "Initial";
    }

    // DOT support


    @Override
    public String getDotLabel() {
        return "";
    }

    @Override
    protected String getDotNoneComplexModeAttributes(DotContext dotContext) {
        String s1 = super.getDotNoneComplexModeAttributes(dotContext);
        String s2 = "shape=circle, margin=0, style=filled, color=black, width=0.1, height=0.1";

        return DotContext.concatenateAttributes(s1, s2);
    }

    SMStateVertex debugGetTarget() {
        if (mTransition != null) {
            return mTransition.getBranchTarget(0);
        } else {
            return null;
        }
    }


}

