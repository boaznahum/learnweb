package wf.state_machine;

interface InternalCommand {
    void doIt();
}