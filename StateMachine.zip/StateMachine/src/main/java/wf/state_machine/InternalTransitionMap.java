package wf.state_machine;

import org.w3c.dom.Element;
import wf.state_machine.outputers.XMLContext;

import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * A map between SMBaseTrigger to StateHandlerList
 * use to implement internal transitions
 */
final class InternalTransitionMap {

    private Map<SMBaseTrigger, StateHandlerList> mMap;

    StateHandlerList find(SMBaseTrigger eid) {
        if (mMap == null) {
            return null;
        }
        else {
            return mMap.get(eid);
        }
    }


    private StateHandlerList findOrCreate(SMBaseTrigger eid) {

        StateHandlerList handlerList = null;

        if (mMap == null) {
            mMap = new LinkedHashMap<>();
        }
        else {
            handlerList = mMap.get(eid);
        }

        if (handlerList == null) {
            handlerList = new StateHandlerList();
            mMap.put(eid, handlerList);
        }

        return handlerList;
    }

    void add(SMBaseTrigger eid, SMStateHandler h) {
        findOrCreate(eid).addLast(h);
    }


    void writeDotData(XMLContext xmlContext, Element inNode,
                      SMStateVertexImp source) {

        if (mMap == null) {
            return;
        }

        for (SMBaseTrigger trigger : mMap.keySet()) {
            SMTransitionImp t = new UnaryTransition(source.getWorld(), source, null);
            TransitionDotHelper.writeDotData(xmlContext, inNode, source, trigger, t, true);        }
    }


    // for debug only
    /**
     * return iterator to set of events
     */
    Iterator debugGetEventsIterator() {
        if (mMap == null) {
            return Collections.EMPTY_SET.iterator();
        }
        else {
            return mMap.keySet().iterator();
        }
    }

}