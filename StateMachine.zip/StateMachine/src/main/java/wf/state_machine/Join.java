package wf.state_machine;

import org.w3c.dom.Element;
import wf.state_machine.outputers.XMLContext;
import wf.state_machine.outputers.dot.DotContext;
import wf.state_machine.outputers.dot.DotHelper;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;


/**
 * This is actually Join:
 * A Join point is the opposite size of fork. It used to merge transitions from state.
 * When all transitions are arrived to Join then it's outgoing transition is executed.
 * Outgoing transition has no event. The are executed when all incoming are arrived.
 */
class Join extends PseudoState {

    public static final String DEFAULT_NAME = "J*";

    private final Map<SMStateVertex, Join> mEntries = new HashMap<>();
    private SMTransitionImp mTransition;
    private boolean mAllIn;

    Join(SMConcurrentStateImp parent,
         String sid) {
        super(parent, sid);
    }


    @Override
    final String getTypeName() {
        return "Join";
    }

    @Override
    public boolean isJoin() {
        return true;
    }

    @Override
    SMTransition addOutgoingTransition(SMBaseTrigger trigger, SMTransitionImp t) {
        super.addOutgoingTransition(trigger, t);

        checkAlreadyHasOutgoingTransition(mTransition);

        checkHaveDefaultBranch(t);

        // now check all event2transitions are out of concurrent state
        int n = t.getN();

        SMConcurrentStateImp parent = (SMConcurrentStateImp)getParentState();

        for (int i = 0; i < n; ++i) {
            SMStateVertexImp target = t.getBranchTarget(i);

            if (target != null) // in case i == 0
            {
                if (parent.findSubStateContainsOrEqInternal(target) != null) {
                    throw new SMDefinitionException(getTypeAndName() +
                                                    ", outgoing transition -->" +
                                                    target.getTypeAndName() +
                                                    " is in concurrent state");
                }
            }
        }

        mTransition = t;

        return t;
    }


    @Override
    void setIncomingTransition(SMStateVertexImp source) {

        SMConcurrentStateImp parent = (SMConcurrentStateImp)getParentState();

        SMStateVertexImp region = parent.findSubStateContainsOrEqInternal(source, false);

        if (region == null || !region.isRegion()) {
            throw new SMDefinitionException("In " + getTypeAndName() + ", incoming transition from " +
                                            source.getTypeAndName() + " not from (in) region");
        }

        // TODO: See in check list, check that all incoming are from different regions.

        mEntries.put(region, null);

    }

    @Override
    protected void checkValid() {
        super.checkValid();

        checkHaveGuaranteedOutgoingTransition(mTransition);

        // todo:check_valid all members

    }

    @Override
    protected void init() {
        super.init();

        clearEntries();

        mTransition.init();
    }


    private void clearEntries() {

        for (Map.Entry<SMStateVertex, Join> e : mEntries.entrySet()) {
            e.setValue(null);
        }

        mAllIn = false;

    }

    boolean isRegionIn(SMStateVertex region) {
        return mEntries.containsKey(region) && mEntries.get(region) != null;
    }


    @Override
    LinkedList<SMTransitionSegmentImp> findPathThrough(LinkedList<SMTransitionSegmentImp> pathSoFar,
                                                    SMStateImp beginOfPath,
                                                    SMStateVertex source,
                                                    TriggerPacking triggerPacking) {
        return pathSoFar; // reach here first and then exit
    }

    @Override
    boolean possiblyImpassable() {
        return false;
    }

    @Override
    LinkedList<SMStateVertexImp> enterBegin(SMStateImp beginOfPath,
                                            SMStateVertexImp innerTargetState,
                                            LinkedList<SMStateVertexImp> statesPath,
                                            SMStateVertexImp sourceState, // for debug
                                            TriggerPacking triggerPacking // for debug
    ) {
        statesPath = super.enterBegin(beginOfPath,
                                      innerTargetState,
                                      statesPath,
                                      sourceState,
                                      triggerPacking);

        SMConcurrentStateImp parent = (SMConcurrentStateImp)getParentState();

        SMStateVertexImp region = parent.findSubStateContainsOrEqInternal(sourceState, false);

        if (region == null) {
            throw new SMDefinitionException("region == null");
        }

        if (!(mEntries.containsKey(region))) {
            throw new SMDefinitionException("!mEntries.containsKey(region)");
        }

        mEntries.put(region, this); // we need some none null value has a flag

        // now check if all regions are in

        for (Map.Entry<SMStateVertex, Join> e : mEntries.entrySet()) {
            if (e.getValue() == null) {
                return statesPath; // not yet
            }
        }

        mAllIn = true; // so enter_end will know to make me current

        getWorld().addInternalSystemTrigger(SystemTrigger.JOIN_EXIT,
                                            this,
                                            new HelpExitData(triggerPacking, beginOfPath),
                                            true);


        return statesPath;
    }

    @Override
    void enterEnd(SMStateVertex sourceState, // for debug
                  TriggerPacking triggerPacking /* for debug */) {
        // see patch in super.enter_end in case of join
        super.enterEnd(sourceState, triggerPacking);

        if (mAllIn) {
            updateParentIBecomeCurrent();
        }

    }

    @Override
    void exitBegin(TriggerPacking triggerPacking,
                   SMStateVertex targetState) {
        super.exitBegin(triggerPacking, targetState);

        clearEntries();
    }

    @Override
    List<SMTransitionSegmentImp> processTrigger(TriggerPacking triggerPacking,
                                             SMStateVertex target,
                                             SMInternalTriggerData internalData,
                                             boolean myEvent) {

        if (!imTargetAndMySystemTrigger(triggerPacking, target, SystemTrigger.JOIN_EXIT)) {
            return null;
        }


        // assume super does nothing with trigger,
        //  if yes we should call it with 'and' trigger too
        super.processTrigger(triggerPacking, target, internalData, myEvent);

        HelpExitData fed = (HelpExitData)internalData;
        TriggerPacking realTrigger = fed.getStepTrigger();
        SMStateImp beginOfPath = fed.getBeginOfPath();

        return mTransition.findPathThrough(beginOfPath,
                                           this,
                                           realTrigger);

    }

    // ================ DOM support ===============================

    @Override
    public void writeBody(XMLContext xmlContext, Element myNode) {
        super.writeBody(xmlContext, myNode);

        writeDotBody(xmlContext, myNode);

        //if (mTransition != null) {
        //    mTransition.writeTo(xmlContext, myNode);
        //}
    }

    private void writeDotBody(XMLContext xmlContext, Element myNode) {

        writeUnNamedTransition(xmlContext, myNode, mTransition);
    }

    @Override
    public String getElementName() {
        return "join";
    }

    /**
     * DoingX_Fx[label="MyJoin|<1>1|<2>2" shape=record,width=.0];
     */
    @Override
    public String getDotLabel() {
        String label = super.getDotLabel();

        if (label.equals(DEFAULT_NAME)) {
            label = null;
        }

        SMConcurrentState parent = (SMConcurrentState)getParentState();

        return DotHelper.buildRecordLabelForConcurrent(label, parent);
    }

    /**
     * DoingX_Fx[label="Fork|<1>1|<2>2" shape=record,width=.0];
     *
     * @param dotContext
     */
    @Override
    protected String getDotNoneComplexModeAttributes(DotContext dotContext) {
        String s1 = super.getDotNoneComplexModeAttributes(dotContext);
        String s2 = "shape=record, width=.0";

        return DotContext.concatenateAttributes(s1, s2);
    }

    /**
     * The syntax from record is
     * node0:f0 -> node1:n;
     * where f0 and n are the ids we put in <>
     */
    @Override
    public String getDotNameAsTargetOfTransition(SMStateVertex source) {
        String name = super.getDotNameAsSourceOfTransition(source);

        return DotHelper.getRecordSubLabel(name, (SMConcurrentState)getParentState(), source);
    }


}


