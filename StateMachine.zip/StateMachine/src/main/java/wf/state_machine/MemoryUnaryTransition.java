package wf.state_machine;

import org.jetbrains.annotations.Nullable;

/**
 * @author Boaz Nahum
 * @version WI VX.6, V12.0X, ADC V0.95
 */

final class MemoryUnaryTransition extends SMTransitionImp {

    private final TransitionBranch branch0;

    MemoryUnaryTransition(StateMachineImp world) {
        super(world, null);

        // not yet set target
        branch0 = new TransitionBranch();
    }

    @Override
    protected TransitionBranch getTransitionBranchNoCheck(int i) {
        return branch0;
    }

    @Override
    int getN() {
        return 1;
    }

    void setTarget(int targetSelection, @Nullable SMStateVertexImp state) {

        checkTransitionIndex(targetSelection);
        getTransitionBranchNoCheck(targetSelection).setTarget(state);
    }

}
