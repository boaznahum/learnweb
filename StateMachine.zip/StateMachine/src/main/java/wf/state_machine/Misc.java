package wf.state_machine;

import org.jetbrains.annotations.Nullable;

import java.util.concurrent.atomic.AtomicLong;

/**
 * User: Boaz Nahum
 * Date: Feb 19, 2006
 */
class Misc {

    private static final AtomicLong uniqueGenerator = new AtomicLong();

    private Misc() {
    }

    public static String createUnique(@Nullable String prefix) {

        long uniqueID = uniqueGenerator.incrementAndGet();

        if (prefix == null) {
            return "" + uniqueID;
        } else {
            return prefix + "@" + uniqueID;
        }
    }

    /**
     * @param t1     must not be null
     * @param others must not be null but may be empty
     */
    static SMStateVertex[] merge(SMStateVertex t1, SMStateVertex[] others) {

        int n = 1 + others.length;

        SMStateVertex[] ts = new SMStateVertex[n];

        ts[0] = t1;
        System.arraycopy(others, 0, ts, 1, others.length);

        return ts;

    }

}
