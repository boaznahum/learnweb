package wf.state_machine;

/**
 * Transition with N >= 2 branches
 * @author Boaz Nahum
 * @version WI VX.6, V12.0X, ADC V0.95
 */

class NaryTransition extends PermanentTransition {

    private final TransitionBranch[] branches;

    NaryTransition(StateMachineImp world,
                   SMStateVertex[] targetStateList,
                   SMGuard guard) {
        
        super(world, guard);



        int nTargets = targetStateList.length;

        if (nTargets < 2) {
            throw new SMDefinitionException("In nary transition n must >= 2");
        }

        // in case of nary transition (nTargets>1) you must specify guard
        if (guard == null) {
            throw new SMDefinitionException("In case of more than one target, you must supply a guard");
        }


        branches = new TransitionBranch[nTargets];
        for (int i = 0; i < nTargets; ++i) {
            branches[i] = createAndSetTarget((SMStateVertexImp)targetStateList[i]);
        }

    }

    /**
     * targets are in range [0..N-1]
     */
    @Override
    final int getN() {
        return branches.length;
    }


    @Override
    protected TransitionBranch getTransitionBranchNoCheck(int i) {
        return branches[i];

    }
}
