package wf.state_machine;

/**
 * A transition that targets are final and can't be changed
 *
 * @author Boaz Nahum
 * @version WI VX.6, V12.0X, ADC V0.95
 */

abstract class PermanentTransition extends SMTransitionImp {


    PermanentTransition(StateMachineImp world, SMGuard guard) {
        super(world, guard);
    }


    private static void checkTargetIsNotNull(SMStateVertex target0) {
        if (target0 == null) {
            throw new SMDefinitionException("Target can't be null");
        }
    }

    static TransitionBranch createAndSetTarget(SMStateVertexImp target) {
        checkTargetIsNotNull(target);

        TransitionBranch branch = new TransitionBranch();

        branch.setTarget(target);

        return branch;
    }

}
