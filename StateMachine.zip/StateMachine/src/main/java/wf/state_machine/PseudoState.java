package wf.state_machine;


import org.jetbrains.annotations.Nullable;
import org.w3c.dom.Element;
import wf.state_machine.outputers.XMLContext;

import java.util.List;

abstract class PseudoState extends SMStateVertexImp {

    PseudoState(SMComplexStateImp parent,
                String sid) {
        super(parent, sid);
    }

    /**
     * @return true
     */
    @Override
    public boolean isPseudo() {
        return true;
    }

    private void checkIsNullTrigger(SMBaseTrigger trigger) {
        if (trigger != null) {
            throw new SMDefinitionException(getTypeName() +
                                            " '" + getName() +
                                            "' outgoing transition can't have trigger");
        }
    }

    final void checkAlreadyHasOutgoingTransition(SMTransition t) {
        if (t != null) {
            throw new SMDefinitionException(getTypeName() +
                                            " '" + getName() + "' already has one outgoing transition");
        }

    }

    final void checkHaveGuaranteedOutgoingTransition(SMTransitionImp t) {
        if (t == null) {
            throw new SMDefinitionException(getTypeAndName() + ": has no outgoing transition");
        }

        if (!t.isGuaranteed()) {
            throw new SMDefinitionException(getTypeAndName() + ": has no guaranteed outgoing transition");
        }
    }

    final void checkHaveGuaranteedOutgoingTransition(Transitions t) {
        if (t == null) {
            throw new SMDefinitionException(getTypeAndName() + ": has no outgoing transition");
        }

        if (!t.hasAtLeastOneGuaranteedTransition()) {
            throw new SMDefinitionException(getTypeAndName() + ": has no guaranteed outgoing transition");
        }
    }

    /**
     * At time of building this all we can do.
     * When verification we do more accurate check
     *
     * @param t
     */
    final void checkHaveDefaultBranch(SMTransitionImp t) {
        if (t.isGuardExists() && t.getBranchTarget(0) == null) {
            throw new SMDefinitionException(getTypeName() +
                                            " '" + getName() + "' outgoing transition must have default branch");
        }
    }

    final void checkHasAtLeastOneGuaranteedTransition(Transitions transitions) {
        if (!transitions.hasAtLeastOneGuaranteedTransition()) {
            throw new SMDefinitionException(getTypeName() +
                                            " '" + getName() + "' must have at least one guaranteed transition");
        }

    }

    final void checkItIsUnary(SMTransitionImp t) {
        if (!t.is1Branch()) {
            throw new SMDefinitionException(
                "In " + getTypeAndName() + ", outgoing transition must be unary(no default branch, no guard)");
        }
    }

    final void checkTargetIsInParent(SMTransitionImp t) {
        SMComplexStateImp parent = getParentState();

        List<SMStateVertex> l = t.isAllPathTroughIsInContainer(parent, false);

        if (l != null) {
            l.add(0, this);

            throw new SMDefinitionException("In " + getTypeAndName() +
                                            " there is a possibility of a outgoing transition ending on/outside container (" +
                                            parent.getTypeAndName() + ") : " +
                                            pathToString(l));

        }
    }

    final void checkTargetIsInParent(Transitions ts) {
        ts.checkTargetIsInParent(this);

    }


    @Override
    SMTransition addOutgoingTransition(SMBaseTrigger trigger, SMTransitionImp t) {

        checkIsNullTrigger(trigger);

        return t;
    }


    final boolean imTargetAndMySystemTrigger(TriggerPacking triggerPacking, SMStateVertex target,
                                             SystemTrigger systemTrigger) {

        //noinspection ObjectEquality
        return target == this && triggerPacking != null && triggerPacking.getTrigger() == systemTrigger;
    }


    static final class HelpExitData extends SMInternalTriggerData {

//        private final TriggerPacking realTrigger;
        private final SMStateImp beginOfPath;

        HelpExitData(TriggerPacking realTrigger, SMStateImp beginOfPath) {
            super(realTrigger);
            this.beginOfPath = beginOfPath;
        }

        SMStateImp getBeginOfPath() {
            return beginOfPath;
        }
    }

    // DOM/DOT support

    void writeUnNamedTransition(XMLContext xmlContext,
                                Element myNode,
                                @Nullable SMTransitionImp transition) {
        if (transition != null) {
            transition.writeTo(xmlContext, myNode);
            TransitionDotHelper.writeDotData(xmlContext, myNode, this, null, transition, false);
        }
    }


}
