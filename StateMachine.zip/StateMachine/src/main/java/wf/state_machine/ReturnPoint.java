package wf.state_machine;

import org.w3c.dom.Element;
import wf.state_machine.outputers.XMLAttributeAndValue;
import wf.state_machine.outputers.XMLContext;
import wf.state_machine.outputers.XMLWriteable;
import wf.state_machine.outputers.dot.DotContext;

import java.util.LinkedList;

/**
 * ReturnPoint is special state with no parent.
 * It is singleton.
 * Because it must have a parent, then we make top level state it's parent.
 * Is purpose is to find a path to 'entry state' of the state coming to it.
 *
 *
 * Date: Mar 18, 2005
 *
 * @author Boaz Nahum
 */
class ReturnPoint extends PseudoState implements XMLWriteable {

    ReturnPoint(TopLevelState parent) {
        super(parent, "$return$");
    }



    @Override
    protected void checkValid() {
        super.checkValid();
    }

    @Override
    protected void init() {
        super.init();
    }

    @Override
    void checkIncomingTransitionIsValid(SMStateVertexImp source) {
        if ( source.isPseudo() ) {
            throw new SMDefinitionException("Pseudo state can't be connected"
                                            + " to 'return point'");
        }
    }

    @Override
    void checkOutgoingTransitionIsValid(SMStateVertex target) {
        throw new SMDefinitionException("No outgoing transitions from " +
                                        "'return point");

    }


    /**
     * Add  segment source to you and find path through you.
     * Return null if no path through you.
     *  @param pathSoFar If no path found then pathSoFar is not modified.
     * @param triggerPacking*/
    @Override
    LinkedList<SMTransitionSegmentImp> addYourSegmentAndFindPathThrough(LinkedList<SMTransitionSegmentImp> pathSoFar,
                                                                     SMStateImp beginOfPath,
                                                                     SMStateVertexImp source,
                                                                     TriggerPacking triggerPacking,
                                                                     SMTransitionImp transition,
                                                                     int branchNumber) {

        /**
        * this casting is valid because of {@link SMStateVertexImp#checkIncomingTransitionIsValid(SMStateVertexImp)}
         */

        SMStateImp sourceState = (SMStateImp)source;

        SMStateImp stateToReturnTo = sourceState.getStateSourceState();

        if ( stateToReturnTo == null ) {
            return null;
        }

        // I'm only an alias
        return stateToReturnTo.addYourSegmentAndFindPathThrough(
                pathSoFar,
                beginOfPath,
                source,
                triggerPacking,
                transition,
                branchNumber);

    }

    @Override
    boolean possiblyImpassable() {
        return true;
    }

    @Override
    LinkedList<SMTransitionSegmentImp> findPathThrough(LinkedList<SMTransitionSegmentImp> pathSoFar,
                                                    SMStateImp beginOfPath,
                                                    SMStateVertex source,
                                                    TriggerPacking triggerPacking) {


        /**
         * I'm only an alias, no pass through me, see {@link #addYourSegmentAndFindPathThrough(java.util.LinkedList< wf.state_machine.SMTransitionSegment>, wf.state_machine.SMState, wf.state_machine.SMStateVertex, wf.state_machine.SMBaseTrigger, wf.state_machine.SMTransition, int)}
         */
         throw new SMDefinitionException("Unsupported operation");
    }

    @Override
    String getTypeName() {
        return "Return Point";
    }

    // ================ DOM support ===============================

    @Override
    public void writeBody(XMLContext xmlContext, Element myNode) {
        super.writeBody(xmlContext, myNode);


    }



    @Override
    public String getElementName() {
        return "return_point";
    }

    @Override
    public XMLAttributeAndValue[] getAttributes() {
        return null;
    }

    // DOt support
    @Override
    protected String getDotNoneComplexModeAttributes(DotContext dotContext) {
        //noinspection SpellCheckingInspection
        return "shape=Mcircle,"+
                "width=0.2, height=0.2," +
                "label=\"\"";
    }


}
