package wf.state_machine;

final class ReturnTransitionEventsPair {

    /**
     * May be null;
     */
    private final SMBaseTrigger entryTrigger;
    private final SMBaseTrigger returnTrigger;

    /**
     * @param entryTrigger - may be bull
     * @param returnTrigger
     */
    ReturnTransitionEventsPair(SMBaseTrigger entryTrigger, SMBaseTrigger returnTrigger) {
        this.entryTrigger = entryTrigger;
        this.returnTrigger = returnTrigger;
    }

    public SMBaseTrigger getEntryEvent() {
        return entryTrigger;
    }

    public SMBaseTrigger getReturnEvent() {
        return returnTrigger;
    }

    @Override
    public final String toString() {
        return "(" + entryTrigger + ", " + returnTrigger + ")";
    }

    @Override
    public boolean equals(Object o) {

        if (this == o) {
            return true;
        }
        if (!(o instanceof ReturnTransitionEventsPair)) {
            return false;
        }

        final ReturnTransitionEventsPair returnTransitionEventsPair = (ReturnTransitionEventsPair) o;

        if (entryTrigger != null ? !entryTrigger.equals(returnTransitionEventsPair.entryTrigger) : returnTransitionEventsPair.entryTrigger != null)
        {
            return false;
        }

        return returnTrigger.equals(returnTransitionEventsPair.returnTrigger);
    }

    @Override
    public int hashCode() {
        int result;
        result = (entryTrigger != null ? entryTrigger.hashCode() : 0);
        result = 29 * result + returnTrigger.hashCode();
        return result;
    }

}