package wf.state_machine;

/**
 * Auto generated trigger
 * @author Boaz Nahum
 * @version WI VX.6, V12.0X, ADC V0.95
 */

interface SMAGTrigger extends SMTrigger {

    @Override
    String getName();
}