package wf.state_machine;

/**
 * A base handler info that is not(cant be) associated with specific event
 * @author Boaz Nahum
 */

interface SMBaseHandlerContext {

    /**
     * Get the world
     */
    SMGlobalContext getGlobalContext();

    /**
     * Sugaring for {@link #getGlobalContext()}
     */
    default SMGlobalContext globalC() {
        return getGlobalContext();
    }

    /**
     * Sugaring over {@link #getGlobalContext()}
     *
     * Same as {@link SMGlobalContext#logUserMsg(String)} operated on {@link #getGlobalContext()}
     * @param s
     */
    default void logUserMsg(String s) {
        getGlobalContext().logUserMsg(s);
    }



}
