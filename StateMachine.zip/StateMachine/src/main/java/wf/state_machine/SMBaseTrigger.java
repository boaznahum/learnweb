package wf.state_machine;

public interface SMBaseTrigger  {
    String getName();
}

