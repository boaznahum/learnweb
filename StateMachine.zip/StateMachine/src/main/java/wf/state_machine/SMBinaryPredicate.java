package wf.state_machine;

/**
 * @author Boaz Nahum
 */

@FunctionalInterface
public interface SMBinaryPredicate {

    /**
     * See {@link SMCondition#isTrue(SMTransitionGuardContext)}
     * @return it true then transition 0 is taken
     * otherwise, this is unary transition then no transition is taken, if binary then transition 1 ('else') is taken
     */
    boolean isTrue(SMTransitionGuardContext info);


    default String getName() {
        return toString();
    }
}
