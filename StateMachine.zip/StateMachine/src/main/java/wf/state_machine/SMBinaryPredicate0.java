package wf.state_machine;

/**
 * A simple binray guard that accept no parameters
 * @author Boaz Nahum
 */

@FunctionalInterface
public interface SMBinaryPredicate0 {

    /**
     * See {@link SMCondition#isTrue(SMTransitionGuardContext)}
     * @return it true then transition 0 is taken
     * otherwise, this is unary transition then no transition is taken, if binary then transition 1 ('else') is taken
     */
    boolean isTrue();

}
