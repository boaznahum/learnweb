package wf.state_machine;

import org.w3c.dom.Element;
import wf.state_machine.outputers.XMLContext;
import wf.state_machine.outputers.dot.DotContext;

import java.util.List;

abstract class SMChoicePoint extends PseudoState {

    // static choice point may have no outgoing transition
    // so this member may be null
    Transitions transitions;

    SMChoicePoint(SMCompositeStateImp parent,
                  String sid) {
        super(parent, sid);
    }


    @Override
    SMTransition addOutgoingTransition(SMBaseTrigger trigger, SMTransitionImp t) {
        super.addOutgoingTransition(trigger, t);

        //checkAlreadyHasOutgoingTransition(mTransition);

        if (transitions == null) {
            transitions = new Transitions(getWorld());
        }

        transitions.add(t);

        return t;
    }

    /**
     * Return the path to the first vertex (in my path)that is not in container.
     * onEdgeIsOk determine if we interested in 'really in' or that 'equal' is also consider 'in'
     */
    @Override
    List<SMStateVertex> isAllPathTroughIsInContainer(SMComplexStateImp container,
                                                     boolean onEdgeIsOk) {
        if (transitions == null) {
            return null; // it is not ok, but it will be caught by SMChoicePoint.check_valid()
        }

        List<SMStateVertex> l = transitions.isAllPathTroughIsInContainer(container,
                                                                         onEdgeIsOk);

        if (l != null) {
            l.add(0, this); // return this --> t1 --> t2 ...
        }

        return l;
    }

    @Override
    protected void init() {
        super.init();

        if (transitions != null) {
            transitions.init();
        }

    }

    @Override
    protected void checkValid() {
        super.checkValid();

        if (transitions != null) {
            transitions.checkValid();
        }
    }

    // ================ DOM support ===============================

    @Override
    public void writeBody(XMLContext xmlContext, Element myNode) {

        writeDotBody(xmlContext, myNode);

        super.writeBody(xmlContext, myNode);
    }

    private void writeDotBody(XMLContext xmlContext, Element myNode) {

        if (transitions != null) {
            transitions.writeDotData(xmlContext, myNode, this, null);
        }

        //writeUnNamedTransition(xmlContext, myNode, mTransition);
    }

    @Override
    String getDotNoneComplexModeAttributes(DotContext dotContext) {

        String a1 = super.getDotNoneComplexModeAttributes(dotContext);

        String a2;
        //noinspection ConstantConditions

        //a2 = "shape=circle, margin=0, width=0.1, height=0.1";

        a2 = "shape=diamond, " +
             "fontsize=10," +
             "margin=0," +
             "width=0.01, " +
             "height=0.01";

        return DotContext.concatenateAttributes(a1, a2);

    }


}

