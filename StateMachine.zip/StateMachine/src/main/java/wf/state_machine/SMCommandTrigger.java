package wf.state_machine;

/**
 * A trigger that is used to execute command in SM
 * @author Boaz Nahum
 * @version WI VX.6, V12.0X, ADC V0.95
 */

interface SMCommandTrigger extends SMBaseTrigger {

    /**
     * The StateMachine is passed as parameter so we can create singleton
     * of this command.
     */
    void run(StateMachineImp sm);

}
