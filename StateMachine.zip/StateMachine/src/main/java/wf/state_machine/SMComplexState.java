package wf.state_machine;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;

/**
 * !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 * !! This interface is not intended to be implemented by client code
 * !! SM FW assumes that only its internal implementation exists
 * !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 * @author Boaz Nahum
 */

@SuppressWarnings("ClassReferencesSubclass")
interface SMComplexState extends SMState {


    /**
     * The format of name is "s1:s2:s3",
     *  where
     *  s1 is inner of this state
     *  s2 is inner state in s1
     *  s3 ...
     *
     *  if you want toi start from root of state machine then use {@link StateMachine#getState(String)}
     * @param name
     */
    @Nullable
    SMStateVertex getState(String name);

    /**
     * Same as {@link #getState(String)} but throws assertion if not found
     */
    SMStateVertex getStateAssert(String name);

    /**
     * See {@link #getState(String)}
     *
     * Search for non pseudo state
     * @param name
     * @throws Exception if not found or if it is a pseudo state
     */
    @NotNull
    SMState getRealStateAssert(String name);

    SMCompositeState addCompositeState(String sid);

    SMConcurrentState addConcurrentState(String sid);

    /**
     * will return null if state is not stable, and it's current state
     * is PseudoState
     * in case of concurrent state this current state has no useful meaning
     */
    @Nullable
    SMState getCurrentState();

    /**
     * todo:boaz:tmpcode: try to remove it from public interface!!!
     */
    Collection<? extends SMState> getSubStates();

    /**
     * todo:boaz:tmpcode: try to remove it from public interface!!!
     */
    SMStateVertex findSubStateContainsOrEq(SMStateVertex s);
}
