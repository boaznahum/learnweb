package wf.state_machine;

// for debug only

import org.jetbrains.annotations.Nullable;
import wf.state_machine.outputers.DOMHelper;
import wf.state_machine.outputers.dot.DotContext;
import wf.state_machine.outputers.XMLContext;
import org.w3c.dom.Element;

import java.util.List;
import java.util.Collection;

/**
 * A state that contains other {@link SMState}s and {@link PseudoState}s.<br>
 * It may one of:<br>
 * <LI>
 * {@link SMConcurrentState} a state that is composed directly into two or more
 * orthogonal {@link SMComplexStateImp} called regions.
 * </LI>
 * <LI> {@link SMCompositeState} that it is not {@link SMConcurrentState}
 * </LI>
 * <LI>A region is a {@link SMComplexStateImp} that is sub-state of {@link SMConcurrentState}
 * </LI>
 * <LI>{@link TopLevelState}  A {@link SMCompositeState} that is directly sub-state of {@link StateMachine}
 * </LI>
 */
@SuppressWarnings({"ClassReferencesSubclass"})
abstract class SMComplexStateImp extends SMStateImp implements SMComplexState {

    final StateVertexIDMap<PseudoState> mPseudoSubStates = new StateVertexIDMap<>();

    private final StateIDMap mStateSet = new StateIDMap();

    private final boolean mIsRegion;


    /**
     * please note: during some phases of state, mCurrentState may be a PseudoState
     * but, during stable state it must be at least a SMState
     * this is the reason why SMConcurrentState also has current state (during stable state
     * of concurrent state all of its sub-states are current
     */
    SMStateVertexImp mCurrentState;


    SMComplexStateImp(StateMachineImp world, SMComplexStateImp parent, String sid) {
        super(world, parent, sid);

        // top level state is never region
        mIsRegion = (parent != null) && parent.isConcurrent();
    }

    @Override
    boolean isComplex() {
        return true;
    }

    @Override
    public final boolean isRegion() {
        return mIsRegion;
    }


    // this is not protected because For & DotHelper need it
    final StateIDMap getSubStatesMap() {
        return mStateSet;
    }


    @Override
    public final Collection<? extends SMState> getSubStates() {
        return mStateSet.values();
    }

    final Collection<? extends SMStateImp> getSubStatesInternal() {
        return mStateSet.values();
    }

    private <S extends SMStateVertexImp> void addState(StateVertexIDMap<S> list, S state) {

        // look both in real states and pseudo states !!!
        SMStateVertexImp already = findState(state.getName());

        if (already != null) {
            throw new SMDefinitionException("SMState with name '" +
                                            state +
                                            "' already defined in " + getTypeAndName() +
                                            " as " + already.getTypeAndName());
        }

        list.add(state);
    }

    final void addState(SMStateImp state) {
        addState(getSubStatesMap(), state);
    }

    final void addPseudoState(PseudoState state) {
        addState(mPseudoSubStates, state);
    }

    @Override
    public final SMStateVertex getState(String name) {
        String[] names = name.split(":");

        if (names.length == 0) {
            return null;
        }

        SMComplexStateImp c = this;

        int i = 0;
        for (; i < names.length - 1; ++i) {
            SMStateVertex s = c.findState(names[i]);

            if (s == null) {
                return null;
            }

            if (!(s instanceof SMComplexStateImp)) {
                return null;
            }

            c = (SMComplexStateImp)s;
        }

        return c.findState(names[i]);
    }

    /**
     * throw assertion if not found
     */
    @Override
    public final SMStateVertex getStateAssert(String name) {
        String[] names = name.split(":");

        if (names.length == 0) {
            throw new SMDefinitionException("getStateAssert, SMState name invalid: " + name);
        }

        SMStateVertexImp s = this;

        //int i = 0;
        int n = names.length;

        for (int i = 0; i < n; ++i) {
            if (!(s instanceof SMComplexStateImp)) {
                StringBuilder left = new StringBuilder();

                for (int j = i; j < n - 1; ++j) {
                    left.append(names[j]);
                    left.append(":");
                }

                left.append(names[n - 1]);

                throw new SMDefinitionException("getStateAssert, " +
                                                s.getAbsName() + "is not an complex thus does not contains " + left);

            }

            SMComplexStateImp c = (SMComplexStateImp)s;

            s = c.findState(names[i]);

            if (s == null) {
                throw new SMDefinitionException("getStateAssert, " +
                                                c.getAbsName() + " does not contains " + names[i]);
            }

        }

        return s;
    }

    @Nullable
    @Override
    public SMState getRealStateAssert(String name) {

        SMStateVertexImp state = (SMStateVertexImp)getStateAssert(name);


        if (!(state instanceof SMState)) {

            throw new SMDefinitionException("Override, " +
                                            state.getAbsName() + " is a pseudo state");

        }
        return ((SMState)state);
    }


    /**
     * return <b>null</b> if not found
     */
    @Nullable
    private final SMStateVertexImp findState(String sid) {
        SMStateVertexImp s = mPseudoSubStates.find(sid);

        if (s != null) {
            return s;
        }

        return getSubStatesMap().find(sid);
    }


    @Override
    public final SMCompositeState addCompositeState(String sid) {

        SMCompositeStateImp s = new SMCompositeStateImp(this, sid);
        addState(s);
        return s;
    }


    @Override
    public final SMConcurrentState addConcurrentState(String sid) {
        SMConcurrentStateImp s = new SMConcurrentStateImp(this, sid);
        addState(s);
        return s;
    }

    /**
     * will return null if state is not stable, and it's current state
     * is PseudoState
     * in case of concurrent state this current state has no useful meaning
     */
    @Override
    @Nullable
    public final SMState getCurrentState() {
        return getCurrentStateInternal();
    }

    @Nullable
    private final SMStateImp getCurrentStateInternal() {
        return mCurrentState != null ? mCurrentState.getRealState() : null;
    }

    @Override
    public final SMState getCurrentStateDeep() {
        SMStateImp current = getCurrentStateInternal();
        return current != null ? current.getCurrentStateDeep() : null;
    }

    //=======================================================================
    // transition definition

    Transitions getFinalTransitions() {
        return findTransitions(SystemTrigger.STATE_FINAL);
    }

    @Override
    SMTransition addOutgoingTransition(SMBaseTrigger trigger, SMTransitionImp t) {

        /**
         * define transition from this state.
         * this transition occurred when current state
         * is final.
         *  see {@link SMCompositeState#addFinalState(String)}
         */
        if (trigger == null) {
            trigger = SystemTrigger.STATE_FINAL;
        }

        return super.addOutgoingTransition(trigger, t);
    }

    //================================================================
    @Override
    protected void checkValid() {
        super.checkValid();

        StateVertexIDMap<SMStateImp> subStates = getSubStatesMap();

        for (SMStateImp s : subStates.getStates()) {
            s.checkValid();
        }

        for (PseudoState s : mPseudoSubStates.getStates()) {
            s.checkValid();
        }

        if (subStates.isEmpty()) {
            throw new SMDefinitionException("Complex state " + getAbsName() + " contains no sub states");
        }

    }


    @Override
    void init() {
        super.init();

        init(mPseudoSubStates);
        init(getSubStatesMap());

        mCurrentState = null;
    }

    private static void init(StateVertexIDMap<? extends SMStateVertex> subStates) {
        for (SMStateVertexImp smStateVertex : subStates.getStates()) {
            smStateVertex.init();
        }
    }


    //================================================================
    // handle events
    @Override
    void resetTriggerQueues() {
        super.resetTriggerQueues();
        getSubStatesMap().resetEventQueues();
    }

    // ============================================================================
    // state math

    @Override
    boolean isStateContains(SMStateVertex s) {

        for (SMStateImp smState : getSubStatesMap().getStates()) {
            if (smState.isStateContainsOrEq(s)) {
                return true;
            }
        }

        for (PseudoState pseudoState : mPseudoSubStates.getStates()) {
            if (pseudoState.isStateContainsOrEq(s)) {
                return true;
            }
        }

        return false;
    }


    SMState findSubStateContains(SMStateVertex s) {
        // pseudo states can't contains other state
        // so we ignore them

        for (SMStateImp subState : getSubStatesMap().getStates()) {

            if (subState.isStateContains(s)) {
                return subState;
            }
        }

        return null;
    }

    private static SMStateVertexImp findSubStateContainsOrEq(SMStateVertex s,
                                                             StateVertexIDMap<? extends SMStateVertex> list) {

        for (SMStateVertexImp smStateVertex : list.getStates()) {

            if (smStateVertex.isStateContainsOrEq(s)) {
                return smStateVertex;
            }
        }

        return null;

    }

    final SMStateVertexImp findSubStateContainsOrEqInternal(SMStateVertex s, boolean pseudoStatesToo) {

        SMStateVertexImp c;

        c = findSubStateContainsOrEq(s, getSubStatesMap());

        if (c != null || !pseudoStatesToo) {
            return c;
        }

        c = findSubStateContainsOrEq(s, mPseudoSubStates);

        return c;
    }

    final SMStateVertexImp findSubStateContainsOrEqInternal(SMStateVertex s) {
        return findSubStateContainsOrEqInternal(s, true);
    }

    @Override
    public final SMStateVertex findSubStateContainsOrEq(SMStateVertex s) {
        return findSubStateContainsOrEqInternal(s, true);
    }

    abstract void childBecomeCurrent(SMStateVertexImp child);

    // ================ DOM support ===============================

    @Override
    public void writeBody(XMLContext xmlContext, Element myNode) {

        DotContext dotContext = xmlContext.getDotContext();

        String dotClusterName = null;
        if (dotContext != null) {
            if (!isTopLevel()) {
                dotClusterName = getDotName();
                //noinspection SpellCheckingInspection
                dotContext.addDotElement(myNode, "subgraph " + dotClusterName + " {");
                dotContext.addDotElement(myNode, DotContext.getDotLabelEqualsName(this) + ";");

                //if (isConcurrent()) {
                //    dotContext.addDotElement(myNode, "rank=same;");
                //}

                if (isActive()) {
                    dotContext.addDotElement(myNode, "color=" + DOTAttributesXx.COMPLEX_STATE_ACTIVE_LINE_COLOR + ";");
//                DotHelper.addDotElement(myNode, "peripheries=2;");
                } else {
                    // it seems that color attributes are remember between brother graphs.
                    // so when i set color to red, the following brothers are drawn as red too.
                    // so here ii reset it to black
                    dotContext.addDotElement(myNode, "color=black;");
                }

                if (isRegion()) {
                    //http://www.graphviz.org/doc/info/attrs.html
                    dotContext.addDotElement(myNode, "style=" + DOTAttributesXx.REGION_STATE_LINE_STYLE + ";");

                }

                if (!dotContext.isSupportingNodeToClusterArrow()) {
                    dotContext.addDummyNodesMarker(myNode, this);
                }

            }

        }


        // DOM
        {
            Element pseudoStateElement = DOMHelper.domAddElement(myNode, "PseudoStates");

            StateVertexIDMap<PseudoState> subList = mPseudoSubStates;

            for (PseudoState pseudoState : subList.getStates()) {
                pseudoState.writeTo(xmlContext, pseudoStateElement);
            }
        }

        {
            Element subStatesElem = DOMHelper.domAddElement(myNode, "SubStates");


            StateIDMap subStates = getSubStatesMap();

            for (SMStateImp state : subStates.getStates()) {
                state.writeTo(xmlContext, subStatesElem);
            }
        }


        super.writeBody(xmlContext, myNode);

        if (dotContext != null) {
            if (!isTopLevel()) {
                dotContext.addDotElement(myNode, "} // end of " + dotClusterName);
                dotContext.addDotElement(myNode, "");
            }
        }

    }


    /**
     * All real and pseudo states
     */
    @Override
    public void debugAddAllStates(List<String> states) {

        super.debugAddAllStates(states);

        mPseudoSubStates.debugAddAllStates(states);
        mStateSet.debugAddAllStates(states);
    }

}
