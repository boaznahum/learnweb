package wf.state_machine;

import org.jetbrains.annotations.Nullable;

/**
 * !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 * !! This interface is not intended to be implemented by client code
 * !! SM FW assumes that only its internal implementation exists
 * !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 * @author Boaz Nahum
 */
public interface SMCompositeState extends SMComplexState {

    //=======================================================================
    // define states

    /**
     *
     * @param stateName Can be null or empty.
     * In such case a name wil be generated for it and it won't appear in plotters and you can't search by.
     */
    SMState addSimpleState(@Nullable String stateName);

    SMState[] addSimpleStates(String[] names);

    /**
     * Add named initial pseudo state without connecting it to the initial state.
     * The initial state must connected to one of the states in this state.
     * The connected state may be indirect child of it.
     *
     * See sugaring for creating and connecting an initial state {@link #addInitialState(SMStateVertex)}
     *
     * In case of a complex state that has only one inner non pseudo state and if you don't need the transition from
     * the initial, then you don't have to set an initial state.
     *
     */
    SMStateVertex addInitialState(String name);

    /**
     * Same as  {@link #addInitialState(String)} but use default name 'I*' with is not displayed on diagrams
     * name is 'I*'
     *
     */
    SMStateVertex addInitialState();

    /**
     * Sugaring:
     * Add initial state and connect it to a state.
     * name is 'I*'
     * See {@link #addInitialState()}
     */
    SMTransition addInitialState(SMStateVertex targetState);


    /**
     * @param name If nullable, then won't be displayed, See {@link #addSimpleState(String)}
     */
    SMState addFinalState(@Nullable String name);

    /**
     * State name won't be displayed
     */
    default SMState addFinalState() {
        return addFinalState(null);
    }



    SMStateVertex addStaticChoicePoint(String name);

    SMStateVertex addDynamicChoicePoint(String name);

    /**
     * Deep history with default name.See {@link #addDeepHistory(String)}
     * Deep history remember last visited most inner state, shallow history only remember for the top inner states.
     *
     *
     * You can add transition to history without a trigger that will be taken
     * in case history was not yet memorized {@link SMStateVertexImp#addTransition(SMStateVertex)}
     */
    SMHistory addDeepHistory();

    /**
     * Deep history remember last visited most inner state, shallow history only remember for the top inner states.
     *
     * Use method {@link SMHistory#getHistoryTransition()} to get
     * access to the history transition, so you can add
     * handlers to it.
     *
     * You can add transition to history without a trigger that will be taken
     * in case history was not yet memorized {@link SMStateVertexImp#addTransition(SMStateVertex)}
     */
    SMHistory addDeepHistory(String name);

    /**
     * Shallow history with default name. See {@link #addShallowHistory(String)}
     *
     * Deep history remember last visited most inner state, shallow history only remember for the top inner states.
     *
     * You can add transition to history without a trigger that will be taken
     * in case history was not yet memorized {@link SMStateVertexImp#addTransition(SMStateVertex)}
     */
    SMHistory addShallowHistory();

    /**
     * Deep history remember last visited most inner state, shallow history only remember for the top inner states.
     *
     * Use method {@link SMHistory#getHistoryTransition()} to get
     * access to the history transition, so you can add
     * handlers to it.
     *
     * You can add transition to history without a trigger that will be taken
     * in case history was not yet memorized {@link SMStateVertexImp#addTransition(SMStateVertex)}
     *
     */
    SMHistory addShallowHistory(String name);

    /**
     * Define transition from each sub sub state.
     *
     * See also {@link SMStateVertex#addTransitionsFromMany(SMBaseTrigger, SMCondition, SMStateVertex...)}

     * @return return array may be zero length if no sub state is this composite state.
     */
    SMTransition[] addTransitionFromAllSubStates(SMBaseTrigger triggerTrigger,
                                                 SMGuard guard,
                                                 SMStateVertex target1,
                                                 SMStateVertex... otherTargets);
}
