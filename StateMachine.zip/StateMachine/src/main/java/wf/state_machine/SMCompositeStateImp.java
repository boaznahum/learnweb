package wf.state_machine;

import org.jetbrains.annotations.Nullable;
import org.w3c.dom.Element;
import wf.state_machine.outputers.XMLContext;

import java.util.LinkedList;
import java.util.List;

class SMCompositeStateImp extends SMComplexStateImp implements SMCompositeState {

    private boolean mHasOnEdgeIncomingTransition; // see check valid
    private InitialState mInitialState;

    /**
     * please note, these two are also contained in {@link #mPseudoSubStates} !!!
     */
    private SMHistory mDeepHistory;
    private SMHistory mShallowHistory;

    SMCompositeStateImp(StateMachineImp world, SMComplexStateImp parent, String sid) {
        super(world, parent, sid);
    }

    SMCompositeStateImp(SMComplexStateImp parent, String sid) {
        super(parent.getWorld(), parent, sid);
    }

    @Override
    final boolean isInFinalState() {
        return mCurrentState.isInFinalState();
    }

    // this is not final , because top level need override it
    @Override
    String getTypeName() {
        return "Composite SMState";
    }

    // public void setInitialState(SMStateVertex initialState) { mInitialState = initialState; }
    final SMStateVertex getInitialState() {
        return mInitialState;
    }

    @Override
    final SMStatePathTree getCurrentStatePathTree() {
        if (mCurrentState == null) {
            return null;
        } else {


            SMStatePathTree t = new SMStatePathTree(this, mCurrentState.getCurrentStatePathTree());

            return t;
        }
    }

    @Override
    final SMStateVertexImp getDeepHistory() {
        return mCurrentState.getDeepHistory();
    }


    //=======================================================================
    // define states
    @Override
    public final SMState addSimpleState(String stateName) {
        SimpleState st = new SimpleState(this, stateName);
        addState(st);
        return st;
    }

    @Override
    public final SMState[] addSimpleStates(String[] names) {
        SMState[] states = new SMState[names.length];

        for (int i = 0; i < names.length; ++i) {
            states[i] = addSimpleState(names[i]);
        }

        return states;
    }


    /**
     * The initial state must connected to one of the states in this state.
     * The connected state may be indirect child of it.
     */
    @Override
    public final SMStateVertex addInitialState(String name) {
        if (mInitialState != null) {
            throw new SMDefinitionException(getTypeAndName() +
                                            " already has initial state: " +
                                            mInitialState.getTypeAndName());
        }

        InitialState i = new InitialState(this, name);

        mInitialState = i;

        addPseudoState(i);

        return i;
    }

    /**
     * name is 'I*'
     * See {@link #addInitialState()}
     */
    @Override
    public final SMStateVertex addInitialState() {
        return addInitialState("I*");
    }

    /**
     * Sugaring:
     * Add initial state and connect it to a state.
     * name is 'I*'
     * See {@link #addInitialState()}
     */
    @Override
    public final SMTransition addInitialState(SMStateVertex targetState) {
        return addInitialState().addTransition(targetState);
    }


    @Override
    public final SMState addFinalState(String name) {
        FinalState finalState = new FinalState(this, name);
        addState(finalState);
        return finalState;
    }

    @Override
    public final SMStateVertex addStaticChoicePoint(String name) {
        StaticChoicePoint choicePoint =
            new StaticChoicePoint(this, name);

        addPseudoState(choicePoint);

        return choicePoint;
    }

    @Override
    public final SMStateVertex addDynamicChoicePoint(String name) {
        DynamicChoicePoint choicePoint =
            new DynamicChoicePoint(this, name);

        addPseudoState(choicePoint);

        return choicePoint;
    }

    private void checkHistoryNotInParent() {
        if (isTopLevel()) {
            throw new SMDefinitionException("Top level state may have no history");
        }
    }

    /**
     * Deep history with default name.
     * See {@link #addDeepHistory(String)}
     */
    @Override
    public final SMHistory addDeepHistory() {
        return addDeepHistory("H*");

    }

    /**
     * Use method {@link SMHistory#getHistoryTransition()} to get
     * access to the history transition, so you can add
     * handlers to it.
     */
    @Override
    public final SMHistory addDeepHistory(String name) {
        checkHistoryNotInParent();

        if (mDeepHistory != null) {
            throw new SMDefinitionException("Composite state '" + this + "' already has deep history: '" +
                                            mDeepHistory + "'");
        }

        mDeepHistory = new SMHistory(true,
                                     this,
                                     name);

        addPseudoState(mDeepHistory);

        return mDeepHistory;
    }

    @Override
    public SMHistory addShallowHistory() {
        return addShallowHistory("H");
    }

    /**
     * Use method {@link SMHistory#getHistoryTransition()} to get
     * access to the history transition, so you can add
     * handlers to it.
     */
    @Override
    public final SMHistory addShallowHistory(String name) {
        checkHistoryNotInParent();

        if (mShallowHistory != null) {
            throw new SMDefinitionException("Composite state '" + this + "' already has shallow history: '" +
                                            mShallowHistory + "'");
        }

        mShallowHistory = new SMHistory(false,
                                        this,
                                        name);

        addPseudoState(mShallowHistory);

        return mShallowHistory;
    }

    private void clearHistory() {
        if (mDeepHistory != null) {
            mDeepHistory.clearHistory();
        }

        if (mShallowHistory != null) {
            mShallowHistory.clearHistory();
        }
    }

    //=======================================================================
    // transition definition

    /**
     * Define transition from each sub sub state.
     * <p>
     * See also {@link SMStateVertex#addTransitionsFromMany(SMBaseTrigger, SMCondition, SMStateVertex...)}
     *
     * @return return array may be zero length if no sub state is this composite state.
     */
    @Override
    public final SMTransition[] addTransitionFromAllSubStates(SMBaseTrigger triggerTrigger,
                                                              SMGuard guard,
                                                              SMStateVertex target1,
                                                              SMStateVertex... otherTargets) {

        SMStateImp[] allSubStates = getSubStatesMap().getAllStates();

        return addTransitionFromManyStates(allSubStates,
                                           triggerTrigger,
                                           guard, target1, otherTargets);

    }

    @Override
    final void setIncomingTransition(SMStateVertexImp source) {
        mHasOnEdgeIncomingTransition = true;
    }

    //================================================================
    @Override
    protected void checkValid() {
        super.checkValid();

        if (mHasOnEdgeIncomingTransition && mInitialState == null) {
            throw new SMDefinitionException(getTypeAndName() +
                                            " has on edge incoming transition," +
                                            " but has no initial state");
        }

    }

    @Override
    void init() {
        super.init();
    }


    /**
     * return list of SMTransitionSegment if transition need to be handled by caller
     * return EMPTY_SEGMENT_LIST if transition was occurred, but was handled by state itself
     */
    @Override
    final List<SMTransitionSegmentImp> processTrigger(TriggerPacking triggerPacking,
                                                      SMStateVertex target,
                                                      SMInternalTriggerData internalData,
                                                      boolean myEvent) {

        if (myEvent) {
            target = null; // now it's my trigger and all my children
        }

        List<SMTransitionSegmentImp> l =
            mCurrentState.preAndProcessTrigger(triggerPacking, target, internalData);

        //My inner state don't cause any transition, so I'm trying
        // to check if there is any transitions from my edge.
        // We assume that inner states have priority over outer states.
        if (l == null && myEvent) {
            l = super.processTrigger(triggerPacking, target, internalData, myEvent);
        }

        if (l == null) {
            return null; // nothing to do
        }

        //    boolean transitionHandled = true;
        //noinspection ObjectEquality
        if (l != EMPTY_SEGMENT_LIST) {   // was not handled yet
            if (transitionCompletelyIn(l)) {
                getWorld().processTransition(l);
                //System.out.println("Internal transition handled by container state: " + this);
                l = EMPTY_SEGMENT_LIST;
            }
        }

        //noinspection ObjectEquality
        if (l == EMPTY_SEGMENT_LIST) {
            // event2transitions were occurred, and all were in this state
            // now check if there is final state transition

            Transitions finalTransition = getFinalTransitions();

            if (finalTransition != null && isInFinalState()) {
                LinkedList<SMTransitionSegmentImp> pathFromParent =
                    finalTransition.findPathThrough(null,
                                                    this,
                                                    triggerPacking);

                if (pathFromParent != null) {
                    l = pathFromParent;
                }
            }
        }

        return l;
    }


    // ============================================================================
    // state entry/exit
    @Override
    LinkedList<SMStateVertexImp> enterBegin(SMStateImp beginOfPath,
                                            SMStateVertexImp innerTargetState,
                                            LinkedList<SMStateVertexImp> statesPath,
                                            SMStateVertexImp sourceState, // for debug
                                            TriggerPacking triggerPacking /* for debug*/) {
        statesPath = super.enterBegin(beginOfPath,
                                      innerTargetState,
                                      statesPath,
                                      sourceState,
                                      triggerPacking);


        //noinspection ObjectEquality
        boolean enteringEdge = innerTargetState == null || innerTargetState == this;

        // See super imp
        //noinspection ObjectEquality
        if (getInitialState() == null && enteringEdge) {

            innerTargetState = getSingleInnerState();

            if (innerTargetState != null) {
                enteringEdge = false;
            }
        }


        if (enteringEdge) { // try to enter to edge of state

            if (mInitialState == null) {
                /**
                 // We try to check this condition at verification time, see {@link SMCompositeState#checkValid()}
                 // But there are situations that is hard to do, for example:
                 // There is direct entry to one of regions so it's sibling is entered
                 //  to the edge without explicitly defining transition
                 */
                String stateName = getAbsName();
                throw new SMDefinitionException("You are trying to enter edge of state:'" + stateName + "' " +
                                                ",but no initial state is defined for it, ant it has more than one inner state");
            }

            LinkedList<SMTransitionSegmentImp> pathFromInitial =
                mInitialState.findPathThrough(null, beginOfPath, mInitialState, triggerPacking);

            /** well, we assume all path is in this container,
             *  this assumption should be checked in {@link InitialState#checkValid()}
             */
            getWorld().processTransition(pathFromInitial);

        } else {

            SMStateVertexImp container = findSubStateContainsOrEqInternal(innerTargetState);

            mCurrentState = container;

            if (container == null) {
                throw new SMExecutionException("SMState " + getAbsName() +
                                               " doesn't contain sub state " +
                                               innerTargetState.getAbsName());
            }

            statesPath = container.enterBegin(beginOfPath,
                                              innerTargetState,
                                              statesPath,
                                              sourceState,
                                              triggerPacking);
        }

        return statesPath;

    }

    @Nullable
    private SMStateImp getSingleInnerState() {

        StateIDMap subStatesMap = getSubStatesMap();

        if (subStatesMap.size() == 1) {
            return subStatesMap.values().iterator().next();
        } else {
            return null;
        }
    }

    @Nullable
    boolean isSingleInnerState() {

        StateIDMap subStatesMap = getSubStatesMap();

        return  subStatesMap.size() == 1;
    }

    // please note ! enter_end is not recursive
    @Override
    final void enterEnd(SMStateVertex sourceState, // for debug
                        TriggerPacking triggerPacking // for debug
    ) {
        super.enterEnd(sourceState, triggerPacking);
    }

    @Override
    final void exitBegin(TriggerPacking triggerPacking,
                         SMStateVertex targetState) {

        boolean hasHistory = mDeepHistory != null || mShallowHistory != null;


        if (hasHistory) {
            SMStateVertexImp deepHistory = getDeepHistory();

            if (deepHistory == null) {
                clearHistory();
            } else {
                if (mDeepHistory != null) {
                    mDeepHistory.setHistory(deepHistory);
                }

                if (mShallowHistory != null) {
                    mShallowHistory.setHistory(mCurrentState);
                }
            }
        }

        mCurrentState.exit(triggerPacking, targetState);

        super.exitBegin(triggerPacking, targetState);
    }

    @Override
    final void childBecomeCurrent(SMStateVertexImp child) {
        mCurrentState = child;
        updateParentIBecomeCurrent();
    }
    //=======================================================================

    // ================ DOM support ===============================

    @Override
    public void writeBody(XMLContext xmlContext, Element myNode) {

        if (mInitialState != null) {

            String initialStateName;

            SMStateVertex i = mInitialState.debugGetTarget();

            if (i != null) {
                initialStateName = "" + i;
            } else {
                initialStateName = "???";
            }

            domBeginEndElemAttributeName(myNode, "InitialState", initialStateName);
        }

        super.writeBody(xmlContext, myNode);


    }


    @Override
    public String getElementName() {
        return "CompState";
    }

    // for debug only

    /**
     * All real and pseudo states
     */
    @Override
    public void debugAddAllStates(List<String> states) {
        super.debugAddAllStates(states);    //To change body of overridden methods use File | Settings | File Templates.

        if (mInitialState != null) {
            mInitialState.debugAddAllStates(states);
        }

    }

}