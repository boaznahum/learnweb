package wf.state_machine;

/**
 * !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 * !! This interface is not intended to be implemented by client code
 * !! SM FW assumes that only its internal implementation exists
 * !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 * @author Boaz Nahum
 */

public interface SMConcurrentState extends SMComplexState {

    /**
     * Add for in this concurrent state.
     * For may be later connected to inner regions.
     */
    SMStateVertex addFork(String name);

    /**
     * Add fork with default name "F*".
     * See {@link #addFork()}
     */
    SMStateVertex addFork();

    SMStateVertex addJoin(String name);

    /**
     * Add join with default name "J*"
     */
    SMStateVertex addJoin();
}
