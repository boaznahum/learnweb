package wf.state_machine;

import java.util.LinkedList;
import java.util.List;

final class SMConcurrentStateImp extends SMComplexStateImp implements SMConcurrentState {

    private final Fork mDummyForkForDeepHistory = addDummyForForHistory();


    SMConcurrentStateImp(SMComplexStateImp parent, String sid) {
        super(parent.getWorld(), parent, sid);
    }

    @Override
    final String getTypeName() {
        return "Concurrent SMState";
    }

    @Override
    final boolean isConcurrent() {
        return true;
    }

    private SMStateVertexImp findRegionInJoin(SMStateVertex region) {

        for (PseudoState pseudoState : mPseudoSubStates.getStates()) {

            if (pseudoState.isJoin()) {
                Join j = (Join)pseudoState;

                if (j.isRegionIn(region)) {
                    return j;
                }
            }
        }

        return null;
    }

    @Override
    SMStatePathTree getCurrentStatePathTree() {
        if (mCurrentState == null) {
            return null;
        }
        else if (mCurrentState.isPseudo() && mCurrentState.isFork()) {

            SMStatePathTree t = new SMStatePathTree(this, mCurrentState.getCurrentStatePathTree());

            return t;
        } else {
            StateVertexIDMap<? extends SMStateVertex> subStates = getSubStatesMap();

            SMStatePathTree t = new SMStatePathTree(this, subStates.size());

            int j = 0;
            for (SMStateVertexImp region : subStates.getStates()) {
                SMStateVertexImp join = findRegionInJoin(region);

                if (join != null) {
                    region = join;
                }

                t.setChildren(j, region.getCurrentStatePathTree());

                ++j;
            }

            return t;
        }
    }


    @Override
    SMStateVertexImp getDeepHistory() {
        mDummyForkForDeepHistory.clear();

        for (SMStateImp state : getSubStatesMap().getStates()) {

            // no ! we want to remember it history even if it was on join
            //if ( t.isActive() ) // maybe is in join
            {
                // if this returned null, then region is isn't final state
                SMStateVertexImp deepHistory = state.getDeepHistory();

                // maybe it is in is final state, so don't set it
                if (deepHistory != null) {
                    if (deepHistory.isJoin()) {
                        throw new SMDefinitionException("deepHistory.isJoin()");
                    }  // can't add transition into junction on the fly
                    mDummyForkForDeepHistory.addUTransition(null, deepHistory);
                }
            }
        }

        if (mDummyForkForDeepHistory.isEmpty()) {
            return null; // all regions are in their final state,
        }
        // so concurrent is also in it's final state
        else {
            return mDummyForkForDeepHistory;
        }
    }

    private Fork doAddFork(String name) {
        Fork fork = new Fork(this, name);

        addPseudoState(fork);

        return fork;
    }

    /**
     * Add for in this concurrent state.
     * For may be later connected to inner regions.
     */
    @Override
    public SMStateVertex addFork(String name) {
        return doAddFork(name);
    }

    /**
     * Add fork with default name "F*".
     * See {@link #addFork()}
     */
    @Override
    public SMStateVertex addFork() {
        return addFork(Fork.DEFAULT_NAME);
    }


    @Override
    public SMStateVertex addJoin(String name) {
        Join j = new Join(this, name);

        addPseudoState(j);

        return j;
    }

    /**
     * Add join with default name "J*"
     */
    @Override
    public SMStateVertex addJoin() {
        return addJoin(Join.DEFAULT_NAME);
    }

        //================================================================
    @Override
    protected void checkValid() {
        super.checkValid();
    }

    @Override
    protected void init() {
        super.init();
    }


    /**
     * return list of SMTransitionSegment if transition need to be handled by caller
     * return EMPTY_SEGMENT_LIST if transition was occurred, but was handled by state itself
     */
    @Override
    List<SMTransitionSegmentImp> processTrigger(TriggerPacking triggerPacking,
                                         SMStateVertex target,
                                         SMInternalTriggerData internalData,
                                         boolean myEvent) {

        if (myEvent) {
            target = null; // now it's my trigger and all my children
        }

        List<SMTransitionSegmentImp> l;

        boolean inStateTransitionOccurred = false;

        if (mCurrentState.isPseudo()) {
            //please note: join will be current
            // only its last entry is filled !!!

            l = mCurrentState.preAndProcessTrigger(triggerPacking, target, internalData);

            //noinspection ObjectEquality
            if (l == EMPTY_SEGMENT_LIST) {
                inStateTransitionOccurred = true;
            }
        } else {
            l = null;

            for (SMStateImp state : getSubStatesMap().getStates()) {

                if (!state.isActive()) // maybe it in join ?
                {
                    continue;
                }

                l = state.preAndProcessTrigger(triggerPacking, target, internalData);

                //noinspection ObjectEquality
                if (l == EMPTY_SEGMENT_LIST) {
                    inStateTransitionOccurred = true;
                } else if (l != null) {
                    // now check if it is in concurrent state (into join)
                    if (transitionCompletelyIn(l)) {
                        getWorld().processTransition(l);
                        //System.out.println("Internal transition handled by container state: " + this);
                        l = EMPTY_SEGMENT_LIST;
                        inStateTransitionOccurred = true;
                    } else {
                        return l; // transition outside of region, abort
                    }

                }
            }
        }

        if (inStateTransitionOccurred) {
            l = EMPTY_SEGMENT_LIST;
        }
        else if (myEvent) {
            l = super.processTrigger(triggerPacking, target, internalData, myEvent);
        }

        //noinspection ObjectEquality
        if (l != null && l != EMPTY_SEGMENT_LIST) // maybe a transition from fork into region
        {   // was not handled yet
            if (transitionCompletelyIn(l)) {
                getWorld().processTransition(l);
                //System.out.println("Internal transition handled by container state: " + this);
                l = EMPTY_SEGMENT_LIST;
            }
        }

        //noinspection ObjectEquality
        if (l == EMPTY_SEGMENT_LIST) {
            // event2transitions were occurred, and all were in this state
            // now check if there is final state transition

            Transitions finalTransition = getFinalTransitions();

            if (finalTransition != null && isInFinalState()) {
                LinkedList<SMTransitionSegmentImp> pathFromParent =
                        finalTransition.findPathThrough(null,
                                this,
                                triggerPacking);

                if (pathFromParent != null) {
                    l = pathFromParent;
                }
            }
        }

        return l;
    }

    // check to see if all regions are in final state
    @Override
    boolean isInFinalState() {

        for (SMStateImp region : getSubStatesMap().getStates()) {
            // make sure it is active, maybe we are on join !!!
            if (!region.isActive() || !region.isInFinalState()) {
                return false;
            }
        }

        return true;
    }

    // ============================================================================
    // state entry/exit

    /**
     * add to statesPath the list all states you enter, so caller can call
     * each enter_end
     */
    @Override
    LinkedList<SMStateVertexImp> enterBegin(SMStateImp beginOfPath,
                                            SMStateVertexImp innerTargetState,
                                            LinkedList<SMStateVertexImp> statesPath,
                                            SMStateVertexImp sourceState, // for debug
                                            TriggerPacking triggerPacking // for debug
                                        ) {
        statesPath = super.enterBegin(beginOfPath,
                innerTargetState,
                statesPath,
                sourceState,
                triggerPacking);

        //noinspection ObjectEquality
        if (innerTargetState == this) {
            innerTargetState = null;
        }

        if (innerTargetState != null && innerTargetState.isFork()) // check if this is a fork
        {
            // enter the fork
            innerTargetState.enterBegin(beginOfPath,
                    null,
                    statesPath,
                    sourceState,
                    triggerPacking);
        } else {

            for (SMStateImp state : getSubStatesMap().getStates()) {

                SMStateVertexImp tempTarget = innerTargetState;

                // if inner target is not is this region
                // then go to the edge
                if (tempTarget != null && !state.isStateContainsOrEq(tempTarget)) {
                    tempTarget = null;
                }

                statesPath = state.enterBegin(beginOfPath,
                                          tempTarget,
                                          statesPath,
                                          sourceState,
                                          triggerPacking);

                // well not actually true
                mCurrentState = state;
            }
        }

        return statesPath;
    }

    // please note ! enter_end is not recursive
    @Override
    void enterEnd(SMStateVertex sourceState, // for debug
                  TriggerPacking triggerPacking // for debug
                   ) {
        super.enterEnd(sourceState, triggerPacking);
    }

    @Override
    void exitBegin(TriggerPacking triggerPacking,
                    SMStateVertex targetState) {

        {
            // clear all active join 's

            for (PseudoState pseudoState : mPseudoSubStates.getStates()) {
                if (pseudoState.isJoin()) {
                    pseudoState.exit(triggerPacking, targetState);
                }
            }
        }

        {

            for (SMStateImp state : getSubStatesMap().getStates()) {

                if (state.isActive()) // maybe it in join
                {
                    state.exit(triggerPacking, targetState);
                }
            }
        }

        super.exitBegin(triggerPacking, targetState);
    }

    @Override
    void childBecomeCurrent(SMStateVertexImp child) {
        // please note, join will not call it, till all of it's
        //  entries are filled
        mCurrentState = child;
        updateParentIBecomeCurrent();
    }

    private Fork addDummyForForHistory() {

        Fork forkDummy = new DummyForkForHistory(this);

        addPseudoState(forkDummy);

        return forkDummy;
    }

    //=======================================================================


    // for debug only

    @Override
    public String getElementName() {
        return "ComplexState";
    }

}

