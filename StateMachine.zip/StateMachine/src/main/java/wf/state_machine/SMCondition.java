package wf.state_machine;

import org.jetbrains.annotations.Nullable;

/**
 * A binary guard.
 * It is a sugaring for creating 'nary transition with 2 branches.
 * See {@link #isTrue(SMTransitionGuardContext)}
 *
 * Usually you don't need it, use {@link SMGuard#binary0(String, SMBinaryPredicate0)} or
 * {@link SMGuard#binary1(String, SMBinaryPredicate)}
 *
 * @author Boaz Nahum
 * @version WI VX.6, V12.0X, ADC V0.95
 */

public abstract class SMCondition implements SMGuard, SMBinaryPredicate {

    @Override
    public final int select(SMTransitionGuardContext info) {
        if (isTrue(info)) {
            return 0; // select 'true target'
        } else {

            if (info.getN() == 1) {
                // no else branch
                return -1;
            } else {
                return 1; // select 'else branch'
            }
        }
    }

    /**
     * For plotters only
     */
    @Override
    @Nullable
    public String getName() {
        return null; // but you can override
    }

    @Override
    public String getBranchName(int numberOfBranches, int i) {

        if (i == 0) {
            // we don't name true branch
            return null;
        } else {
            return "else";
        }
    }

    /**
     * @return it true then transition 0 is taken
     * otherwise, this is unary transition then no transition is taken, if binary then transition 1 ('else') is taken
     */
    @Override
    public abstract boolean isTrue(SMTransitionGuardContext info);

    static SMGuard create(String name, SMBinaryPredicate0 predicate) {

        return new SMCondition() {
            @Override
            public boolean isTrue(SMTransitionGuardContext info) {
                return predicate.isTrue();

            }

            @Override
            public String getName() {
                return name;

            }
        };

    }
    static SMGuard create(String name, SMBinaryPredicate predicate) {

        return new SMCondition() {
            @Override
            public boolean isTrue(SMTransitionGuardContext info) {
                return predicate.isTrue(info);

            }

            @Override
            public String getName() {
                return name == null ? predicate.getName() : name;

            }
        };

    }

    public String toString() {
        String n = getName();
        if (n == null) {
            return super.toString();
        } else {
            return n;
        }
    }
}
