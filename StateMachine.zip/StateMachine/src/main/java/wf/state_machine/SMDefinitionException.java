package wf.state_machine;

/**
 * An exception that occurred  in process of state machine definition.
 */
class SMDefinitionException extends SMException {
    SMDefinitionException() {
    }

    SMDefinitionException(String message) {
        super(message);
    }

    SMDefinitionException(String message, Throwable cause) {
        super(message, cause);
    }

    SMDefinitionException(Throwable cause) {
        super(cause);
    }
}