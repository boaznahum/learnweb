package wf.state_machine;

import wf.state_machine.smlogger.SMLogEvent;

import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

class SMDelayedTriggersHandler extends BaseStateMachineElement {


    /**
     * Create on demand
     */
    private ScheduledExecutorService delayedTriggerService;


    SMDelayedTriggersHandler(StateMachineImp stateMachine) {
        super(stateMachine);

        delayedTriggerService = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "SM '" + sm().getName() + "' schedule triggers");
            t.setDaemon(true);
            return t;
        });

    }

    public void init() {
        if (delayedTriggerService != null) {
            delayedTriggerService.shutdownNow();

            try {
                delayedTriggerService.awaitTermination(Long.MAX_VALUE, TimeUnit.SECONDS);
            } catch (InterruptedException e) {
                throw new SMExecutionException(e);
            }

            delayedTriggerService = null;
        }

    }

    /**
     * Handle trigger in the future
     *
     * @param trigger
     * @param delay
     * @param timeUnit
     * @return a future to submit operation and not for the handling {@link CompletableFuture}
     * but cancel operation may cancel both submit and handling.
     * See discussion in {@link SMScheduledFutureTrigger#cancel(boolean)}
     */
    synchronized SMScheduledFutureTrigger scheduleTrigger(final SMUTrigger trigger, int delay,
                                                          TimeUnit timeUnit) {


        if (isLoggerOn()) {
            logEvent(
                SMLogEvent.MACHINE_SCHEDULING_TRIGGER,
                null,
                trigger,
                null);
        }


        if (delayedTriggerService == null) {

            delayedTriggerService = Executors.newSingleThreadScheduledExecutor(r -> {
                Thread t = new Thread(r, "SM '" + sm().getName() + "' schedule triggers");
                t.setDaemon(true);
                return t;
            });

        }

        final MySMTriggerCancellingHandler cancellingHandler = new MySMTriggerCancellingHandler(this, trigger);

        Future<?> delayedTrigger = delayedTriggerService.schedule(() -> {
            Future<Object> triggerHandlingFuture = sm().submitTrigger(trigger, null);
            cancellingHandler.setTriggerHandlingFuture(triggerHandlingFuture);
        }, delay, timeUnit);

        // actually this member must not be null, but we set it before escaping this scope
        cancellingHandler.setSubmitFuture(delayedTrigger);


        return cancellingHandler;
    }


    private static class MySMTriggerCancellingHandler extends BaseStateMachineElement implements SMScheduledFutureTrigger {

        /**
         * Trigger was submitted to state machine
         * Nullable
         */
        private Future<Object> triggerHandlingFuture;

        private boolean cancelHandling;

        /**
         * The future that is responsible for submitting the trigger to SM
         */
        private Future<?> submitFuture;

        // for logging
        private final SMBaseTrigger trigger;

        MySMTriggerCancellingHandler(BaseStateMachineElement stateMachine, SMBaseTrigger trigger) {
            super(stateMachine);
            this.trigger = trigger;
        }


        @Override
        public void cancel(boolean cancelEventIfAlreadySubmitted) {


            logEvent(SMLogEvent.MACHINE_CANCELING_SCHEDULED_TRIGGER, null, trigger, null);

            synchronized (this) {
                Objects.requireNonNull(submitFuture).cancel(false);

                if (cancelEventIfAlreadySubmitted) {
                    cancelHandling = true;

                    if (triggerHandlingFuture != null) {
                        triggerHandlingFuture.cancel(false);
                    }
                }
            }
        }

        public void setSubmitFuture(Future<?> submitFuture) {
            this.submitFuture = submitFuture;
        }

        synchronized void setTriggerHandlingFuture(Future<Object> triggerHandlingFuture) {

            this.triggerHandlingFuture = triggerHandlingFuture;

            if (cancelHandling) {
                // when event process will come to process trigger, it will ignore it
                triggerHandlingFuture.cancel(false);
            }


        }
    }
}
