package wf.state_machine;

/**
 * The data passed to {@link SMHandler}
 */
interface SMEventContext extends SMBaseHandlerContext {


    ///**
    // * the handler that was called.
    // * In user code, it will be usually 'this'
    // */
    //private SMHandler handler;
    //
    ///**
    // * handler list that contains this handler
    // */
    //private final HandlerList handlerListContainer;



    /**
     * The trigger that is handled and that cause this event
     */
    SMBaseTrigger getTrigger();

    /**
     * Get the user data that was passed along with {@link #getTrigger()}
     * when calling {@link StateMachine#handleTrigger(SMUTrigger, Object)}
     * or {@link StateMachine#submitTrigger(SMTrigger, Object)}
     */
    Object getTriggerData();


    //// remove this handler from the list that contains it and it is the source of this invocation
    //public final void cancelThis() {
    //    world.removeHandler(handlerListContainer, handler);
    //}

    //void setHandler(SMHandler handler) {
    //    this.handler = handler;
    //}





}

