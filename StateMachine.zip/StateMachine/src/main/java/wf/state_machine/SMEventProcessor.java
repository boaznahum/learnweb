package wf.state_machine;

import org.jetbrains.annotations.Nullable;
import wf.state_machine.smlogger.SMLogEvent;
import wf.state_machine.util.Pair;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * This class should be considered is inner private class of {@link StateMachine}
 *
 * //todo:boaz:fix: Need to add for each method in which context it should be executed:any,step, in-step
 *
 * @author Boaz Nahum
 * @version WI VX.6, V12.0X, ADC V0.95
 */

final class SMEventProcessor extends BaseStateMachineElement {


    //====================================================================
    // 'In step' queues
    // This queues are processed as part of one SM step

    /**
     * Queue of commands {@link InternalCommand}
     * This not need to be thread safe, because it is accessed only
     * from in step processing - adding and removing.
     * LinkedBlockingDeque has very bad performance
     */
    private final Deque<InternalCommand> inStepInternalCommandQueue =
        new LinkedList<>();

    /**
     * No need to be thread safe, because it manipulate only by {@link #currentMainOwner}
     */
    private final LinkedList<SMSystemTriggerPacking> inStepInternalSystemTriggerQueue =
        new LinkedList<>();


    ///**
    // * list of States to process local queue
    // * this is a LIFO, because we want inner states to processed
    // * before outer
    // * No need to be thread safe, because it manipulate only by {@link #currentMainOwner}
    // */
    //private final LinkedList<SMStateImp> inStepLocalStateTriggersQueues = new LinkedList<>();

    /**
     * Queue of triggers that are part of current step.
     */
    @Nullable
    private Queue<TriggerPacking> inStepTriggers;

    /**
     * Each trigger in this queue is one SM step.
     * We need it thread safe, because it is accessed outside the main loop.
     * Improve: In case threading model is {@link SMThreadingModel#Caller} then we pay
     * the price of blocking queue.
     */
    private final BlockingDeque<TriggerPacking> stepsTriggersQueue =
        new LinkedBlockingDeque<>();


    /**
     * Threading model can't be changed !!!
     */
    private final SMThreadingModel threadingModel;
    /**
     * To support {@link SMThreadingModel#SingleThread}
     */
    //private SingleThreadTask singleThread;
    // we need finalizer to terminate thread

    @SuppressWarnings({"FieldCanBeLocal", "UnusedDeclaration"})
    // this is finalizer, so ignore warning
    private SMFinalizer smFinalizer;

    /**
     * main lock, control these members.<br>
     * <ul>
     * <li> Adding and removing steps in main loop into/from {@link #stepsTriggersQueue}
     * <li> {@link #currentMainOwner}
     * At any given time, only one thread may own the state machine and process user and internal triggers.
     * </ul>
     */
    private final Lock mainLock = new ReentrantLock();
    private Thread currentMainOwner;

    private final AtomicInteger debugNumberOfReceivedTriggers = new AtomicInteger();
    private int debugNumberOfHandledTriggers;


    private static final SMCommandTrigger INIT_TRIGGER =
        createInitTriggerCommand();


    /**
     * Current step Data. This information is set/unset at begin/end of {@link #processOneStep(TriggerPacking)}
     */
    private Object currentStepUserData;
    private int currentStepNumber;


    SMEventProcessor(StateMachineImp stateMachine, SMThreadingModel threadingModel) {
        super(stateMachine);
        this.threadingModel = threadingModel;
    }


    /**
     * Start init process on caller thread and
     * finished it on SM thread.
     */
    final Future<Object> init() {

        checkAndCreateThread();

        resetAllQueues(); // remove any pending triggers


        // it is important to put it in head of queue, in case
        //  other 'step' actions entered till initImp() begin
        return submitStepTrigger(INIT_TRIGGER, null, true);

    }

    /**
     * Write statistics into System.out }
     */
    @SuppressWarnings({"UseOfSystemOutOrSystemErr"})
    void debugWriteStatistics() {

        System.out.println("Number of received triggers=" + debugNumberOfReceivedTriggers);
        System.out.println("Number of handled triggers=" + debugNumberOfHandledTriggers);
        System.out.println("Number of triggers in queue:" + stepsTriggersQueue.size());
    }

    /**
     * Return triggers in 'main' queue and in 'in step' queues.
     * Multi Threading: No side effects, but results may be undefined.
     * This also include triggers in {@link #inStepTriggers}
     */
    String[] debugGetTriggerQueue() {


        List<TriggerPacking> triggers = new ArrayList<>(stepsTriggersQueue);

        ArrayList<String> ss =
            new ArrayList<>(triggers.size() + ((inStepTriggers != null) ? inStepTriggers.size() : 0));

        if (inStepTriggers != null) {
            for (TriggerPacking t : inStepTriggers) {
                ss.add(t.getTriggerName());
            }
        }


        for (TriggerPacking t : triggers) {
            ss.add(t.getTriggerName());
        }

        return ss.toArray(new String[ss.size()]);
    }

    SMThreadingModel debugGetThreadingModel() {
        return threadingModel;
    }

    /**
     * Handle triggers that are auto generated, such as  {@link SMState#getEnterEvent()} and {@link SMState#getExitEvent()}.
     *
     * @param trigger
     */
    void handleAGTrigger(SMAGTrigger trigger) {

        handleInStepTrigger(trigger);
    }

    private void handleInStepTrigger(SMTrigger trigger) {

        ensureValidThreadInStepCall();

        if (inStepTriggers == null) {
            inStepTriggers = new LinkedList<>();
        }

        inStepTriggers.add(new TriggerPacking(trigger, currentStepUserData, null));

        if (isLoggerOn()) {
            logEvent(
                SMLogEvent.MACHINE_GOT_TRIGGER,
                null,
                trigger,
                null);
        }

    }

    void addStepCommand(boolean headOfQueue, final InternalCommand cmd) {

        SMCommandTrigger trigger = new SMCommandTrigger() {
            @Override
            public void run(StateMachineImp sm) {
                cmd.doIt();

            }

            @Override
            public String getName() {
                return "Command:" + cmd;
            }
        };

        TriggerPacking triggerPacking = new TriggerPacking(trigger, null, null);
        //SMStepTriggerPacking packing = new SMStepTriggerPacking(triggerPacking, null);

        addAndProcessStepsQueue(triggerPacking, headOfQueue);
    }


    /**
     * Must be called from within step processing
     * internal command processing.
     * See {@link #addInStepCommand(InternalCommand, boolean)}
     */
    void addInStepCommand(InternalCommand cmd) {
        addInStepCommand(cmd, false);
    }

    /**
     * Must be called from within step processing
     * Internal command are executing as part of current step -
     * before any other SM step.
     */
    private void addInStepCommand(InternalCommand cmd, boolean beginOfQueue) {

        // If not in step call, then it won't be processed
        ensureValidThreadInStepCall();

        if (beginOfQueue) {
            inStepInternalCommandQueue.addFirst(cmd);
        } else {
            inStepInternalCommandQueue.addLast(cmd);
        }
    }

    /**
     * @param id
     * @param target
     * @param internalData
     * @param beginOfQueue
     */
    final void addInternalSystemTrigger(SystemTrigger id,
                                        SMStateVertex target,
                                        SMInternalTriggerData internalData,
                                        boolean beginOfQueue) {

        // If not in step call, then it won't be processed
        ensureValidThreadInStepCall();

        SMSystemTriggerPacking ep = new SMSystemTriggerPacking(id,
                                                               target,
                                                               internalData);

        if (beginOfQueue) {
            inStepInternalSystemTriggerQueue.addFirst(ep);
        } else {
            inStepInternalSystemTriggerQueue.addLast(ep);
        }
    }

    void initImp() {

        // again, maybe queue filled since call to init()
        resetAllQueues(); // remove any pending triggers


        // initial state is top level state
        SMCompositeState topLevelState = getTopLevel();

        SMState savedCurrentState = topLevelState.getCurrentState();

        // we are logging transition between current state into top level state
        logEvent(
            SMLogEvent.START_OF_INIT_COMMAND_PROCESSING,
            savedCurrentState,
            (SMBaseTrigger)null,
            topLevelState);

        // state->enter will on exit restore to idle state
        getTopLevel().init();

        debugNumberOfReceivedTriggers.set(0);
        debugNumberOfHandledTriggers = 0;

        ///mInternalState = InternalState.E_INITIALIZING;

        getTopLevel().enter(
            null,
            null,
            null,
            new TriggerPacking(INIT_TRIGGER, null, null));

        //mInternalState = InternalState.E_IDLE;


        logEvent(
            SMLogEvent.END_OF_INIT_COMMAND_PROCESSING,
            savedCurrentState,
            (SMBaseTrigger)null,
            topLevelState);
    }

    private void resetAllQueues() {

        // why not just copy and cancel,
        // Because it might that between copy and cancellation another trigger will reached the queue
        // So to be on the safe side, we must prove that if trigger is removed from queue then
        // it is canceled
        TriggerPacking packing;
        while ((packing = stepsTriggersQueue.poll()) != null) {
            Future futureTask = packing.getFuture();
            if (futureTask != null) {
                futureTask.cancel(false);
            }
        }

        inStepInternalCommandQueue.clear();
        if (inStepTriggers != null) {
            inStepTriggers.clear();
        }
        getTopLevel().resetTriggerQueues();
    }

    private void ensureNoInStepCommandPending() {
        boolean isEmpty =
            inStepInternalCommandQueue.isEmpty() &&
            inStepInternalSystemTriggerQueue.isEmpty() &&
            //inStepLocalStateTriggersQueues.isEmpty() &&
            (inStepTriggers == null || inStepTriggers.isEmpty());

        if (!isEmpty) {
            throw new SMExecutionException("Pending 'in step' command are pending");
        }
    }

    private boolean inStepLoopProcessInternalCommand() {

        InternalCommand cmd;
        if ((cmd = inStepInternalCommandQueue.poll()) != null) {
            cmd.doIt();
            return true;
        } else {
            return false;
        }

    }

    private boolean inStepLoopProcessInternalTrigger() {

        SMSystemTriggerPacking systemTriggerPacking;

        if ((systemTriggerPacking = inStepInternalSystemTriggerQueue.pollFirst()) != null) { // process trigger
            processTrigger(systemTriggerPacking.getSystemTriggerPacking(),
                           systemTriggerPacking.getTarget(),
                           systemTriggerPacking.getInternalData());
            // continue - maybe this cause an command enter the queue
            return true;
        } else {
            return false;
        }
    }

    private boolean inStepLoopProcessStateLocalTriggers() {

        SMStatePathTree currentStatePathTree = getWorld().getLastKnownCurrentStatePathTree();

        if (currentStatePathTree == null) {
            return false;
        }

        /**
         * Why we calling it again and again and not keeping history of it ?
         * Because after we process a trigger - all the state machine can be changed
         * A current state is no longer current !
         */
        Pair<SMStateImp, TriggerPacking> p = currentStatePathTree.removeFromLocalQueue();

        if (p == null) {
            return false;
        }


        SMStateImp stateWithLocalEvents = p.getFirst();
        TriggerPacking trigger = p.getSecond();

        logEvent(
            SMLogEvent.PROCESSING_STATE_LOCAL_TRIGGER,
            stateWithLocalEvents,
            trigger,
            null);

        if (!stateWithLocalEvents.isActive()) {
            throw new SMExecutionException("Internal error. Processing local triggers on non active state");
        }

        processTrigger(trigger, stateWithLocalEvents, null);

        // call me gain, I may have more state to process
        return true;
    }

    /**
    private boolean inStepLoopProcessStateLocalTriggersOld() {

        SMStateImp stateWithLocalEvents;


        if ((stateWithLocalEvents = inStepLocalStateTriggersQueues.peekLast()) != null) {
            // this is LIFO
            // get but do not remove, maybe state local queue may has more events

            SMSMTriggerPackingConcurrentLinkedQueue localQueue = stateWithLocalEvents.getLocalTriggerQueue();

            TriggerPacking trigger = localQueue.poll();
            if (trigger == null) {
                // If this state has no more triggers then remove it from list of state that need processing
                // remove it from list and try the next state
                // we are removing not just for optimization, but that main loop can terminated
                // how can we sure that the last is still our state ? - because no one other
                // than main thread is manipulating this queue
                inStepLocalStateTriggersQueues.removeLast();
            } else {
                logEvent(
                    SMLogEvent.PROCESSING_STATE_LOCAL_TRIGGER,
                    stateWithLocalEvents,
                    trigger,
                    null);

                if (!stateWithLocalEvents.isActive()) {
                    throw new SMExecutionException("Internal error. Processing local triggers on non active state");
                }

                processTrigger(trigger, stateWithLocalEvents, null);
            }

            // call me gain, I may have more state to process
            return true;
        } else {
            return false;
        }
    }
     */

    /**
     * Process 'regular' triggers that are part of current step
     */
    private boolean inStepLoopTrigger() {

        if (inStepTriggers == null) {
            return false;
        }

        TriggerPacking trigger = inStepTriggers.poll();

        if (trigger != null) {
            processTrigger(trigger, null, null);
            return true;
        } else {
            return false;
        }
    }


    /**
     * In step loop. Execute:
     * 1. Internal commands
     * 2. Internal triggers.
     * 3. State local triggers
     * 4. In step triggers
     * <p/>
     * Process all commands that are part of the current step
     */
    private void processInStepCommands(int stepNumber) {

        while (true) {

            if (stepNumber != currentStepNumber) {
                throw new SMExecutionException("Step number changed during step execution");
            }

            // command has priority over triggers
            if (inStepLoopProcessInternalCommand()) {
                continue;
            }

            if (inStepLoopProcessInternalTrigger()) {
                continue;
            }

            if (inStepLoopProcessStateLocalTriggers()) {
                continue;
            }

            if (inStepLoopTrigger()) {
                continue;
            }


            break; // all queues are empty, can exit main loop
        }
    }


    /**
     * Handle trigger as one step.
     */
    Future<Object> submitStepTrigger(SMBaseTrigger trigger,
                                     @Nullable Object userData,
                                     boolean headOfQueue) {

        CompletableFuture<Object> future = new CompletableFuture<>();
        submitStepTrigger(trigger, userData, future, headOfQueue);

        return future;
    }

    /**
     * Handle trigger as one step.
     */
    private void submitStepTrigger(SMBaseTrigger trigger,
                                   @Nullable Object userData,
                                   @Nullable CompletableFuture<Object> future,
                                   boolean headOfQueue) {

        TriggerPacking triggerPacking = new TriggerPacking(trigger, userData, future);

//        SMStepTriggerPacking packing = new SMStepTriggerPacking(triggerPacking, future);

        debugNumberOfReceivedTriggers.incrementAndGet();

        if (isLoggerOn()) {
            logEvent(
                SMLogEvent.MACHINE_GOT_TRIGGER,
                null,
                trigger,
                null);
        }

        addAndProcessStepsQueue(triggerPacking, headOfQueue);
    }

    private void addAndProcessStepsQueue(TriggerPacking packing, boolean headOfQueue) {

        mainLock.lock();
        try {

            //Although this is thread safe queue, we adding it in mainLock.
            // Assume that adding and removing was outside of main lock, then:
            //  1. One come with step to execute
            //  2  Put it in queue outside lock
            //  3  It check for busy, and find it to be true, so it quit
            //  4  But the thread that is supposed to be busy, just quit
            if (headOfQueue) {
                stepsTriggersQueue.addFirst(packing);
            } else {
                stepsTriggersQueue.add(packing);
            }

            /**
             * Always true when threading model is {@link SMThreadingModel#SingleThread}
             * and work will be done by {@link SingleThreadTask}
             */
            if (isBusy()) {
                return;     // other one is busy doing the work
            }

            // now I'm busy - i will process all 'step triggers' till queue is empty
            currentMainOwner = Thread.currentThread();

            try {
                TriggerPacking triggerPacking; // user trigger
                while ((triggerPacking = stepsTriggersQueue.poll()) != null) {
                    mainLock.unlock();
                    try {
                        processOneStep(triggerPacking);
                    } finally {
                        mainLock.lock();
                    }
                }
            } finally {
                currentMainOwner = null;
            }
        } finally {
            mainLock.unlock();
        }
    }


    /**
     * Context: Any
     * <p>
     * Currently I don't know how to handle it:
     * 1.  In case of {@link wf.state_machine.SMThreadingModel#SingleThread} it may be easy,
     * the first caller will get the exception, buy how do we know that the caller is not itself async thread ?
     * 2.  in case of single {@link wf.state_machine.SMThreadingModel#Caller}  wh have the same problem and we should
     * detect that the caller is not nested ?
     * <p>
     * meanwhile we will wrote it as a warning
     *
     * @param e
     */
    void handleAsyncError(Throwable e) {

        //noinspection SSBasedInspection
        new RuntimeException("Found error on async action", e).printStackTrace();
    }


    /**
     * Process one step of state machine.
     *
     * @param stepTriggerPacking
     */
    private void processOneStep(TriggerPacking stepTriggerPacking) {

        ensureValidThreadInStepCall();

        ensureNoInStepCommandPending();

        int savedStepNumber = ++currentStepNumber;
        currentStepUserData = stepTriggerPacking.getUserData();
        CompletableFuture<Object> futureTask;

        try {
            // this queue is thread safe
            // process trigger
            futureTask = stepTriggerPacking.getFuture();
            try {

                SMBaseTrigger trigger = stepTriggerPacking.getTrigger();


                // is canceled
                if (futureTask != null && futureTask.isCancelled()) {

                    logEvent(
                        SMLogEvent.MACHINE_IGNORING_CANCELED_TRIGGER,
                        null,
                        stepTriggerPacking,
                        getLastKnownCurrentState());

                } else {
                    if (trigger instanceof SMCommandTrigger) {
                        ((SMCommandTrigger)trigger).run(sm());
                    } else {
                        ++debugNumberOfHandledTriggers;
                        processTrigger(stepTriggerPacking, null, null);
                    }

                    processInStepCommands(savedStepNumber);

                }

            } catch (Error e) {
                if (futureTask != null) {
                    futureTask.completeExceptionally(e);
                }
                throw e;
            }
        } finally {
            // reset current step information
            currentStepUserData = null;
        }

        if (futureTask != null) {
            futureTask.complete(null);
        }
    }


    private void processTrigger(TriggerPacking triggerPacking,
                                SMStateVertex target,
                                SMInternalTriggerData internalData) {

        boolean debuggerIsOn = isLoggerOn();

        SMStateVertex stateOnStart = null;

        if (debuggerIsOn) {

            stateOnStart = getLastKnownCurrentState();

            logEvent(
                SMLogEvent.MACHINE_START_PROCESSING_TRIGGER,
                stateOnStart,
                triggerPacking,
                null);
        }

        if (triggerPacking == null) {
            throw new SMDefinitionException("trigger==null");
        }


        List<SMTransitionSegmentImp> l = getTopLevel().preAndProcessTrigger(triggerPacking, target, internalData);

        //noinspection ObjectEquality
        if (l != null && l != SMStateVertexImp.EMPTY_SEGMENT_LIST) {
            processTransition(l);
        }


        if (debuggerIsOn) {
            logEvent(
                SMLogEvent.MACHINE_END_PROCESSING_TRIGGER,
                stateOnStart,
                triggerPacking,
                getLastKnownCurrentState());
        }
    }

    /**
     * return last state
     */
    void processTransition(List<SMTransitionSegmentImp> l) {

        if (l != null) {
            boolean debuggerIsOn = isLoggerOn();

            SMTransitionSegmentImp segment = l.get(0);
            SMStateImp beginOfPath = segment.getBeginOfPath();

            if (debuggerIsOn) {
                getLogger().beginTransitionsSegments(SMLogEvent.START_OF_SEGMENTS_PROCESSING, sm(), l);
            }

            for (Object aL : l) {
                segment = (SMTransitionSegmentImp)aL;

                processTransitionSegment(
                    beginOfPath,
                    segment);
            }

            if (debuggerIsOn) {
                logEvent(
                    SMLogEvent.END_OF_SEGMENTS_PROCESSING,
                    beginOfPath,
                    (SMBaseTrigger)null,
                    null);
            }

        }
    }

    private void processTransitionSegment(SMStateImp beginOfPath, // begin of path must be SMState
                                          SMTransitionSegmentImp segment) {
        final boolean debuggerIsOn = isLoggerOn();

        SMStateVertexImp source = segment.getSourceInternal();

        SMStateVertexImp target = segment.getTargetInternal();
        TriggerPacking triggerPacking = segment.getTriggerPacking();

        if (debuggerIsOn) {
            logEvent(
                SMLogEvent.START_OF_TRANSITION,
                source,
                triggerPacking,
                target);
        }


        SMStateVertexImp stateToExit =
            SMStateVertexImp.findTopMostStateToExit(source, target);

        stateToExit.exit(
            triggerPacking,
            target);

        // now process transition

        if (segment.transitionHandlersExists()) {
            if (debuggerIsOn) {
                logEvent(
                    SMLogEvent.BEGIN_TRANSITION_HANDLERS,
                    source,
                    triggerPacking,
                    target);
            }

            segment.executeTransitionHandlers(sm());

            if (debuggerIsOn) {
                logEvent(
                    SMLogEvent.END_TRANSITION_HANDLERS,
                    source,
                    triggerPacking,
                    target);
            }
        }

        SMStateVertexImp stateToEnter =
            SMStateVertexImp.findTopMostStateToEnter(
                stateToExit,
                target);

        stateToEnter.enter(
            beginOfPath,
            target,
            source,
            triggerPacking);

        if (segment.endTransitionHandlersExists()) {
            if (debuggerIsOn) {
                logEvent(
                    SMLogEvent.BEGIN_END_TRANSITION_HANDLERS,
                    source,
                    triggerPacking,
                    target);
            }

            segment.executeEndTransitionHandlers(sm());

            if (debuggerIsOn) {
                logEvent(
                    SMLogEvent.END_END_TRANSITION_HANDLERS,
                    source,
                    triggerPacking,
                    target);
            }
        }

        if (debuggerIsOn) {
            logEvent(
                SMLogEvent.END_OF_TRANSITION,
                source,
                triggerPacking,
                target);
        }


    }

    /**
     * Mark state has having local triggers in queue, and process them if not busy.
     * state mus be active.
     *
     * @param state
     */
    void addStateLocalTriggerQueueXXX(final SMStateImp state) {

        if (!state.isActive()) {
            throw new SMExecutionException("Only active thread can ask to process local events");
        }


        /** We found a bug, we can submit events to state from threads that are not running
         // from internal SM processing (such as async actions)
         // We try to fix it by re implement
         { @lin SMStateImp#wf.state_machine.SMStateImp#addToLocalEventQueueInternal(wf.state_machine.TriggerPacking, boolean)} as
         step
         */
        InternalCommand cmd = new InternalCommand() {
            @Override
            public void doIt() {
                //if (!inStepLocalStateTriggersQueues.contains(state)) {
                //    // LIFO
                //    inStepLocalStateTriggersQueues.addFirst(state); // to the end of the list
                //}
            }

            // part of new code
            @Override
            public String toString() {
                return "Add state '" + state + "' + to 'inStepLocalStateTriggersQueues'";

            }
        };


        //The old code:
        // this will do two things:
        // execute the command
        //  begin the execution loop
        addInStepCommand(cmd);
    }


    /**
     * Ensure that:
     * SM is busy executing step.
     * Call is made from the thread that is executing the current step.
     */
    void ensureValidThreadInStepCall() {
        //noinspection ObjectEquality
        if (currentMainOwner != Thread.currentThread()) {
            throw new SMExecutionException("Internal SW error:Current thread does not own state machine.");
        }
    }

    /**
     * Return true is SM is busy executing step.
     * See {@link #ensureValidThreadInStepCall()}
     */
    boolean isBusy() {
        // is any one is working here ...
        return currentMainOwner != null;
    }


    private SMCompositeStateImp getTopLevel() {
        return sm().getTopLevelInternal();
    }

    /**
     * Multi Threading: No side effects. But result may be transient.
     */
    private final SMState getLastKnownCurrentState() {
        return getTopLevel().getCurrentState();
    }


    //private final void logEvent(SMLogEvent logEvent,
    //                            SMStateVertex source,
    //                            SMBaseTrigger trigger,
    //                            SMStateVertex target) {
    //    sm.logEvent(logEvent, source, trigger, target);
    //}


    private void checkAndCreateThread() {

        if (threadingModel == SMThreadingModel.SingleThread && currentMainOwner == null) {
            SingleThreadTask task = new SingleThreadTask(this);

            // for ever !!!
            currentMainOwner = new Thread(task);
            currentMainOwner.setDaemon(true);
            currentMainOwner.start();

            smFinalizer = new SMFinalizer(task);
        }
    }


    private static class SMFinalizer {

        private final SingleThreadTask singleThreadTask;

        SMFinalizer(SingleThreadTask singleThreadTask) {
            this.singleThreadTask = singleThreadTask;
        }

        @Override
        protected void finalize() throws Throwable {
            super.finalize();
            singleThreadTask.terminate();
        }
    }

    /**
     * Must be static, we don't want to hold strong reference to StateMachine
     */
    @SuppressWarnings({"SSBasedInspection", "CallToPrintStackTrace"})
    private static class SingleThreadTask implements Runnable {

        // We hold reference to fields in SM and not to SM itself
        // so that SM can be released by gC !!!
        private final WeakReference<SMEventProcessor> myStateMachineRef;
        private volatile boolean terminated;
        private final BlockingQueue<TriggerPacking> stepsTriggersQueue;

        private static final TriggerPacking TERMINATE_COMMAND =
            new TriggerPacking(SMUTrigger.create("-Dummy-thread-termination-packing"), null, null);


        private SingleThreadTask(SMEventProcessor myStateMachine) {
            myStateMachineRef = new WeakReference<>(myStateMachine);
            stepsTriggersQueue = myStateMachine.stepsTriggersQueue;
        }

        @Override
        public void run() {

            if (setThreadName()) {
                return;
            }

            while (!terminated) {

                TriggerPacking triggerPacking = null;
                try {
                    triggerPacking = stepsTriggersQueue.take();
                } catch (InterruptedException ignore) {
                }

                if (terminated) {
                    break;
                }

                // we never throw exception
                tryRunProcessStep(triggerPacking);
            }
        }

        private void tryRunProcessStep(TriggerPacking triggerPacking) {
            try {
                processStep(triggerPacking);
            } catch (Throwable e) {
                e.printStackTrace();
                // and we continue
            }
        }

        /**
         * This method also set terminated  to true if SM was released.
         * Must be called in smMainLock lock
         */
        private SMEventProcessor checkAndGetSM() {

            SMEventProcessor sm = myStateMachineRef.get();
            if (sm == null) {
                terminated = true;
                return null;
            }

            return sm;
        }


        /**
         * Return true if terminated
         */
        private boolean setThreadName() {

            // must be enclosed in scope !!! otherwise strong reference
            // will be held
            SMEventProcessor sm = checkAndGetSM();
            if (sm == null) {
                return true;
            }
            Thread.currentThread().setName("State Machine event queue:" + sm.sm().getName());
            return false;
        }

        private void processStep(TriggerPacking triggerPacking) {
            SMEventProcessor sm = checkAndGetSM();
            if (sm == null) {
                return;
            }
            sm.processOneStep(triggerPacking);
        }

        public void terminate() {
            terminated = true;
            stepsTriggersQueue.add(TERMINATE_COMMAND);
        }
    }

    private static SMCommandTrigger createInitTriggerCommand() {
        return new SMCommandTrigger() {
            @Override
            public void run(StateMachineImp sm) {
                sm.initImp();
            }

            @Override
            public String getName() {
                return "$Init$";

            }
        };
    }


}
