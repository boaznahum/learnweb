package wf.state_machine;

/**
 * An exception that occurred while state machine is running.
 * This is usually because of SW bug.
 *
 */
class SMException extends RuntimeException {
    SMException() {
    }

    SMException(String message) {
        super(message);
    }

    SMException(String message, Throwable cause) {
        super(message, cause);
    }

    SMException(Throwable cause) {
        super(cause);
    }
}