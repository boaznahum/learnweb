package wf.state_machine;

/**
 * An exception that occurred while state machine is running.
 * This is usually because of SW bug.
 *
 */
class SMExecutionException extends SMException {
    SMExecutionException() {
    }

    SMExecutionException(String message) {
        super(message);
    }

    SMExecutionException(String message, Throwable cause) {
        super(message, cause);
    }

    SMExecutionException(Throwable cause) {
        super(cause);
    }
}