package wf.state_machine;

import org.jetbrains.annotations.Nullable;

import java.util.concurrent.Future;

/**
 * !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 * !! This interface is not intended to be implemented by client code
 * !! SM FW assumes that only its internal implementation exists
 * !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 *
 * @author Boaz Nahum
 */

public interface SMGlobalContext {


    void handleTrigger(SMUTrigger trigger);

    boolean userMsgLoggingIsOn();

    void logUserMsg(String msg);

    StateMachine sm();

    /**
     * Clear the SM global user data.
     * This is the user data of {@link StateMachine#getTopLevel()}
     */
    void clearUserData();

    /**
     * get the SM global user data.
     * This is the user data of {@link StateMachine#getTopLevel()}
     */
    SMUserData getUserData();

    /**
     * See {@link StateMachine#runAsync(SMEventContext, boolean, SMUTrigger, SMUTrigger, SMUTrigger, SMSimpleHandler)}
     */
    void runSync(SMEventContext context, @Nullable SMUTrigger successTrigger,
                 @Nullable SMUTrigger failureTrigger,
                 SMSimpleHandler action);

    /**
     * See {@link StateMachine#runAsync(SMEventContext, boolean, SMUTrigger, SMUTrigger, SMUTrigger, SMSimpleHandler)}
     */
    Future<Void> runAsync(SMEventContext context, boolean cancelByInterrupt, @Nullable SMUTrigger successTrigger,
                          @Nullable SMUTrigger failureTrigger, SMUTrigger cancelingTrigger, SMSimpleHandler action);


}
