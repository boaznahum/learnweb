package wf.state_machine;

import org.jetbrains.annotations.Nullable;

import java.util.concurrent.Future;

/**
 * The context in which {@link SMHandler is executed}
 *
 * This is SM global context,
 * it doesn't contain specific event info such as trigger and source state as in{@link SMEventContext}
 *
 * This is singleton per SM {@link StateMachineImp#getContext()}
 *
 */

final class SMGlobalContextImp implements SMGlobalContext {


    private final StateMachineImp world;

    SMGlobalContextImp(StateMachineImp world) {
        //this.handlerListContainer = handlerListContainer;
        this.world = world;
    }



    @Override
    public void handleTrigger(SMUTrigger trigger) {
        world.handleTrigger(trigger);
    }


    @Override
    public final boolean userMsgLoggingIsOn() {
        return world.isUserMsgLoggingIsOn();
    }

    @Override
    public final void logUserMsg(String msg) {
        world.logUserMsg(msg);
    }


    @Override
    public StateMachine sm() {
        return world;
    }



    /**
     * Clear the SM global user data.
     * This is the user data of {@link StateMachine#getTopLevel()}
     */
    @Override
    public void clearUserData() {
        sm().getTopLevel().clearUserData();
    }

    /**
     * get the SM global user data.
     * This is the user data of {@link StateMachine#getTopLevel()}
     */
    @Override
    public SMUserData getUserData() {
        return sm().getTopLevel().getUserData();
    }

    @Override
    public void runSync(SMEventContext context, @Nullable SMUTrigger successTrigger,
                        @Nullable SMUTrigger failureTrigger,
                        SMSimpleHandler action) {


        world.runSync(context, successTrigger, failureTrigger, action);


    }

    @Override
    public Future<Void> runAsync(SMEventContext context, boolean cancelByInterrupt, @Nullable SMUTrigger successTrigger,
                                 @Nullable SMUTrigger failureTrigger, SMUTrigger cancelingTrigger,
                                 SMSimpleHandler action) {

        return world.runAsync(context,
                              cancelByInterrupt,
                              successTrigger, failureTrigger, cancelingTrigger,
                              action);
    }


    StateMachineImp smInternal() {
        return world;
    }




}
