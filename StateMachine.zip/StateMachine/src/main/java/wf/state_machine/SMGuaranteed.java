package wf.state_machine;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Put this annotation on {@link SMGuard#select(SMTransitionGuardContext)}
 * to inform that is guaranteed to always select a branch
 */
@Retention(RetentionPolicy.RUNTIME)
public @interface SMGuaranteed {
}
