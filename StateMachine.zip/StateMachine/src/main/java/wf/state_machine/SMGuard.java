package wf.state_machine;

import org.jetbrains.annotations.Nullable;

import java.lang.reflect.Method;

@FunctionalInterface
public interface SMGuard {


    //===================================================
    // Some factory methods

    /**
     * A a very simple binary guard {@link SMCondition} that accept no parameters
     * @param name will appears in debugger and logs
     * @param predicate
     */
    static SMGuard binary0(@Nullable String name, SMBinaryPredicate0 predicate) {
        return SMCondition.create(name, predicate);

    }
    /**
     * A binary guard {@link SMCondition} that accept only {@link SMTransitionGuardContext}
     * @param name will appears in debugger and logs
     * @param predicate
     */
    static SMGuard binary1(@Nullable String name, SMBinaryPredicate predicate) {
        return SMCondition.create(name, predicate);

    }


    /**
     * Select a branch in transition.<br>
     * Return -1 if no branch should taken.
     * If the return value is >= getN() then exception is thrown.
     *
     * Must return 0..N-1 if it is guaranteed {@link SMGuaranteed}
     *
     * Implementation notes: If you change signature of this method then please also fix {@link MyMethod}
     * @return return value must be negative or in range [0..N-1], where N is number of branches.
     */

    int select(SMTransitionGuardContext info);


    /**
     * For plotters only
     */
    @Nullable
    default String getName() { return null; }

    /**
     * For plotters only
     */
    @Nullable
    default String getBranchName(int numberOfBranches, int i) {
        return "" + i;
    }

    class MyMethod {

        private MyMethod() {}

        static Method getSelect(SMGuard guard) throws NoSuchMethodException {

            Class<? extends SMGuard> aClass = guard.getClass();

            return aClass.getMethod("select", SMTransitionGuardContext.class);
        }
    }


}

