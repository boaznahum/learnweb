package wf.state_machine;

interface SMHandler {

}


