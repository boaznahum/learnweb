package wf.state_machine;

import org.jetbrains.annotations.Nullable;

import java.util.concurrent.Future;

/**
 * @author Boaz Nahum
 */

interface SMHandlerContext extends SMEventContext {


    /**
     * Only relevant for asynchronous handlers,
     * See {@link SMState#betweenEntryExitDo(boolean, boolean, SMUTrigger, SMUTrigger, SMUTrigger, SMStateHandler)}
     * See {@link SMGlobalContext#runAsync(SMEventContext, boolean, SMUTrigger, SMUTrigger, SMUTrigger, SMSimpleHandler)}
     *
     * @return true if asynchronous handler was canceled
     */
    boolean isCanceled();

    /**
     * Sugaring over {@link #getGlobalContext()}
     *
     * @param trigger
     */
    default void handleTrigger(SMUTrigger trigger) {
        getGlobalContext().handleTrigger(trigger);
    }

    /**
     * Sugaring over {@link #getGlobalContext()}
     * See {@link StateMachine#runAsync(SMEventContext, boolean, SMUTrigger, SMUTrigger, SMUTrigger, SMSimpleHandler)}
     */
    void runSync(SMEventContext context, @Nullable SMUTrigger successTrigger,
                 @Nullable SMUTrigger failureTrigger,
                 SMSimpleHandler action);

    /**
     * Sugaring over {@link #getGlobalContext()}
     * See {@link StateMachine#runAsync(SMEventContext, boolean, SMUTrigger, SMUTrigger, SMUTrigger, SMSimpleHandler)}
     */
    Future<Void> runAsync(SMEventContext context, boolean cancelByInterrupt, @Nullable SMUTrigger successTrigger,
                          @Nullable SMUTrigger failureTrigger, SMUTrigger cancelingTrigger, SMSimpleHandler action);

}
