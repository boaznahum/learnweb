package wf.state_machine;

import java.util.function.Supplier;

/**
 * @author Boaz Nahum
 */

interface SMHandlerExecutor<H extends SMHandler, I extends SMHandlerContext> {

    /**
     * Must not called directly,
     * only via {@link HandlerList#execute(StateMachineImp, Supplier, SMHandlerExecutor)}
     *
     * @param eventContext
     * @param eventInfo
     * @param handler
     */
    void execute(SMGlobalContext eventContext, I eventInfo, H handler);
}
