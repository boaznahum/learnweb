package wf.state_machine;

import org.jetbrains.annotations.Nullable;
import wf.state_machine.outputers.DOMHelper;
import wf.state_machine.outputers.dot.DotContext;
import wf.state_machine.outputers.XMLContext;
import wf.state_machine.outputers.XMLWriteable;
import org.w3c.dom.Element;

import java.util.LinkedList;

//todo:boaz:tmpcode: convert to class
public class SMHistory extends PseudoState implements XMLWriteable {

    /**
     * If history exists then when reaching history pseudo state
     * a transition is made from history state to the 'memorized' state.
     */

    private final MemoryUnaryTransition historyTransition;

    /**
     * In case history was not memorized, then user can define a transitions
     * with trigger (but with guards).
     * Create on demand 
     */
    @Nullable
    private Transitions otherTransitions;

    private final boolean mIsDeep;

    SMHistory(boolean isDeepHistory,
              SMCompositeStateImp parent,
              String sid) {
        super(parent, sid);

        historyTransition = SMTransitionImp.createMemoryUnaryTransition(getWorld());
        
        mIsDeep = isDeepHistory;
    }

    /**
     * The transition that occurred when returning to state and state has history.
     * User uses this method so he can add handlers to history transition.
     */
    public SMTransition getHistoryTransition() {
        return historyTransition;
    }

    @Override
    final String getTypeName() {
        return (mIsDeep ? "Deep" : "Shallow") + " SMHistory";
    }

    void clearHistory() {
        // see this.Guard.select
        historyTransition.setTarget(0, null);
    }

    void setHistory(SMStateVertexImp s) {
        // see this.Guard.select
        historyTransition.setTarget(0, s);
    }

    @Override
    protected void init() {
        super.init();

        clearHistory();
        /**
         /* todo: init {@link #historyTransition}
         */
        historyTransition.init();
        if (otherTransitions != null) {
            otherTransitions.init();
        }

    }

    @Override
    protected void checkValid() {
        super.checkValid();

        checkHasAtLeastOneGuaranteedTransition(otherTransitions);

        checkTargetIsInParent(otherTransitions);

        historyTransition.checkValid();
        if (otherTransitions != null) {
            otherTransitions.checkValid();
        }
    }

    @Override
    SMTransition addOutgoingTransition(SMBaseTrigger trigger, SMTransitionImp t) {
        super.addOutgoingTransition(trigger, t);

        if (otherTransitions == null) {
            otherTransitions = new Transitions(getWorld());
        }
        otherTransitions.add(t);

        return t;
    }


    /**
     * find a path to destination target
     * return a list of Transition Segment
     * if return null then no path trough this state
     */
    @Override
    LinkedList<SMTransitionSegmentImp> findPathThrough(LinkedList<SMTransitionSegmentImp> pathSoFar,
                                                    SMStateImp beginOfPath,
                                                    SMStateVertex source,
                                                    TriggerPacking triggerPacking) {
        // has history ?
        if (historyTransition.getBranchTarget(0) != null) {

            return historyTransition.findPathThrough(pathSoFar,
                    beginOfPath,
                    this,
                    triggerPacking);
        } else {
            if (otherTransitions != null) {
                return otherTransitions.findPathThrough(pathSoFar, beginOfPath, this, triggerPacking);
            } else {
                return null;
            }
        }
    }

    @Override
    boolean possiblyImpassable() {
        return false;
    }

    // ================ DOM support ===============================

    @Override
    public String getElementName() {
        return mIsDeep ? "DeepHistory" : "ShallowHistory";
    }

    @Override
    public void writeBody(XMLContext xmlContext, Element inNode) {

        super.writeBody(xmlContext, inNode);

        DOMHelper.addAndWrite(xmlContext, historyTransition, inNode, "history_transition");

        if (otherTransitions != null) {
            DOMHelper.addAndWrite(xmlContext, otherTransitions, inNode, "other_transitions");
        }

        writeDotData(xmlContext, inNode);


    }

    // DOT support

    private void writeDotData(XMLContext xmlContext, Element inNode) {

        /**
         * {@link historyTransition} are not written, because they are not permanent histograms
         */
        if (otherTransitions != null) {
            otherTransitions.writeDotData(xmlContext, inNode, this, null);
        }
    }

//    String getDotLabel() {
//        return ""; // we draw label above point
//    }


    @Override
    protected String getDotNoneComplexModeAttributes(DotContext dotContext) {
        String s1 = super.getDotNoneComplexModeAttributes(dotContext);

        String s2 = "shape=box, " + // minimal
                "width=0.0, height=0.0," +
                "toplabel=" + DotContext.quoteLabel(getDefaultDotLabel());


        return DotContext.concatenateAttributes(s1, s2);
    }


}
