package wf.state_machine;

/**
 * @author Boaz Nahum
 * @version WI VX.6, V12.0X, ADC V0.95
 */

class SMInternalTriggerData {


    /**
     * The original step trigger that this system trigger contained in
     */
    private final TriggerPacking stepTriggerPacking;


    SMInternalTriggerData(TriggerPacking stepTriggerPacking) {
        this.stepTriggerPacking = stepTriggerPacking;
    }


    /**
     * The real trigger.
     * The original step trigger that this system trigger contained in
     */
    final TriggerPacking getStepTrigger() {
        return stepTriggerPacking;
    }
}
