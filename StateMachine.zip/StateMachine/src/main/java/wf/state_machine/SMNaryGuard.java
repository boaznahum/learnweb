package wf.state_machine;

/**
 * @author Boaz Nahum
 * @version WI VX.6, V12.0X, ADC V0.95
 */

public abstract class SMNaryGuard implements SMGuard {

    @Override
    public String getName() {
        return null; // but you can override
    }

    @Override
    public String getBranchName(int numberOfBranches, int i) {
        return "" + i;
    }

    @Override
    public String toString() {
        String n = getName();
        if (n == null) {
            return super.toString();
        } else {
            return n;
        }
    }

}
