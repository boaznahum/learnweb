package wf.state_machine;

import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * @author Boaz Nahum
 * @version WI VX.6, V12.0X, ADC V0.95
 */

final class SMSMTriggerPackingConcurrentLinkedQueue extends ConcurrentLinkedQueue<TriggerPacking> {

    public boolean containsTrigger(SMBaseTrigger o) {
        return contains(o);


    }


}
