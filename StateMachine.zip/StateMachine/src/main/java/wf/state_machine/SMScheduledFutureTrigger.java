package wf.state_machine;

/**
 * When trigger is scheduled {@link StateMachine#scheduleTrigger(SMUTrigger, int, java.util.concurrent.TimeUnit)}
 * then this is future to the submit operation.
 *
 *
 * @author Boaz Nahum
 */

public interface SMScheduledFutureTrigger {

    /**
     * When scheduling a trigger, we actually scheduling a operation that will submit the trigger.
     * When coming to cancel a trigger we need to ask a (very difficult to answer question) -
     * do we want to cancel the trigger if it is already submitted ?
     * <p/>
     * Why canceling the submit-operation is not enough.
     * Suppose that we scheduled a trigger at sate entry and we want to cancel it on
     * state exit. So we do it in entry/exit handlers.
     * Now assume also that we have a long exit handler before the exit handler that do the cancellation,
     * so the trigger is submitted before we have the chance to cancel it - what is the required behaviour ?
     * <p/>
     * Do we want to cancel it or not ? It depends on the scenario.
     * It this example, logically if exit start we want to cancel the trigger in any case.
     * For example, if trigger is 'time-out' that causes an exit then sure we want to cancel it even
     * even if it already submitted, so it won't cause exit from other states.
     * <p/>
     * To avoid this confusing, it is the best not play with cancellation, let SM handle the events -
     * use different event for different states.
     *
     * @param cancelEventIfAlreadySubmitted if true, trigger will be canceled even if already submitted to SM
     */
    void cancel(boolean cancelEventIfAlreadySubmitted);
}
