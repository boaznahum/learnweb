package wf.state_machine;

/**
 * A callable like {@link java.util.concurrent.Callable} with is not associated  with specific action type {@link SMStateHandler}
 * or {@link SMTransitionHandler}
 * @author Boaz Nahum
 */

public interface SMSimpleHandler extends SMHandler {

    /**
     * @throws Exception
     */
    void handle(SMSimpleHandlerContext i) throws Exception;

}
