package wf.state_machine;

/**
 * @author Boaz Nahum
 */

public interface SMSimpleHandlerContext extends SMHandlerContext {
}
