package wf.state_machine;

/**
 * Date: Mar 9, 2005
 *
 * @author Boaz Nahum
 */
class SMSimpleTrigger implements SMUTrigger {
    private final String mName;

    SMSimpleTrigger(String name) {
        mName = name;
    }

    @Override
    public final String getName() {
        return mName;
    }


    /**
     * Two events are equal if and only if they are same object
     */
    @Override
    public final boolean equals(Object obj) {
        return super.equals(obj);
    }

    /**
     * Two events are equal if and only if they are same object
     */
    @Override
    public final int hashCode() {
        return super.hashCode();
    }

    @Override
    public final String toString() {
        return getName();
    }
}
