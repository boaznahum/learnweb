package wf.state_machine;


import org.jetbrains.annotations.Nullable;

import java.util.concurrent.TimeUnit;

/**
 * !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 * !! This interface is not intended to be implemented by client code
 * !! SM FW assumes that only its internal implementation exists
 * !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 *
 * @author Boaz Nahum
 */
public interface SMState extends SMStateVertex {

    /**
     * Define complex ('and') trigger for this state
     * when all triggers in 'andTrigger' are arrived to state
     * they will be considered as one trigger 'compositeTrigger'
     * <B>all events are cleared when leaving state</B>
     * <B>compositeTrigger and the components of andTrigger must be first declared using {@link StateMachine#defineTriggers(SMUTrigger...)}
     * <p/>
     * Usually you can use the simpler form of this method {@link #defineAndTrigger(SMTrigger, SMTrigger, SMTrigger...)},
     * but in case you need to use andTrigger more than once then once, then you need to use this method.
     * <p/>
     *
     * @param andTrigger See {@link SMTriggersAnd} how to get instance of it
     * See {@link _CheckList.KnownIssue1}
     */
    void defineAndTrigger(SMTrigger compositeTrigger, SMTriggersAnd andTrigger);

    /**
     * See {@link #defineAndTrigger(SMTrigger, SMTriggersAnd)}
     */
    @SuppressWarnings({"OverloadedVarargsMethod"})
    SMTriggersAnd defineAndTrigger(SMTrigger compositeTrigger, SMTrigger and1, SMTrigger... andOthers);

    /**
     * Use this to define return transitions.
     * The way you do it is:
     * <pre>
     *         SMTransition tr = s1.addTransition(
     * MyEvents.e2,
     * s1.getReturnPoint());
     * <p/>
     * </pre>
     * Every state has a memory of the last transition source - The state from where it was reached.
     *
     * Pseudo sates link {@link SMCompositeState#addTransition(SMBaseTrigger, SMGuard, SMStateVertex, SMStateVertex...)}
     * are not memorized
     *
     * When transition defined from s1 to 'return point' it is like a
     * transition from s1 to it's memorized entry state.
     * If s1 still not memorized any state(It was entered from initial state) then no transition is make.
     *
     * In this case you can add transitions to s1 that will be checked after the 'return' transition.
     * See ExampleReturnPoint:
     * <pre>
           sS.addTransition(T.R, sS.getReturnPoint());
           // add default transition - in case state not yet memorized source state
           sS.addTransition(T.R, sNR);
     * </pre>
     */
    SMStateVertex getReturnPoint();


    /**
     * See {@link #onStateDo(SMStateHandler)} for order of handlers.
     */
    void onEntryDo(SMStateHandler h);

    /**
     * please note that this handler is called twice, when activity begin
     * and when activity end.
     * When we enter to inner state of composite state, for example from A to D
     * <pre>
     *  *                               -------------------------------
     *                                  | B                           |
     *                                  |   -----------------------   |
     *                                  |   |C                    |   |
     *          ---------------         |   |       -----------   |   |
     *          |      A      |----E1-------------->|   D     |   |   |
     *          ---------------         |   |       -----------   |   |
     *                  ^               |   ------------ | --------   |
     *                  |               ---------------- | ------------
     *                  |                                |
     *                  E3                               E2
     *                  |                                |
     *                  |                                V
     *                  |                            ----------
     *                  -----------------------------|   E    |
     *                                               ----------
     * </pre>
     * Then 'begin' activity are called only after (entry handler) when reach the inner state and the order is
     * from the inner to the outer.
     * When we exit state then first 'end' activity are called
     * So in the example above, the handlers are called in this order:
     * <pre>
     * On trigger E1:
     *  End_A,
     *  Exit_A,
     * <p/>
     *  Enter_B,
     *    Enter_C,
     *      Enter_D,
     *      Begin_D,
     *    Begin_C,
     *  Begin_B,
     * <p/>
     * On E2 trigger:
     *  End_D,
     *  Exit_D,
     *  End_C,
     *  Exit_C,
     *  End_B,
     *  Exit_B
     * </pre>
     * Enter_E,
     * Begin_E
     * Task: Can I explain the asymmetric between enter sequence and exit sequence. Need/Can I fix it ?
     */
    void onStateDo(SMStateHandler h);

    /**
     * See {@link #onStateDo(SMStateHandler)} for order of handlers.
     */
    void onExitDo(SMStateHandler h);

    /**
     * todo:boaz:fix: Add more accurate document - when exactly it is called.
     * Handle triggers when they are processed by state.
     * This 'Transition' is called internal, because its execution does not cause any transition.
     * Also note 'On State' handlers of this state are not executed.
     *
     * @param trigger
     * @param h
     */
    void onTriggerDo(SMTrigger trigger,
                     SMStateHandler h);

    /**
     * Add entry handler.
     * <p>
     * This handler is executed on state enter.
     * If operation succeeded then trigger {@code successTrigger} if not null
     * otherwise, trigger {@code failTrigger} if not null or {@code successTrigger} if not null
     *
     * See {@link StateMachine#runAsync(SMEventContext, boolean, SMUTrigger, SMUTrigger, SMUTrigger, SMSimpleHandler)}
     *
     * <p>
     * if {@code async} is true then this handler is executed asynchronously,
     * and on exit it is canceled {@link java.util.concurrent.Future#cancel(boolean)}
     * You can check for {@link SMHandlerContext#isCanceled()} or if {@code cancelByInterrupt} is true you can check {@link Thread#isInterrupted()}
     * So in case of async action it can be infinite action and you can check for cancellation
     *
     *
     *
     * @param async run handler on different thread, in this case SM FW will try to cancel it.
     * @param cancelByInterrupt in case {@code async} is true, SM FW will try to cancel thread that is running the handler by {@link Thread#interrupt()}
     * @param successTrigger If operation succeeded then trigger {@code successTrigger} if not null
     * @param failureTrigger If operation failed, trigger {@code failTrigger} if not null or {@code successTrigger} if not null
     * @param cancelingTrigger see {@link StateMachine#runAsync(SMEventContext, boolean, SMUTrigger, SMUTrigger, SMUTrigger, SMSimpleHandler)}
     * @param h
     */
    void betweenEntryExitDo(boolean async,
                            boolean cancelByInterrupt,
                            @Nullable SMUTrigger successTrigger,
                            @Nullable SMUTrigger failureTrigger,
                            @Nullable SMUTrigger cancelingTrigger,
                            SMStateHandler h);

    /**
     * Get in_(), See David Harel
     * This condition is true when state is active
     */
    SMCondition getIsIn();

    /**
     * Get en_(), See David Harel
     * This trigger is fired when we enter state, just before handling handlers
     */
    SMTrigger getEnterEvent();

    /**
     * Get ex_(), See David Harel
     * This trigger is fired when we exit state, just before handling handlers
     */
    SMTrigger getExitEvent();

    /**
     * See {@link StateMachine#scheduleTrigger(SMUTrigger, int, TimeUnit)}
     * <p>
     * See discussion in {@link SMScheduledFutureTrigger#cancel(boolean)}
     * <p>
     * Schedule event on entry and cancel it on exit.
     * The event is not specific to this state, it is added to State-Machine and may be handled by
     * other states as well
     *
     * @param trigger
     */
    void scheduleTriggerOnEntry(SMUTrigger trigger, int delay, TimeUnit timeUnit);

    /**
     * Add a trigger to local state queue
     * If state is currently active, then trigger will be processed the moment
     * state machine will return to it's loop but before any other event from the main queue
     * So for example:
     *     If you submit(from nested operation) to state machine an event that will cause it to exit from state
     *     And then submit second event to local queue, the second event will be processed before the first
     *     one if state is active
     * <pre>
         processing.onEntryDo(c->{
             c.handleTrigger(T.EXIT);
             // Will this event be handled, although we have EXIT on Queue ?
             ((SMState)c.getThisState()).addToLocalEventQueue(T.INTERNAL);
         });
     * </pre>
     *
     * If state is not active, then trigger will be processed next time state is entered
     * (after state enter, and 'do activity' handlers)
     * Is state is complex state, then trigger will be processed by sub states too.
     * <b>all events are removed from local queue when state is exited, even if not processed</b>
     *
     * This is similar to David Harel 'broad casting', with one big different, the event/trigger is kept in state queue
     * till state become active.
     * If the target state is always active concurrent state that the effect is the same
     *
     * @return true if state was added
     */
    void addToLocalEventQueue(SMTrigger trigger);

    /**
     * See {@link #addToLocalEventQueue(SMTrigger)}
     *  @param trigger
     * @param userData
     */
    void addToLocalEventQueue(SMTrigger trigger, Object userData);

}
