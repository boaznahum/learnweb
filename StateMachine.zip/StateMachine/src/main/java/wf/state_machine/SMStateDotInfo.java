package wf.state_machine;

/**
 * @author Boaz Nahum
 * @version WI VX.6, V12.0X, ADC V0.95
 */

public class SMStateDotInfo {

    // may be different from the state we draw
    private final SMStateVertexImp state;

    private final String typeAndDotName;
    private final String dotName;

    /**
     * If true, then this is a fake info of the original state
     */
    private final boolean isFake;

    SMStateDotInfo(SMStateVertexImp state, String typeAndDotName, String dotName, boolean isFake) {
        this.state = state;
        this.typeAndDotName = typeAndDotName;
        this.dotName = dotName;
        this.isFake = isFake;
    }


    public SMStateVertex getState() {
        return state;
    }

    public SMStateVertexImp getStateInternal() {
        return state;
    }

    public String getTypeAndDotName() {
        return typeAndDotName;
    }

    public String getDotName() {
        return dotName;
    }

    public boolean isComplex() {
        if (isFake) {
            // we assume we always fake as simple node
            return false;
        } else {
            return state.isComplex();
        }
    }

    public String getDotNameAsSourceOfTransition(SMStateDotInfo target) {

        if (isFake  || target.isFake) {
            return dotName;
        } else {
            return state.getDotNameAsSourceOfTransition(target.state);
        }
    }


    public String getDotNameAsTargetOfTransition(SMStateDotInfo source) {

        if (isFake || source.isFake) {
            return dotName;
        } else {
            return state.getDotNameAsTargetOfTransition(source.state);
        }
    }

    public boolean isFake() {
        return isFake;
    }

    public String toString() {
        if (isFake) {
            return "Fake of:" + state  + ", " + dotName;
        } else {
            return state + ", " + dotName; 
        }
    }
}
