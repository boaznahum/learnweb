package wf.state_machine;


/**
 * State Handler is added by using these methods:
 * {@link SMState#onEntryDo(wf.state_machine.SMStateHandler)}
 * {@link SMState#onStateDo(wf.state_machine.SMStateHandler)}
 * {@link SMState#onExitDo(wf.state_machine.SMStateHandler)}
 * {@link SMState#onTriggerDo(wf.state_machine.SMTrigger, wf.state_machine.SMStateHandler)}
 *
 */
@FunctionalInterface
public interface SMStateHandler extends SMHandler {

    /**
     * This method must not be called directly, Only via {@link SMStateHandlerExecutor}
     * @param c
     */

    void handle(SMStateHandlerContext c) throws Exception;
}
