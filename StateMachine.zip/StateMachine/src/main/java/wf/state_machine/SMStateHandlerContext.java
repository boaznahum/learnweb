package wf.state_machine;

/**
 * @author Boaz Nahum
* @version x.5
*/
public interface SMStateHandlerContext extends SMHandlerContext {

    SMStateHandlerType getType();

    SMStateVertex getThisState();

    /**
     * Not always valid
     */
    SMStateVertex getSource();

    @Override
    SMBaseTrigger getTrigger();

    /**
     * Get the user data that was passed along with {@link #getTrigger()}
     * when calling {@link StateMachine#handleTrigger(SMUTrigger, Object)}
     * or {@link StateMachine#submitTrigger(SMTrigger, Object)}
     */
    @Override
    Object getTriggerData();


    /**
     * Not always valid
     */
    SMStateVertex getTarget();
}
