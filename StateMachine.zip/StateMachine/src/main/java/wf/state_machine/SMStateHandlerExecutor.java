package wf.state_machine;

final class SMStateHandlerExecutor implements SMHandlerExecutor<SMStateHandler, SMStateHandlerContext> {

    private static SMStateHandlerExecutor mInstance;

    private SMStateHandlerExecutor() {
    }

    static SMStateHandlerExecutor get() {
        // no need to be thread safe, nothing wrong if create more than once
        if (mInstance == null) {
            mInstance = new SMStateHandlerExecutor();
        }

        return mInstance;
    }

    @Override
    public void execute(SMGlobalContext eventContext, SMStateHandlerContext eventInfo, SMStateHandler handler) {
        try {
            handler.handle(eventInfo);
        } catch (Exception e) {
            throw new RuntimeException(e);

        }
    }
}

