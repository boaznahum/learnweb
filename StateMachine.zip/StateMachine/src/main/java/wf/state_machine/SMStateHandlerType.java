package wf.state_machine;

/**
 * Which type of event occurred and passed to {@link SMStateHandler}
 * @author Boaz Nahum
* @version x.5
*/
public enum SMStateHandlerType {

    /**
     * See {@link SMState#onEntryDo(SMStateHandler)}
     */
    ENTRY,

    /**
     * See {@link SMState#onStateDo(SMStateHandler)}
     */
    BEGIN_STATE_ACTIVITY,

    /**
     * See {@link SMState#onStateDo(SMStateHandler)}
     */
    TERMINATE_STATE_ACTIVITY,

    /**
     * See {@link SMState#onExitDo(SMStateHandler)}
     */
    EXIT,

    /**
     * See {@link SMState#onTriggerDo(SMTrigger, SMStateHandler)}
     */
    INTERNAL_TRANSITION
}
