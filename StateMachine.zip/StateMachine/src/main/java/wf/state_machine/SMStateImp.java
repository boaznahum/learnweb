package wf.state_machine;

import org.jetbrains.annotations.Nullable;
import org.w3c.dom.Element;
import wf.state_machine.outputers.DOMHelper;
import wf.state_machine.outputers.XMLContext;
import wf.state_machine.smlogger.SMLogEvent;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;

@SuppressWarnings({"ClassReferencesSubclass"})
abstract class SMStateImp extends SMStateVertexImp implements SMState {


    // and event manipulation - created on demand
    private TriggerQueue mAndTriggerQueue;
    /**
     * See {@link Trigger2AndDefinitionMap}
     */
    private Trigger2AndDefinitionMap andsTriggerDefinition;


    /**
     * regular transitions
     * Nullable
     */
    @Nullable
    private Event2TransitionsMap event2transitions;

    // for 'return point'
    private SMBaseTrigger mEntryTrigger;
    private SMStateImp mSourceState;

    // create on demand
    private StateHandlerList mEntryHandlers;
    private StateHandlerList mDoActivityHandlers;
    private StateHandlerList mExitHandlers;

    // create on demand
    private InternalTransitionMap mInternalTransitionHandlers;

    /**
     * // create on demand
     * We need it thread safe, because triggers are added to queue by any thread {@link #addToLocalEventQueueInternal(TriggerPacking, boolean)}
     * and are removed by {@link SMEventProcessor}
     */
    private SMSMTriggerPackingConcurrentLinkedQueue localTriggerQueue;


    /**
     * in_(S), See David Harel
     */
    private SMCondition inCondition;

    /**
     * en_(S), See David Harel
     * This trigger is fired when we enter state, just before handling handlers
     */
    private SMAGTrigger enterEvent;

    /**
     * ex_(S), See David Harel
     * This trigger is fired when we exit state, just before handling handlers
     */
    private SMAGTrigger exitEvent;


    SMStateImp(StateMachineImp world, SMComplexStateImp parent, String sid) {
        super(world, parent, sid);
    }


    // ====================================================================

    //=======================================================================

    /**
     * Define complex ('and') trigger for this state
     * when all triggers in 'andComponents' are arrived to state
     * they will be considered as one trigger 'compositeTrigger'
     * <B>all events are cleared when leaving state</B>
     * <B>compositeTrigger and the components of andComponents must be first declared using {@link StateMachine#defineTriggers(SMUTrigger...)}
     * <p/>
     * Usually you can use the simpler form of this method {@link #defineAndTrigger(SMTrigger, SMTrigger, SMTrigger...)},
     * but in case you need to use andComponents more than once then once, then you need to use this method.
     * <p/>
     * See {@link _CheckList.KnownIssue1}
     */

    @Override
    public void defineAndTrigger(SMTrigger compositeTrigger, SMTriggersAnd andTrigger) {

        SMTriggersAndImp andComponents = (SMTriggersAndImp)andTrigger;

        defineAndTriggerImp(compositeTrigger, andComponents);

    }

    /**
     * // create on demand
     * We need it thread safe, because triggers are added to queue by any thread {@link #addToLocalEventQueueInternal(TriggerPacking, boolean)}
     * and are removed by {@link SMEventProcessor}
     */
    @Nullable
    final SMSMTriggerPackingConcurrentLinkedQueue getLocalTriggerQueue() {
        return localTriggerQueue;
    }



    private void defineAndTriggerImp(SMTrigger compositeTrigger, SMTriggersAndImp andComponents) {
        legalTriggerAssert(compositeTrigger);

        SMTriggersAnd found = null;

        if (andsTriggerDefinition != null) {
            found = andsTriggerDefinition.find(compositeTrigger);
        } else {
            andsTriggerDefinition = new Trigger2AndDefinitionMap();
        }

        if (found != null) // multiple definition
        {
            throw new SMDefinitionException("In state '" + this + "', 'and' event " +
                                            compositeTrigger + " is already defined as " +
                                            found);
        } else {
            for (SMTrigger andComponent : andComponents.parts()) {
                legalTriggerAssert(andComponent);
                checkEventIsLegalCandidatePartOfComplexEvent(andComponent);
            }

            andsTriggerDefinition.insert(compositeTrigger, andComponents);
        }

    }

    /**
     * See {@link #defineAndTrigger(SMTrigger, SMTriggersAnd)}
     */
    @Override
    @SuppressWarnings({"OverloadedVarargsMethod"})
    public SMTriggersAnd defineAndTrigger(SMTrigger compositeTrigger, SMTrigger and1, SMTrigger... andOthers) {

        SMTriggersAndImp and = new SMTriggersAndImp(and1, andOthers);

        defineAndTriggerImp(compositeTrigger, and);

        return and;
    }

    /**
     * Use this to define return transitions.
     * The way you do it is:
     * <pre>
     *         SMTransition tr = s1.addTransition(
     * MyEvents.e2,
     * s1.getReturnPoint());
     * <p/>
     * </pre>
     * Every state has a memory of the last transition source - The state from where it was reached.
     * When transition defined from s1 to 'return point' it is like a
     * transition from s1 to it's memorized entry state.
     * If s1 still not memorized any state(It was entered from initial state) then no transition is make.
     * In this case you can add transitions to s1 that will be checked after the 'return' transition.
     * See ExampleReturnPoint
     */
    @Override
    public SMStateVertex getReturnPoint() {
        // this is not recursion.
        //noinspection TailRecursion
        return getWorld().getTopLevel().getReturnPoint();
    }



    // ====================================================================
    // Add state handlers

    /**
     * See {@link #onStateDo(SMStateHandler)} for order of handlers.
     */
    @Override
    public final void onEntryDo(final SMStateHandler h) {
        InternalCommand cmd = () -> addEntryHandlerImp(h);

        getWorld().addStepCommand(cmd);
    }

    /**
     * please note that this handler is called twice, when activity begin
     * and when activity end.
     * When we enter to inner state of composite state, for example from A to D
     * <pre>
     *  *                               -------------------------------
     *                                  | B                           |
     *                                  |   -----------------------   |
     *                                  |   |C                    |   |
     *          ---------------         |   |       -----------   |   |
     *          |      A      |----E1-------------->|   D     |   |   |
     *          ---------------         |   |       -----------   |   |
     *                  ^               |   ------------ | --------   |
     *                  |               ---------------- | ------------
     *                  |                                |
     *                  E3                               E2
     *                  |                                |
     *                  |                                V
     *                  |                            ----------
     *                  -----------------------------|   E    |
     *                                               ----------
     * </pre>
     * Then 'begin' activity are called only after (entry handler) when reach the inner state and the order is
     * from the inner to the outer.
     * When we exit state then first 'end' activity are called
     * So in the example above, the handlers are called in this order:
     * <pre>
     * On trigger E1:
     *  End_A,
     *  Exit_A,
     * <p/>
     *  Enter_B,
     *  Enter_C,
     *  Enter_D,
     *  Begin_D,
     *  Begin_C,
     *  Begin_B,
     * <p/>
     * On E2 trigger:
     *  End_D,
     *  Exit_D,
     *  End_C,
     *  Exit_C,
     *  End_B,
     *  Exit_B
     * </pre>
     * Enter_E,
     * Begin_E
     * Task: Can I explain the asymmetric between enter sequence and exit sequence. Need/Can I fix it ?
     */
    @Override
    public final void onStateDo(final SMStateHandler h) {
        InternalCommand cmd = () -> addDoActivityHandlerImp(h);
        getWorld().addStepCommand(cmd);
    }


    /**
     * See {@link #onStateDo(SMStateHandler)} for order of handlers.
     */
    @Override
    public final void onExitDo(final SMStateHandler h) {
        InternalCommand cmd = () -> addExitHandlerImp(h);
        getWorld().addStepCommand(cmd);
    }


    /**
     * todo:boaz:fix: Add more accurate document - when exactly it is called.
     * Handle triggers when they are processed by state.
     * This 'Transition' is called internal, because its execution does not cause any transition.
     * Also note 'On State' handlers of this state are not executed.
     *
     * @param trigger
     * @param h
     */
    @Override
    public final void onTriggerDo(final SMTrigger trigger,
                                  final SMStateHandler h) {
        legalTriggerAssert(trigger);

        InternalCommand cmd = () -> addInternalTransitionHandlerImp(trigger, h);

        getWorld().addStepCommand(cmd);
    }

    @Override
    public void betweenEntryExitDo(boolean async,
                                   boolean cancelByInterrupt,
                                   @Nullable SMUTrigger successTrigger,
                                   @Nullable SMUTrigger failureTrigger,
                                   @Nullable SMUTrigger cancelingTrigger,
                                   SMStateHandler h) {


        legalTriggerAssertNullable(successTrigger, failureTrigger, cancelingTrigger);

        // due to implementation limitation, the cancel work all on
        // executed handlers so far
        // to not make thing worse, don't share this handler between states
        // other may be create instance of SMStateHandlerContext per execution
        // but still we have no way how to connect between the entry execution and the exit
        AsyncStateHandler doingHandler =
            new AsyncStateHandler(async, cancelByInterrupt, successTrigger, failureTrigger, cancelingTrigger, h);

        onEntryDo(doingHandler);


        // //todo:boaz:fix: We have bug here,
        // If from sync action an operation on SM will cause to exit state (for example trigger action or local trigger in sttae)
        //  Then the exit handler will be invoked before async operation is completed
        // and it will be canceled - it is not a probelm if it is the last operation to executed
        if (async) {
            onExitDo(i -> doingHandler.cancel());
        }


    }
    // ====================================================================

    //public final String[] getEventsName(SMBaseTrigger[] triggers) {
    //    String[] nms = new String[triggers.length];
    //    for (int i = 0; i < triggers.length; ++i) {
    //        nms[i] = triggers[i].toString();
    //    }
    //    return nms;
    //}

    /**
     * Get in_(), See David Harel
     * This condition is true when state is active
     */
    @Override
    public SMCondition getIsIn() {
        if (inCondition == null) {
            inCondition = new StateInCondition();
        }

        return inCondition;
    }

    /**
     * Get en_(), See David Harel
     * This trigger is fired when we enter state, just before handling handlers
     */
    @Override
    public SMTrigger getEnterEvent() {
        if (enterEvent == null) {
            enterEvent = () -> "en_(" + SMStateImp.this.getName() + ")";
        }

        return enterEvent;
    }

    /**
     * Get ex_(), See David Harel
     * This trigger is fired when we exit state, just before handling handlers
     */
    @Override
    public SMTrigger getExitEvent() {
        if (exitEvent == null) {
            exitEvent = () -> "ex_(" + SMStateImp.this.getName() + ")";
        }

        return exitEvent;
    }


    /**
     * See {@link wf.state_machine.StateMachine#scheduleTrigger(SMUTrigger, int, TimeUnit)}
     * <p>
     * See discussion in {@link SMScheduledFutureTrigger#cancel(boolean)}
     * <p>
     * Schedule event on entry and cancel it on exit.
     * The event is not specific to this state, it is added to State-Machine and may be handled by
     * other states as well
     *
     * @param trigger
     */
    @Override
    public void scheduleTriggerOnEntry(final SMUTrigger trigger, final int delay, final TimeUnit timeUnit) {

        SMStateHandler h = new SMStateHandler() {

            private SMScheduledFutureTrigger cancelingHandler;

            @Override
            public void handle(SMStateHandlerContext i) throws Exception {

                if (i.getType() == SMStateHandlerType.ENTRY) {

                    cancelingHandler = ((SMGlobalContextImp)i.getGlobalContext()).smInternal()
                        .scheduleTrigger(trigger, delay, timeUnit);
                } else {
                    if (cancelingHandler != null) {
                        cancelingHandler.cancel(true);
                    }
                }
            }
        };
        onEntryDo(h);

        onExitDo(h);


    }


    @Override
    SMStateImp getRealState() {
        return this;
    }

    SMState getCurrentStateDeep() {
        return this;
    }


    @Override
    protected void checkValid() {
        super.checkValid();
    }

    @Override
    void init() {
        super.init();

        if (event2transitions != null) {
            event2transitions.smInit();
        }

        // we should do it - because maybe user add
        //  events to local queue after it ask for init from handler
        //  and event queue should be cleared when entering state
        //  local event queue on exit
        //resetEventQueuesThisOnly();

        mEntryTrigger = null;
        mSourceState = null;


    }

    private void checkEventIsLegalCandidatePartOfComplexEvent(SMTrigger eventID) {

        // if it is null it will be checked in SMTriggersAnd ctor
        if (eventID != null) {
            SMBaseTrigger complexTrigger = isPartOfComplexAndEvent(eventID);
            if (complexTrigger != null) {
                throw new SMDefinitionException("In state '" + this + "', event " +
                                                eventID + " is already part of 'and' event:" + complexTrigger);
            }
        }
    }

/*    final Trigger2AndDefinitionMap andsEventDefinition()
    {
        return getRoot().andsTriggerDefinition;
    }
*/

    //protected final boolean isComplexAndEvent(SMTrigger triggerID) {
    //    return
    //            andsTriggerDefinition != null &&
    //            andsTriggerDefinition.find(triggerID) != null;
    //}

    private SMTrigger isPartOfComplexAndEvent(SMTrigger event) {
        if (andsTriggerDefinition == null) {
            return null;
        } else {
            return andsTriggerDefinition.isPartOfComplexAndEvent(event);
        }
    }

    //final boolean isEventInComplexAndEvent(SMTrigger complexEvent, SMTrigger event) {
    //    // if we reach here, then andsTriggerDefinition is not null
    //    return andsTriggerDefinition.isEventInComplexAndEvent(complexEvent, event);
    //}

    private SMTrigger completeAndEvent() {
        // if we reach here, then andsTriggerDefinition is not null
        return andsTriggerDefinition.completeAndEventInQueue(mAndTriggerQueue);
    }

    private void removeAndEventsFromAndQueue(SMTrigger complexTrigger) {
        andsTriggerDefinition.removeAndEventsFromQueue(mAndTriggerQueue, complexTrigger);
    }


    //=======================================================================
    // events

    private void clearAndEventsQueue() {
        if (mAndTriggerQueue != null) {
            mAndTriggerQueue.clear();
        }

    }

    private void resetEventQueuesThisOnly() {
        if (localTriggerQueue != null) {
            localTriggerQueue.clear();
        }

        clearAndEventsQueue();

    }

    /**
     * this is not final because composite state need to reset all
     * its children
     */
    void resetTriggerQueues() {
        resetEventQueuesThisOnly();
    }

    private void legalTriggerAssert(SMBaseTrigger eid) {
        getWorld().legalTriggerAssert(eid);
    }

    private void legalTriggerAssertNullable(@Nullable SMUTrigger... ts) {
        getWorld().legalTriggerAssertNullable(ts);
    }


    //=======================================================================
    // transition definition

    final Transitions findTransitions(SMBaseTrigger triggerTrigger) {
        if (event2transitions == null) {
            return null;
        } else {
            return event2transitions.find(triggerTrigger);
        }
    }

    //=======================================================================
    // transition definition


    private void checkIsNotNullTrigger(SMBaseTrigger trigger) {
        if (trigger == null) {
            throw new SMDefinitionException("In " +
                                            getTypeAndName() +
                                            ", outgoing transition must have trigger");
        }
    }

    @Override
    SMTransition addOutgoingTransition(SMBaseTrigger trigger, SMTransitionImp t) {
        checkIsNotNullTrigger(trigger);

        legalTriggerAssert(trigger);

        // OK, it is valid to add more than one transition per event
//        if (findTransitions(trigger) != null)
//            throw new SMDefinitionException("In state '" + this + "', there is already transition with trigger '" +
//                    trigger + "'");

        setModified();

        if (event2transitions == null) {
            event2transitions = new Event2TransitionsMap();
        }
        event2transitions.add(trigger, t);

        return t;
    }


    private void addEntryHandlerImp(SMStateHandler h) {
        setModified();

        mEntryHandlers =
            StateHandlerList.add(mEntryHandlers, h);
    }

    private void addDoActivityHandlerImp(SMStateHandler h) {
        setModified();

        mDoActivityHandlers =
            StateHandlerList.add(mDoActivityHandlers, h);
    }

    private void addExitHandlerImp(SMStateHandler h) {
        setModified();

        mExitHandlers =
            StateHandlerList.add(mExitHandlers, h);
    }

    private void addInternalTransitionHandlerImp(SMBaseTrigger triggerTrigger,
                                                 SMStateHandler h) {
        setModified();

        if (mInternalTransitionHandlers == null) {
            mInternalTransitionHandlers = new InternalTransitionMap();
        }

        mInternalTransitionHandlers.add(triggerTrigger, h);
    }

    // ============================================================================


    // state entry/exit

    private void executeStateHandlers(StateHandlerList handlers,
                                      final SMStateVertex source,
                                      final TriggerPacking triggerPacking,
                                      final SMStateVertex target,
                                      final SMStateHandlerType type) {

        if (handlers.isEmpty()) {
            return;
        }

        Supplier<SMStateHandlerContext> sa =
            () -> new StateHandlerContextImpl(getGlobalContext(), this, type, source, triggerPacking, target);

        handlers.execute(getWorld(), sa);
    }

    @Override
    LinkedList<SMStateVertexImp> enterBegin(SMStateImp beginOfPath,
                                            SMStateVertexImp targetState,
                                            LinkedList<SMStateVertexImp> statesPath,
                                            SMStateVertexImp sourceState, // for debug
                                            TriggerPacking triggerPacking) {

        statesPath = super.enterBegin(beginOfPath,
                                      targetState,
                                      statesPath,
                                      sourceState,
                                      triggerPacking);

        clearAndEventsQueue();

        mEntryTrigger = triggerPacking.getTrigger();
        mSourceState = beginOfPath;

        if (enterEvent != null) {
            getWorld().handleAGTrigger(enterEvent);
        }

        if (/* triggerTrigger != StateMachine.INIT_TRIGGER && */mEntryHandlers != null && !mEntryHandlers.isEmpty()) {
            logEvent(SMLogEvent.BEGIN_ENTRY_HANDLERS,
                     sourceState,
                     triggerPacking,
                     this);

            executeStateHandlers(mEntryHandlers,
                                 sourceState,
                                 triggerPacking,
                                 this,
                                 SMStateHandlerType.ENTRY);

            logEvent(SMLogEvent.END_ENTRY_HANDLERS,
                     sourceState,
                     triggerPacking,
                     this);
        }

        return statesPath;
    }

    /**
     * @param sourceState for debug
     * @param triggerPacking
     */
    @Override
    void enterEnd(SMStateVertex sourceState,
                  TriggerPacking triggerPacking) {

        super.enterEnd(sourceState, triggerPacking);

        if (mDoActivityHandlers != null && !mDoActivityHandlers.isEmpty()) {
            logEvent(SMLogEvent.BEGIN_START_STATE_ACTIVITY_HANDLERS,
                     sourceState,
                     triggerPacking,
                     this);

            executeStateHandlers(mDoActivityHandlers,
                                 sourceState,
                                 triggerPacking,
                                 this,
                                 SMStateHandlerType.BEGIN_STATE_ACTIVITY);

            logEvent(SMLogEvent.END_START_STATE_ACTIVITY_HANDLERS,
                     sourceState,
                     triggerPacking,
                     this);
        }

        //// handle deferred events
        //if (localTriggerQueue != null && !localTriggerQueue.isEmpty()) {
        //    getWorld().addStateLocalTriggerQueue(this);
        //}
    }

    @Override
    void exitBegin(TriggerPacking triggerPacking,
                   SMStateVertex targetState) {

        // clear local events and and remove it from StateMachine
        if (localTriggerQueue != null) {
            localTriggerQueue.clear(); // this also will cause state machine to remove me from it's list
        }
        // StateMachine to remove it from list

        if (mDoActivityHandlers != null && !mDoActivityHandlers.isEmpty()) {
            logEvent(SMLogEvent.BEGIN_TERMINATE_STATE_ACTIVITY_HANDLERS,
                     this,
                     triggerPacking,
                     targetState);

            executeStateHandlers(mDoActivityHandlers,
                                 this,
                                 triggerPacking,
                                 targetState,
                                 SMStateHandlerType.TERMINATE_STATE_ACTIVITY);

            logEvent(SMLogEvent.END_TERMINATE_STATE_ACTIVITY_HANDLERS,
                     this,
                     triggerPacking,
                     targetState);
        }

        if (exitEvent != null) {
            getWorld().handleAGTrigger(exitEvent);
        }

        if (mExitHandlers != null && !mExitHandlers.isEmpty()) {
            logEvent(SMLogEvent.BEGIN_EXIT_HANDLERS,
                     this,
                     triggerPacking,
                     targetState);

            executeStateHandlers(mExitHandlers,
                                 this,
                                 triggerPacking,
                                 targetState,
                                 SMStateHandlerType.EXIT);

            logEvent(SMLogEvent.END_EXIT_HANDLERS,
                     this,
                     triggerPacking,
                     targetState);
        }

    }

    /**
     * Try to convert a trigger to a composite trigger.
     * If trigger if not part of composite trigger then it is return as is. Otherwise
     * (Trigger is part of composite) and composite is completed then the composite is return. Otherwise:
     * Return null.
     * In other words:
     * -If the original trigger is returned then this trigger is not part of composite trigger.
     * -If null is returned then this trigger is part of composite trigger but not yet completed.
     * -If not null and not the original then it is the composite trigger.
     * <p/>
     * For example, if A = X * Y * Z
     * If pass trigger not in {X, Y, Z} then it is returned, otherwise:
     * If you pass X and Y,Z not yet received then return null. otherwise:
     * return A
     */
    @Override
    TriggerPacking convertToAndEvent(TriggerPacking originalPacking) {

        SMBaseTrigger originalTrigger = originalPacking.getTrigger();

        SMTrigger originalUserTrigger = SMSystemTools.userTrigger(originalTrigger);

        if (originalUserTrigger == null) { // it is a system userEvent
            return originalPacking;
        }

        SMTrigger subTrigger = originalUserTrigger;


        while (isPartOfComplexAndEvent(subTrigger) != null) {
            if (mAndTriggerQueue == null) {
                mAndTriggerQueue = new TriggerQueue();
            }

            // part of and expression
            mAndTriggerQueue.push(subTrigger);

            logEvent(SMLogEvent.GOT_PART_OF_COMPLEX_TRIGGER,
                     this,
                     subTrigger,
                     null);


            // now check if there is a complete and expression

            SMTrigger completeAnd = completeAndEvent();

            if (completeAnd != null) {
                removeAndEventsFromAndQueue(completeAnd);

                logEvent(SMLogEvent.GOT_END_COMPLEX_TRIGGER,
                         this,
                         completeAnd,
                         null);
            } else {
                // was part of 'and' expression but not yet completed
                return null;
            }

            subTrigger = completeAnd; // and try again with new subTrigger
        }

        //noinspection ObjectEquality
        if (subTrigger != originalUserTrigger) {
            return new TriggerPacking(subTrigger, originalPacking.getUserData(), null);
        } else {
            return originalPacking;
        }
    }

    /**
     * return list of SMTransitionSegment if transition occurred
     */
    @Override
    List<SMTransitionSegmentImp> processTrigger(TriggerPacking triggerPacking,
                                                SMStateVertex target,
                                                SMInternalTriggerData internalData,
                                                boolean myEvent) {
        if (!myEvent) {
            return null;
        }

        SMBaseTrigger trigger = triggerPacking.getTrigger();

        boolean debuggerIsOn = isLoggerOn();

        // process internal event2transitions
        if (mInternalTransitionHandlers != null) {

            StateHandlerList hl = mInternalTransitionHandlers.find(trigger);

            if (hl != null && !hl.isEmpty()) {
                if (debuggerIsOn) {
                    logEvent(SMLogEvent.BEGIN_INTERNAL_TRANSITION_HANDLERS,
                             this,
                             trigger,
                             null);
                }

                executeStateHandlers(hl,
                                     this,
                                     triggerPacking,
                                     null,
                                     SMStateHandlerType.INTERNAL_TRANSITION);

                if (debuggerIsOn) {
                    logEvent(SMLogEvent.END_INTERNAL_TRANSITION_HANDLERS,
                             this,
                             trigger,
                             null);
                }
            }
        }

        // try to handle regular transition
        {
            Transitions transitions = findTransitions(trigger);

            if (transitions != null) {

                LinkedList<SMTransitionSegmentImp> path = transitions.findPathThrough(this,
                                                                                      this,
                                                                                      triggerPacking);

                // ok found a path trough regular transition
                if (path != null) {
                    return path;
                }

            }

        }

        return null;
    }

    /**
     * find a path to destination target
     * return a list of {@link SMTransitionSegment}
     * if return null then no path trough this state
     */
    @Override
    LinkedList<SMTransitionSegmentImp> findPathThrough(LinkedList<SMTransitionSegmentImp> pathSoFar,
                                                       SMStateImp beginOfPath,
                                                       SMStateVertex source,
                                                       TriggerPacking triggerPacking) {
        return pathSoFar; // this is final path
    }

    @Override
    boolean possiblyImpassable() {
        return false;
    }

    // ============================================================================
    // state local event queue manipulators

    /**
     * Add a trigger to local state queue
     * If state is currently active, then trigger will be processed the moment
     * state machine will return to it's loop
     * Id state is not active, then trigger will be processed next time state is entered
     * (after state enter, and 'do activity' handlers)
     * Is state is complex state, then trigger will be processed by sub states too.
     * <b>all events are removed from local queue when state is exited, even if not processed</b>
     *
     * @return true if state was added
     */
    private void addToLocalEventQueueInternal(TriggerPacking packing,
                                                 boolean ignoreIfIn /* = false */) {

        /**
         * We found a bug, This method may be called from non internal SM process
         * So the check in {@link SMEventProcessor#addInStepCommand(wf.state_machine.InternalCommand, boolean)} fails,
         * We can run {@link SMEventProcessor#addStateLocalTriggerQueue(SMStateImp)} as step commnad
         * but then it might that the check above is no longer valid,
         * So i'm trying to run all this command is a step
         * Hope that it will bring to prev assumption that it is always inner processing
         * But to make it closer to the previous we are adding it to head of queue
         *
         */

        InternalCommand cmd = new InternalCommand() {
            @Override
            public void doIt() {


                boolean eventPushed = false;
                if (localTriggerQueue == null) {

                    // just use any final member as lock
                    synchronized (this) {
                        if (localTriggerQueue == null) {
                            localTriggerQueue = new SMSMTriggerPackingConcurrentLinkedQueue();
                        }
                    }
                }

                if (ignoreIfIn || !localTriggerQueue.contains(packing)) {

                    localTriggerQueue.add(packing); // at end of queue
                    eventPushed = true;
                }

                if (eventPushed) {
                    logEvent(SMLogEvent.ADDING_LOCAL_TRIGGER_TO_STATE,
                            SMStateImp.this,
                             packing,
                             null);

                    //if (isActive()) {
                    //    getWorld().addStateLocalTriggerQueue(SMStateImp.this);
                    //}
                }

            }

            @Override
            public String toString() {
                return "In state '" + SMStateImp.this + "' addToLocalEventQueue '" + packing.getTrigger() + "'";

            }
        };


        // Add the step command, as a result a inner loop of handling local events will started
        getWorld().addStepCommand(cmd, true);
    }

    /**
     * Add a trigger to local state queue
     * If state is currently active, then trigger will be processed the moment
     * state machine will return to it's loop
     * If state is not active, then trigger will be processed next time state is entered
     * (after state enter, and 'do activity' handlers)
     * Is state is complex state, then trigger will be processed by sub states too.
     * <b>all events are removed from local queue when state is exited, even if not processed</b>
     *
     * @return true if state was added
     */
    @Override
    public final void addToLocalEventQueue(SMTrigger trigger) {
        addToLocalEventQueue(trigger, null);
    }

    /**
     * See {@link #addToLocalEventQueue(SMTrigger)}
     *  @param trigger
     * @param userData
     */
    @Override
    public final void addToLocalEventQueue(SMTrigger trigger, Object userData) {
        TriggerPacking packing = new TriggerPacking(trigger, userData, null);
        addToLocalEventQueueInternal(packing, true);
    }


    //public final boolean isInLocalEventQueue(SMBaseTrigger trigger) {
    //    return mLocalTriggerQueue != null && mLocalTriggerQueue.find(trigger);
    //}
    //
    //public final int removeFromLocalEventQueue(SMBaseTrigger trigger,
    //                                           boolean removeAll /* = false */) {
    //    if (mLocalTriggerQueue == null) {
    //        return 0;
    //    } else {
    //        return mLocalTriggerQueue.remove(trigger, removeAll);
    //    }
    //}

    //public final void clearStateLocalEventQueue() {
    //    if (mLocalTriggerQueue != null) {
    //    // StateMachine will be automatically remove this state from list
    //        mLocalTriggerQueue.clear();
    //    }
    //}

    // ====================================================================

    /**
     * return the state from which we enter this state
     * may return null
     */
    SMStateImp getStateSourceState() {
        return mSourceState;
    }

    // ================ DOM support ===============================

    @Override
    public void writeBody(XMLContext xmlContext, Element myNode) {

        Element andEventsElem = DOMHelper.domAddElement(myNode, "AndEvents");

        if (andsTriggerDefinition != null) {
            for (SMTrigger eid : andsTriggerDefinition.keys()) {

                String name = eid.getName();

                Element andEventElem = DOMHelper.domAddElement(andEventsElem, "AndEvent");
                andEventElem.setAttribute("name", name);


                Element andIDSElem = DOMHelper.domAddElement(andEventElem, "AndIDS");

                SMTriggersAndImp and = andsTriggerDefinition.find(eid);

                for (SMTrigger andComponent : and.parts()) {

                    domBeginEndElemAttributeName(andIDSElem, "SMTrigger", andComponent.getName());
                }
            }
        }

        if (event2transitions != null) {
            DOMHelper.addAndWrite(xmlContext, event2transitions, myNode);
            event2transitions.writeDotData(xmlContext, myNode, this);
        }


        Element internalTransitionsElem = DOMHelper.domAddElement(myNode, "InternalTransitions");

        if (mInternalTransitionHandlers != null) {
            Iterator i = mInternalTransitionHandlers.debugGetEventsIterator();

            while (i.hasNext()) {
                SMBaseTrigger e = (SMBaseTrigger)i.next();

                Element triggerElem = DOMHelper.domAddElement(internalTransitionsElem, "InternalTransition");
                triggerElem.setAttribute("trigger", e.toString());
            }

            mInternalTransitionHandlers.writeDotData(xmlContext, myNode, this);
        }


        super.writeBody(xmlContext, myNode);
    }

    //public SMBaseTrigger getEntryEvent() {
    //    return mEntryTrigger;
    //}

    @Override
    public boolean isEntryEventIs(SMTrigger event) {
        if (mEntryTrigger == null) {
            return false;
        } else {
            return mEntryTrigger.equals(event);
        }
    }

    private final class StateInCondition extends SMCondition {

        @Override
        public boolean isTrue(SMTransitionGuardContext info) {
            return isActive();
        }

        @Override
        public String getName() {
            return "in(" + SMStateImp.this.getName() + ")";
        }
    }

}