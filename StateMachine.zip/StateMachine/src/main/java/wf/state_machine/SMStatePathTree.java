package wf.state_machine;


import org.jetbrains.annotations.Nullable;
import wf.state_machine.util.Pair;

/**
 * Because the possibility of concurrent states, a path to current state as
 * a form of tree, each complex state has one or more current states,
 * a composite state has single current state, a concurrent state has 1 to n current
 * states. So current SMStatePathTree as a form:
 * <p/>
 * <PRE>
 * SMStateVertex - this node
 * /\
 * children
 * /    \
 * /      \
 * /        \
 * SMStatePathTree     \
 * SMStatePathTree
 * </PRE>
 */
public final class SMStatePathTree {

    /**
     * the current state at node
     */
    private final SMStateVertexImp nodeState;

    /**
     * current states under node, in case of concurrent states
     * it length may be > 1
     * <p>
     * In case of simple state it is null
     */
    private final SMStatePathTree[] children;

    SMStatePathTree(SMStateVertexImp s) {
        nodeState = s;
        children = null;
    }

    SMStatePathTree(SMStateVertexImp s, int n) {
        nodeState = s;
        children = new SMStatePathTree[n];
    }

    /**
     * One child
     *
     * @param nodeState
     */
    SMStatePathTree(SMStateVertexImp nodeState, SMStatePathTree child) {
        this.nodeState = nodeState;
        children = new SMStatePathTree[]{child};
    }

    public SMStatePathTree[] getChildren() {
        return children;
    }

    void setChildren(int index, SMStatePathTree child) {
        children[index] = child;
    }

    /**
     * We walk on the tree BFS - why ? no good reason.
     *
     * @return null in no one in the tree has event in local queue
     */
    @Nullable
    Pair<SMStateImp, TriggerPacking> removeFromLocalQueue() {

        // This is a patch - should be handled by OOP !!!

        if (!(nodeState instanceof SMStateImp)) {
            return null;
        }

        SMStateImp thisNode = (SMStateImp)nodeState;

        SMSMTriggerPackingConcurrentLinkedQueue localTriggerQueue = ((SMStateImp)nodeState).getLocalTriggerQueue();

        if (localTriggerQueue != null) {

            TriggerPacking triggerPacking = localTriggerQueue.poll();

            if (triggerPacking != null) {
                return new Pair<>(thisNode, triggerPacking);
            }
        }

        if (children == null) {
            return null;
        }

        for (SMStatePathTree child : children) {

            Pair<SMStateImp, TriggerPacking> localTrigger = child.removeFromLocalQueue();

            if (localTrigger != null) {
                return localTrigger;
            }
        }


        // no local in tree
        return null;
    }

    private static String asString(SMStatePathTree tree) {
        if (tree == null) {
            // this can happened in case state tree is invalid, because it was
            //  taken when SM is busy
            return "?";

        } else {
            return tree.getAsString();
        }

    }

    private String getAsString() {
        if (nodeState.isTopLevel()) {
            if (children == null) {
                return "*";
            } else {
                // root is always composite !!!
                return asString(children[0]);
            }
        } else {

            StringBuilder n = new StringBuilder(nodeState.getName());
            if (children != null) {
                int l = children.length;

                if (l == 1) {
                    n.append(":");
                    n.append(asString(children[0]));
                } else {
                    if (l > 1) {
                        n.append(":{");

                        for (int i = 0; i < l; ++i) {
                            if (i > 0) {
                                n.append(", ");
                            }

                            n.append(asString(children[i]));
                        }

                        n.append("}");

                    }
                }
            }

            return n.toString();
        }
    }

    /**
     * same as {@link #getAsString}
     */
    @Override
    public String toString() {
        return getAsString();
    }


}
