package wf.state_machine;

import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 * !! This interface is not intended to be implemented by client code
 * !! SM FW assumes that only its internal implementation exists
 * !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 * @author Boaz Nahum
 */

public interface SMStateVertex extends StateMachineElement {

    /**
     * Short name of state, not including it's ancestors.
     */
    String getName();

    /**
     * todo:boaz:tmpcode: try to remove it from public interface!!!
     */
    SMStateVertex getParent();

    /**
     * todo:boaz:tmpcode: try to remove it from public interface!!!
     */
    boolean isTopLevel();

    boolean isEntryEventIs(SMTrigger event);

    /**
     * Define transition.<br>
     * A unary transition is a transition in which number of targets is 1. otherwise it is 'nary' transition.
     * In unary transition you may supply null guard, this is treated as always true' guard.
     * <p/>
     * In 'nary' transition you must supply guard.<br>
     * All transition composed of N target states: target1, ...otherTargets
     * Guard must return a number I in range 0..N-1 selecting the branch to take.
     * If return -1 then no branch is selected. If return >=N then exception is thrown.
     * see {@link SMGuard#select(SMTransitionGuardContext)}.<br>
     *
     * @param guard may be null in case of 'unary' transition.
     */
    @SuppressWarnings({"OverloadedVarargsMethod"})
    SMTransition addTransition(SMBaseTrigger trigger,
                               SMGuard guard,
                               SMStateVertex target1,
                               SMStateVertex... otherTargets);

    /**
     * Sugaring - add unary/binary transition
     * @param trigger
     * @param guard
     * @param targetTrue
     * @param targetFalse
     */
    default SMTransition addBTransition(SMBaseTrigger trigger,
                                        @Nullable String name,
                                        SMBinaryPredicate guard,
                                        SMStateVertex targetTrue,
                                        @Nullable SMStateVertex targetFalse) {
        return addTransition(trigger, SMGuard.binary1(name, guard), targetTrue, targetFalse);
    }

    /**
     * Sugaring - add unary/binary transition, without name or assuming {@link SMBinaryPredicate#getName()} is meaningful
     * @param trigger
     * @param guard
     * @param targetTrue
     * @param targetFalse
     */
    default SMTransition addBTransition(SMBaseTrigger trigger,
                                        SMBinaryPredicate guard,
                                        SMStateVertex targetTrue,
                                        @Nullable SMStateVertex targetFalse) {
        return addTransition(trigger, SMGuard.binary1(null, guard), targetTrue, targetFalse);
    }

    /**
     * Sugaring - add unary transition, without name or assuming {@link SMBinaryPredicate#getName()} is meaningful
     * @param trigger
     * @param guard
     * @param targetTrue
     */
    default SMTransition addUTransition(SMBaseTrigger trigger,
                                        SMBinaryPredicate guard,
                                        SMStateVertex targetTrue) {
        return addTransition(trigger, SMGuard.binary1(null, guard), targetTrue);
    }

    /**
     * Sugaring - add unary
     * @param trigger
     * @param guard
     * @param targetTrue
     */
    default SMTransition addUTransition(SMBaseTrigger trigger,
                                        @Nullable String name,
                                        SMBinaryPredicate guard,
                                        SMStateVertex targetTrue) {
        return addTransition(trigger, SMGuard.binary1(name, guard), targetTrue);
    }

    /**
     * Unary transition. see general case in
     * Please note that if you want to define internal state transition (source and target are the same state)
     * you probably need to use addInternalTransition otherwise the On State action will be called
     * {@link #addTransition(SMBaseTrigger, SMGuard ,SMStateVertex, SMStateVertex...)}
     */
    SMTransition addUTransition(SMBaseTrigger trigger,
                                SMStateVertex targetState);

    /**
     * //todo:boaz:fix: Add doc when you can use transition without a trigger
     * @param targetState
     */
    SMTransition addTransition(SMStateVertex targetState);

    /**
     * //todo:boaz:fix: Add doc when you can use transition without a trigger
     * Nary transition with no trigger
     */
    @SuppressWarnings({"OverloadedVarargsMethod"})
    SMTransition addTransition(SMGuard guard,
                               SMStateVertex target1,
                               SMStateVertex... otherTargets);

    /**
     * Add unary transitions from many sources to this state.
     * See also {@link SMCompositeState#addTransitionFromAllSubStates(SMBaseTrigger, SMGuard, SMStateVertex, SMStateVertex...)}
     * @param trigger
     * @param guard
     * @return list of transitions - for each {this, sources[...] } pair
     */
    List<SMTransition> addTransitionsFromMany(SMBaseTrigger trigger,
                                              @Nullable SMCondition guard,
                                              SMStateVertex... sources);

    // ================ DOT support ===============================
    //

    String getDotName();

    String getDotLabel();

    //////////////////////////////////////////////////////////////////////
    // Diagnostics and debugging
    //
    // Use these method with great care - they are here for debugging and not for modeling state machine
    // ! In many cases they might report a transient state !
    // Don't use them to affect your model behaviour
    //

    boolean debugIsActive();

}
