package wf.state_machine;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import wf.state_machine.outputers.DOMHelper;
import wf.state_machine.outputers.XMLAttributeAndValue;
import wf.state_machine.outputers.XMLContext;
import wf.state_machine.outputers.XMLWriteable;
import wf.state_machine.outputers.dot.DotContext;
import wf.state_machine.smlogger.SMLogEvent;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

import static wf.state_machine.SMStateVertexImp.StateInternalState.SS_ACTIVE;
import static wf.state_machine.SMStateVertexImp.StateInternalState.SS_NO_ACTIVE;
import static wf.state_machine.SMStateVertexImp.StateInternalState.SS_ON_ENTER;
import static wf.state_machine.SMStateVertexImp.StateInternalState.SS_ON_EXIT;

@SuppressWarnings({"ClassReferencesSubclass"})
abstract class SMStateVertexImp extends StateMachineElementImp
    implements SMStateVertex, XMLWriteable, Comparable /* so state can be used as a key in map (see fork) */ {


    // state' state

    protected enum StateInternalState {

        SS_NO_ACTIVE,
        SS_ON_ENTER,
        SS_ACTIVE,
        SS_ON_EXIT
    }

    /**
     * this is used as an indicator that transition was made
     * but it was handled by state itself
     */
    static final List<SMTransitionSegmentImp> EMPTY_SEGMENT_LIST = Collections.emptyList();

    private final SMComplexStateImp parentState;

    /**
     * must be one of SS_*
     */
    private StateInternalState stateInternalState;


    /**
     * Short name of state, not including it's ancestors.
     */
    private final String mName;

    /**
     *
     * @param world
     * @param parent
     * @param name
     */
    SMStateVertexImp(StateMachineImp world,
                  SMComplexStateImp parent,
                  @Nullable String name) {
        super(world);

        parentState = parent;
        stateInternalState = SS_NO_ACTIVE;

        mName = HiddenName.hideIfNull(name);
    }

    /**
     * use this when parent is not null
     */
    SMStateVertexImp(SMComplexStateImp parent,
                  String name) {
        this(parent.getWorld(), parent, name);
    }

    /**
     * Short name of state, not including it's ancestors.
     */
    @Override
    public final String getName() {
        return mName;
    }

    @Override
    public final String toString() {
        return getAbsName();
    }

    /**
     * null if this is root
     *
     * Note: Can't be public because {@link SMComplexStateImp} is not public
     * That why we have two methods {@link #getParent()}
     * How to solve this ?
     */
    SMComplexStateImp getParentState() {
        return parentState;
    }

    @Override
    public SMStateVertexImp getParent() {
        return parentState;
    }


    /**
     * Return full name of state including it's ancestors.
     * this will not include top level name
     */
    final String getAbsName() {
        SMStateVertex root = getTopLevel();

        //noinspection ObjectEquality
        if (this == root) {
            return getName();
        } else {
            StringBuilder n = new StringBuilder(getName());

            SMStateVertexImp s = getParentState();

            //noinspection ObjectEquality
            while (s != root) {
                n.insert(0, s.getName() + ":");
                s = s.getParentState();
            }

            return n.toString();
        }


    }

    abstract String getTypeName();

    // used for error reporting

    final String getTypeAndName() {
        return getTypeName() + " '" + getAbsName() + "'";
    }

    SMStatePathTree getCurrentStatePathTree() {
        return new SMStatePathTree(this);
    }

    /**
     * final state will return null - we don't return to it
     * join must be return null, because we can't return to it
     * composite will return its current state deep history (maybe will return null)
     * concurrent will return a dummy state that is a fork to all it's deep history
     */
    SMStateVertexImp getDeepHistory() {
        return this;
    }


    //========================================================================
    // will return none null if this is a SMState and not a PseudoState

    SMStateImp getRealState() {
        return null;
    }

    //public boolean isFinalState() {
    //    return false;
    //}

    /**
     * SimpleState & PseudoSate  state are never in final state
     * FinalState is always in final state
     * SMCompositeState is in final state if it's current state in final state
     * SMConcurrentState if all it's sub states are in final state
     */
    boolean isInFinalState() {
        return false;
    }

    /**
     * Is this state entered but not yet exist ?
     * In stable state machine this means that state is current.
     */
    final boolean isActive() {
        return stateInternalState == SS_ACTIVE;
    }

    boolean isComplex() {
        return false;
    }

    boolean isConcurrent() {
        return false;
    }

    /**
     * true if this is a direct sub state of concurrent state.
     * region must be a complex state
     */
    boolean isRegion() {
        return false;
    }

    boolean isPseudo() {
        return false;
    }

    boolean isFork() {
        return false;
    }

    boolean isJoin() {
        return false;
    }

    @Override
    public final boolean isTopLevel() {
        return getParentState() == null;
    }

    @Override
    public boolean isEntryEventIs(SMTrigger event) {
        return false;
    }

    //=======================================================================
    // transition definition

    void checkIncomingTransitionIsValid(SMStateVertexImp source) {
    }

    void checkOutgoingTransitionIsValid(SMStateVertex target) {
    }

    private static void checkTransitionIsValid(SMStateVertexImp source, SMStateVertexImp target) {
        checkTransitionAcrossRegions(source, target);

        source.checkOutgoingTransitionIsValid(target);
        target.checkIncomingTransitionIsValid(source);
    }

    private static void checkTransitionAcrossRegions(SMStateVertexImp source, SMStateVertexImp target) {
        if (target.isJoin()) {
            return; // if it not valid join, it will be caught
        }
        // by Join.setIncomingTransition

        if (!source.isOrInRegion() || !target.isOrInRegion()) {
            return;
        }


        SMStateVertexImp topMostToExit =
            findTopMostStateToExit(source, target);

        // if we exit region and not an composite state (it's parent)
        // then it means that we are going to one of:
        //  join - if it's region brother then it is ok,
        //               if not then it will be caught by join
        //               setIncomingTransition
        //  fork - not allowed
        //  other region not in this region - brother region -
        //   that's means we cross regions
        if (topMostToExit.isRegion()) {
            throw new SMDefinitionException(
                "SMTransition across region(" +
                topMostToExit.getAbsName() + "): " +
                source.getAbsName() + " --> " +
                target.getAbsName());
        }

    }

    private SMTransition checkAndAddTransition(SMBaseTrigger trigger, SMTransitionImp t) {
        addTransitionToTargets(t);
        addOutgoingTransition(trigger, t);
        return t;
    }

    /**
     * this must be override by sub states, to catch some errors and for
     * special cases
     */
    SMTransition addOutgoingTransition(SMBaseTrigger trigger, SMTransitionImp t) {
        throw new SMDefinitionException(getTypeName() + " state does not support outgoing transitions");
    }

    void setIncomingTransition(SMStateVertexImp source) {
    }

    private void addTransitionToTarget(SMStateVertexImp target) {
        if (target != null) {
            checkTransitionIsValid(this, target);

            target.setIncomingTransition(this);
        }
    }

    private void addTransitionToTargets(SMTransitionImp t) {
        int n = t.getN();

        for (int i = 0; i < n; ++i) {
            SMStateVertexImp target = t.getBranchTarget(i);

            addTransitionToTarget(target);
        }
    }


    private SMTransitionImp createTransition(StateMachineImp world,
                                          SMStateVertex[] targets,
                                          SMGuard guard) {

        SMTransitionImp t = SMTransitionImp.createTransition(
            world,
            targets,
            guard);

        return t;
    }


    /**
     * Define transition.<br>
     * A unary transition is a transition in which number of targets is 1. otherwise it is 'nary' transition.
     * In unary transition you may supply null guard, this is treated as always true' guard.
     * <p/>
     * In 'nary' transition you must supply guard.<br>
     * All transition composed of N target states: target1, ...otherTargets
     * Guard must return a number I in range 0..N-1 selecting the branch to take.
     * If return -1 then no branch is selected. If return >=N then exception is thrown.
     * see {@link SMGuard#select(SMTransitionGuardContext)}.<br>
     *
     * @param guard may be null in case of 'unary' transition.
     */
    @Override
    @SuppressWarnings({"OverloadedVarargsMethod"})
    public final SMTransition addTransition(SMBaseTrigger trigger,
                                            SMGuard guard,
                                            SMStateVertex target1,
                                            SMStateVertex... otherTargets) {

        SMStateVertex[] targets = Misc.merge(target1, otherTargets);

        SMTransitionImp t = createTransition(
            getWorld(),
            targets,
            guard
        );

        return checkAndAddTransition(trigger, t);

    }

    /**
     * Unary transition. see general case in
     * Please note that if you want to define internal state transition (source and target are the same state)
     * you probably need to use addInternalTransition otherwise the On State action will be called
     * {@link #addTransition(SMBaseTrigger, SMGuard ,SMStateVertex, SMStateVertex...)}
     */
    @Override
    public final SMTransition addUTransition(SMBaseTrigger trigger,
                                             SMStateVertex targetState) {
        return addTransition(
            trigger,
            null,
            targetState);
    }

    /**
     * unary transition with no trigger
     *
     */
    @Override
    public final SMTransition addTransition(SMStateVertex targetState) {
        return addTransition(
            null,
            (SMGuard)null,
            targetState);
    }

    /**
     * Nary transition with no trigger
     */
    @Override
    @SuppressWarnings({"OverloadedVarargsMethod"})
    public final SMTransition addTransition(SMGuard guard,
                                            SMStateVertex target1,
                                            SMStateVertex... otherTargets) {
        return addTransition(null, guard, target1, otherTargets);
    }

    ///**
    // * Every call to this method will generate new key
    // * You can assume nothing on the content of the key, not even that it contains your prefix;
    // */
    //public final String generateUniqueKey(@Nullable String prefix) {
    //
    //    String myPrefix = "State:'" + getAbsName() + "'";
    //    if (prefix != null) {
    //        myPrefix +=  ", " + prefix;
    //    }
    //
    //    return Misc.createUnique(myPrefix);
    //}


    /**
     * Add unary transitions from many sources to this state.
     * See also {@link wf.state_machine.SMCompositeState#addTransitionFromAllSubStates(SMBaseTrigger, SMGuard, SMStateVertex, SMStateVertex...)}
     * @param trigger
     * @param guard
     * @return list of transitions - for each {this, sources[...] } pair
     */
    @Override
    public List<SMTransition> addTransitionsFromMany(SMBaseTrigger trigger,
                                                     @Nullable SMCondition guard,
                                                     SMStateVertex... sources) {

        ArrayList<SMTransition> transitions = new ArrayList<>(sources.length);

        for (SMStateVertex source : sources) {

            SMTransition transition = source.addTransition(trigger, guard, this);

            transitions.add(transition);

        }

        return transitions;

    }



    /**
     * addTransition from list of states.
     * Return {@link SMTransition} for each state in source list.
     */
    static SMTransition[] addTransitionFromManyStates(SMStateImp[] sourceStatesList,
                                                      SMBaseTrigger triggerTrigger,
                                                      SMGuard guard,
                                                      SMStateVertex target1,
                                                      SMStateVertex... otherTargets) {

        SMTransition[] transitions = new SMTransition[sourceStatesList.length];

        if (sourceStatesList.length == 0) {
            return transitions;
        }

        for (int i = 0; i < sourceStatesList.length; ++i) {
            SMStateImp s = sourceStatesList[i];

            transitions[i] =
                s.addTransition(triggerTrigger, guard, target1, otherTargets);
        }

        return transitions;
    }


    @Override
    protected void checkValid() {
    }

    @Override
    void init() {
        super.init();
        stateInternalState = SS_NO_ACTIVE;
    }


    // ============================================================================
    // state math

    boolean isStateContains(SMStateVertex s) {
        return false;
    }

    final boolean isStateContainsOrEq(SMStateVertex s) {
        //noinspection ObjectEquality
        if (s == this) {
            return true;
        } else {
            return isStateContains(s);
        }
    }

    ///**
    // * return true if s is brother of this state
    // * (both have same parent)
    // */
    //final boolean isBrother(SMStateVertex s) {
    //    //noinspection ObjectEquality
    //    return this != s && getParentState() == s.getParentState();
    //}

    /**
     * check if s is my brother or s is descendant of my brother
     */
    final boolean isBrotherOrBrotherDescendant(SMStateVertex s) {
        // this must be optimized, cause we look twice in this
        return
            getParentState() != null &&
            !isStateContainsOrEq(s) && // it's not me nor one of my descendant
            getParentState().isStateContains(s);
    }

    /**
     * return the top most state of s1 that does not contain s2
     * assume s1 and s2 are disjunctive states  i.e s1 does not eq or contains s2 and
     * s2 does not contains s1
     */
    private static SMStateVertexImp topMostStateNoContains(SMStateVertexImp s1, SMStateVertexImp s2) {

        SMStateVertexImp s1_parent = s1.getParentState();

        if (s1_parent.isStateContains(s2)) {
            return s1;
        } else {
            return topMostStateNoContains(s1_parent, s2);
        }
    }

    /**
     * Return state that --really-- contains all states:
     * If results are T then both s1 and s2 are in T but not equals to it.
     * !! should be used only by output-ers -- not optimized
     */
    static SMComplexStateImp firstStateContainsBothNoConcurrent(SMStateVertexImp s1, SMTransitionImp otherStates) {

        int nOther = otherStates.getN();

        for (int i = 0; i < nOther; ++i) {
            SMStateVertexImp t = otherStates.getBranchTarget(i);
            if (t == null || t.getParentState() == null) {
                throw new SMDefinitionException("Can't be null or top");
            }
        }


        SMComplexStateImp parent = s1.getParentState();

        while (parent != null) {
            if (!parent.isConcurrent()) {

                // even if all is empty
                boolean containsAll = true;

                for (int i = 0; i < nOther; ++i) {
                    SMStateVertex t = otherStates.getBranchTarget(i);
                    if (!parent.isStateContains(t)) {
                        containsAll = false;
                        break;
                    } // else - optimize - remove from list
                }

                if (containsAll) {
                    return parent;
                }
            }

            parent = parent.getParentState();
        }


        throw new SMDefinitionException("both can't be top");
    }

    /**
     * return true if transition is all in segment
     * if transition if from/to edge of state then this will return false
     */
    boolean transitionCompletelyIn(List list) {
        if (list == null) {
            return true;
        }

        for (Object aList : list) {
            SMTransitionSegmentImp segment = (SMTransitionSegmentImp)aList;

            SMStateVertex source = segment.getSource();
            SMStateVertex target = segment.getTarget();

            if (!isStateContains(source) || !isStateContains(target)) {
                return false;
            }
        }

        return true;

    }

    /**
     * return true if this state is in region
     */
    private boolean isInRegion() {
        // we begin in parent, because we ask if it IN
        SMStateVertexImp parent = getParentState();

        while (parent != null) {
            if (parent.isRegion()) {
                return true;
            }

            parent = parent.getParentState();
        }

        return false;
    }

    // return true if state is region or in region

    private boolean isOrInRegion() {
        return isRegion() || isInRegion();
    }

    static SMStateVertexImp findTopMostStateToExit(SMStateVertexImp source, SMStateVertexImp target) {
        if (source.isStateContainsOrEq(target)) {
            return source;
        } else if (target.isStateContainsOrEq(source)) {
            return target;
        } else {
            return topMostStateNoContains(source, target);
        }

    }

    static SMStateVertexImp findTopMostStateToEnter(SMStateVertexImp stateWeExitFrom, SMStateVertexImp target) {
        if (stateWeExitFrom.isStateContainsOrEq(target)) {
            return stateWeExitFrom;
        } else {
            return topMostStateNoContains(target, stateWeExitFrom);
        }
    }

    // end state math
    // ============================================================================


    /**
     * add to statesPath the list all states you enter, so caller can call
     * each enter_end
     */
    LinkedList<SMStateVertexImp> enterBegin(SMStateImp beginOfPath,
                                            SMStateVertexImp innerTargetState,
                                            LinkedList<SMStateVertexImp> statesPath,
                                            SMStateVertexImp sourceState, // for debug
                                            // for debug
                                            TriggerPacking triggerPacking) {
        stateInternalState = SS_ON_ENTER;

        logEvent(
            SMLogEvent.BEGIN_STATE_ENTRY,
            sourceState,
            triggerPacking,
            this);

        if (statesPath == null) {
            statesPath = new LinkedList<>();
        }

        statesPath.add(this);

        return statesPath;
    }

    void enterEnd(SMStateVertex sourceState, // for debug
                  TriggerPacking triggerPacking /* for debug */) {
        stateInternalState = SS_ACTIVE;

        // this is a patch
        if (!isJoin()) {
            updateParentIBecomeCurrent();
        }

        logEvent(
            SMLogEvent.END_STATE_ENTRY,
            sourceState,
            triggerPacking,
            this);

        logEvent(
            SMLogEvent.ON_STATE,
            sourceState,
            triggerPacking,
            this);
    }

    final void enter(SMStateImp beginOfPath,
                     SMStateVertexImp innerTargetState,
                     SMStateVertexImp sourceState, // for debug
                     TriggerPacking triggerPacking /* for debug */) {
        LinkedList<SMStateVertexImp> statesPath = enterBegin(
            beginOfPath,
            innerTargetState,
            null, // empty list
            sourceState,
            triggerPacking);

        ListIterator<SMStateVertexImp> i = statesPath.listIterator(statesPath.size());

        while (i.hasPrevious()) {
            SMStateVertexImp s = i.previous();

            s.enterEnd(
                sourceState,
                triggerPacking);
        }
    }

    void exitBegin(TriggerPacking triggerPacking,
                   SMStateVertex targetState) {
    }

    final void exit(TriggerPacking triggerPacking,
                    SMStateVertex targetState) {
        stateInternalState = SS_ON_EXIT;

        logEvent(
            SMLogEvent.BEGIN_STATE_EXIT,
            this,
            triggerPacking,
            targetState);

        exitBegin(triggerPacking, targetState);

        stateInternalState = SS_NO_ACTIVE;

        logEvent(
            SMLogEvent.END_STATE_EXIT,
            this,
            triggerPacking,
            targetState);

    }

    private boolean isMyEvent(SMStateVertex target) {
        //noinspection ObjectEquality
        return target == null || target == this;
    }

    TriggerPacking convertToAndEvent(TriggerPacking originalPacking) {
        // SMStateVertex don't have events dictionary
        return originalPacking;
    }


    /**
     * At the beginning there was only {@link #processTrigger(TriggerPacking, SMStateVertex, SMInternalTriggerData, boolean)}
     * but it was flexible enough, because there is no good place to call super method.
     * <p>
     * This method purpose it to perform the prolog which is valid for all types of states
     * -Log event to logger.
     * -Try to convert composite trigger
     * -Call the 'heavy' processing {@link #processTrigger(TriggerPacking, SMStateVertex, SMInternalTriggerData,boolean)}
     *
     * return list of SMTransitionSegment if transition need to be handled by caller
     * return EMPTY_SEGMENT_LIST if transition was occurred, but was handled by state itself
     */
    List<SMTransitionSegmentImp> preAndProcessTrigger(TriggerPacking triggerPacking,
                                                      SMStateVertex target,
                                                      SMInternalTriggerData internalData) {

        boolean debuggerIsOn = isLoggerOn();

        if (debuggerIsOn) {
            logEvent(
                SMLogEvent.STATE_GOT_TRIGGER,
                this,
                triggerPacking,
                null);
        }

        boolean myEvent = isMyEvent(target);

        if (myEvent) {

            /**
             * Note: Because we try to resolve composite states in this level then
             * that means that in case of   
             */
            triggerPacking = convertToAndEvent(triggerPacking);

            if (triggerPacking == null) {
                return null; // it was part of 'and' trigger, but not completed one
            }
        }


        return processTrigger(triggerPacking, target, internalData, myEvent);
    }

    /**
     * return list of SMTransitionSegment if transition need to be handled by caller
     * return EMPTY_SEGMENT_LIST if transition was occurred, but was handled by state itself
     * @param myEvent {@link #isMyEvent(SMStateVertex)} return true.
     */
    List<SMTransitionSegmentImp> processTrigger(TriggerPacking triggerPacking,
                                                SMStateVertex target,
                                                SMInternalTriggerData internalData,
                                                boolean myEvent) {
        return null;

    }

    /**
     * find a path to destination target
     * return a list of Transition Segment
     * if return null then no path trough this state
     * @param pathSoFar If no path found then pathSoFar is not modified.
     * @param beginOfPath
     * @param triggerPacking
     */
    LinkedList<SMTransitionSegmentImp> findPathThrough(LinkedList<SMTransitionSegmentImp> pathSoFar,
                                                       SMStateImp beginOfPath,
                                                       SMStateVertex source,
                                                       TriggerPacking triggerPacking) {
        return null;
    }

    /**
     * Add  segment source to you and find path through you.
     * Return null if no path through you.
     *  @param pathSoFar If no path found then pathSoFar is not modified.
     * @param triggerPacking*/
    LinkedList<SMTransitionSegmentImp> addYourSegmentAndFindPathThrough(LinkedList<SMTransitionSegmentImp> pathSoFar,
                                                                        SMStateImp beginOfPath,
                                                                        SMStateVertexImp source,
                                                                        TriggerPacking triggerPacking,
                                                                        SMTransitionImp transition,
                                                                        int branchNumber) {

        SMTransitionSegmentImp segment =
            SMTransitionSegmentImp.create(
                beginOfPath,
                source,
                transition,
                branchNumber,
                triggerPacking,
                this);

        pathSoFar.addLast(segment);

        // todo: make sure all targets don't modify pathSoFar if
        // returning null
        LinkedList<SMTransitionSegmentImp> pathFound = findPathThrough(
            pathSoFar,
            beginOfPath,
            source,
            triggerPacking);

        if (pathFound == null) {
            pathSoFar.removeLast(); // we promise not to modify it
        }

        return pathFound;

    }

    /**
     * See {@link #findPathThrough(LinkedList, SMStateImp, SMStateVertex, TriggerPacking)}
     * {@link SMStateImp#addYourSegmentAndFindPathThrough(LinkedList, SMStateImp, SMStateVertexImp, TriggerPacking, SMTransitionImp, int)}
     * <p/>
     * Please not that the implementation of this method is depended heavily
     * on validity check and understanding the SM implementation.
     */
    abstract boolean possiblyImpassable();


    /**
     * Return the path to the first vertex (in my path)that is not in container.
     * onEdgeIsOk determine if we interested in 'really in' or that 'equal' is also consider 'in'
     * For the case of simple State, if state is not in(equal to) container then it is returned.
     */
    List<SMStateVertex> isAllPathTroughIsInContainer(SMComplexStateImp container,
                                                     boolean onEdgeIsOk) {
        boolean thisIsInContainer =
            onEdgeIsOk ? container.isStateContainsOrEq(this) :
            container.isStateContains(this);

        if (thisIsInContainer) {
            return null;
        } else {
            LinkedList<SMStateVertex> l = new LinkedList<>();
            l.add(this);
            return l;
        }

    }

    /**
     * update through all parent hierarchy that state become parent
     */
    final void updateParentIBecomeCurrent() {
        if (getParentState() != null) {
            getParentState().childBecomeCurrent(this);
        }
    }

    /**
     * convert list vertex to string s1-->s2-->...
     */
    String pathToString(List<SMStateVertex> path) {
        ListIterator<SMStateVertex> i = path.listIterator();

        StringBuilder s = new StringBuilder();

        while (i.hasNext()) {
            s.append(i.next().toString());

            if (i.hasNext()) {
                s.append("-->");
            }
        }

        return s.toString();
    }

    // Comparable

    @Override
    public final int hashCode() {
        return super.hashCode();
    }

    @Override
    public final boolean equals(Object obj) {
        return super.equals(obj);
    }

    @Override
    public final int compareTo(@NotNull Object o) {
        SMStateVertex rhs = (SMStateVertex)o;

        int l = hashCode();
        int r = rhs.hashCode();

        return (l < r) ? (-1) : ((l == r) ? 0 : 1);
    }


    // ================ DOM support ===============================
    //

    final void writeTo(XMLContext xmlContext, Node node) {
        DOMHelper.addAndWrite(xmlContext, this, node);

    }

    @Override
    public abstract String getElementName();

    @Override
    public void writeBody(XMLContext xmlContext, Element myNode) {

        DotContext dotContext = xmlContext.getDotContext();

        if (dotContext == null) {
            return;
        }


        if (!isComplex()) {
            String dotName = getDotName();

            String attributes = getDotNoneComplexModeAttributes(dotContext);

            dotContext.addDotElement(myNode,
                                     dotName + DotContext.wrapAttributes(attributes) + ";");
        }
    }

    String getDotNoneComplexModeAttributes(DotContext dotContext) {

        String s1 = getDotLabelAttribute();

        String s2;

        if (isActive()) {
            s2 = getDotActiveStateAttributes();
        } else {
            s2 = null;
        }

        String s3 = getDotStateShapeAttributes();

        String combined = DotContext.concatenateAttributes(s1, s2);
        return DotContext.concatenateAttributes(combined, s3);
    }

    private String getDotStateShapeAttributes() {
        //http://www.graphviz.org/doc/info/attrs.html
        return "shape=box";
    }

    /**
     * Return "label=" + getName()
     */
    private String getDotLabelAttribute() {
        return DotContext.getDotLabelEqualsName(this);
    }

    private String getDotActiveStateAttributes() {
        return "color=" + DOTAttributesXx.SIMPLE_STATE_ACTIVE_LINE_COLOR +
               ", penwidth=" + DOTAttributesXx.SIMPLE_STATE_ACTIVE_LINE_PEN_WIDTH;//, peripheries=2";
    }

    /**
     * @return null if none
     */
    @Override
    public XMLAttributeAndValue[] getAttributes() {

        return new XMLAttributeAndValue[]{
            new XMLAttributeAndValue("name", getName()),
            new XMLAttributeAndValue("type", getTypeName()),
            new XMLAttributeAndValue("shape", "box")
        };
    }

    /**
     * Create node, add it to inNode, add attribute "name"=name
     */
    static void domBeginEndElemAttributeName(Node inNode, String elementName, String name) {

        Element childNode = DOMHelper.domAddElement(inNode, elementName);

        childNode.setAttribute("name", name);
    }

    // ================ DOT support ===============================
    //

    @Override
    public String getDotName() {
        String s = getAbsName().replace(":", "_");
        s = s.replaceAll("\\s", "_");
        s = s.replace("*", "x");
        s = s.replace("&", "x");
        s = s.replace("$", "x");

        if (isComplex()) {
            s = "cluster_" + s;
        }

        return s;
    }

    public String getDotNameAsSourceOfTransition(SMStateVertex target) {
        return getDotName();
    }

    public String getDotNameAsTargetOfTransition(SMStateVertex source) {
        return getDotName();
    }

    private String getTypeAndDotName() {
        return getTypeName() + " '" + getDotName() + "'";
    }

    final String getDefaultDotLabel() {
        return getName();
    }

    @Override
    public String getDotLabel() {
        return getDefaultDotLabel();
    }

    @Override
    public boolean debugIsActive() {
        return isActive();

    }

    // ====================================================================
    // for debug only


    /**
     * All real and pseudo states
     */
    public void debugAddAllStates(List<String> states) {
        states.add(getAbsName());
    }


    SMStateDotInfo getDotInfo() {
        return new SMStateDotInfo(this, getTypeAndDotName(), getDotName(), false);
    }

}