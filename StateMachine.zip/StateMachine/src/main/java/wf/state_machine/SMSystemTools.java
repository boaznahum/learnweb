package wf.state_machine;

/**
 * Date: Mar 9, 2005
 *
 * @author Boaz Nahum
 */
class SMSystemTools {


    private SMSystemTools() {
    }

    static boolean isUserTrigger(SMBaseTrigger trigger) {
        return trigger instanceof SMUTrigger;
    }

    static boolean isSystemTrigger(SMBaseTrigger trigger) {
        return trigger instanceof SystemTrigger;
    }

    static SMUTrigger userTrigger(SMBaseTrigger trigger) {

        if (trigger instanceof SMUTrigger) {
            return (SMUTrigger)trigger;
        } else {
            return null;
        }

    }

    ///**
    // * Binary transition is converted to nary transition with 2 branches
    // */
    //static SMGuard binaryToGuard(final SMCondition condition) {
    //
    //    boolean isNamed = condition instanceof SMNamedElement;
    //
    //    if (isNamed) {
    //        return new NamedCondition2BinaryGuard(condition);
    //    } else {
    //        return new Condition2BinaryGuard(condition);
    //
    //    }
    //}
    //
    //private static class Condition2BinaryGuard implements SMGuard {
    //
    //    protected final SMCondition condition;
    //
    //    Condition2BinaryGuard(SMCondition condition) {
    //        this.condition = condition;
    //    }
    //
    //    @Override
    //    public int select(SMTransitionGuardContext info) {
    //        if (condition.isTrue()) {
    //            return 0; // select 'true target'
    //        } else {
    //
    //            if (info.getN() == 1) {
    //                // no else branch
    //                return -1;
    //            } else {
    //                return 1; // select 'else branch'
    //            }
    //        }
    //    }
    //}
    //
    //private static class NamedCondition2BinaryGuard extends Condition2BinaryGuard implements SMNamedElement {
    //
    //
    //    NamedCondition2BinaryGuard(SMCondition condition) {
    //        super(condition);
    //    }
    //
    //    @Override
    //    public String getName() {
    //        return ((SMNamedElement)condition).getName();
    //    }
    //
    //    public String toString() {
    //        String s = getName();
    //        if (s != null) {
    //            return s;
    //        } else {
    //            return super.toString();
    //        }
    //    }
    //}

}
