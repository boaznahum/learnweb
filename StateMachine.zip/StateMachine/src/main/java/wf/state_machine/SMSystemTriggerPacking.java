package wf.state_machine;

/**
 * @author Boaz Nahum
 * @version WI VX.6, V12.0X, ADC V0.95
 */
final class SMSystemTriggerPacking {

    //private final TriggerPacking triggerPacking;
    private final SMStateVertex target;
    private final SMInternalTriggerData internalData;
    private final SystemTrigger systemTrigger;

    /**
     *
     * @param systemTrigger
     * @param target
     * @param internalData
     */
    SMSystemTriggerPacking(SystemTrigger systemTrigger,
                           SMStateVertex target,
                           SMInternalTriggerData internalData) {
        this.systemTrigger = systemTrigger;
        this.target = target;
        this.internalData = internalData;
    }

    /**
     * Pack system trigger with the original step user data
     */

    TriggerPacking getSystemTriggerPacking() {
        return new TriggerPacking(systemTrigger, internalData.getStepTrigger().getUserData(), null);
    }

    SMStateVertex getTarget() {
        return target;
    }

    SMInternalTriggerData getInternalData() {
        return internalData;
    }

    /**
     * Return the original trigger that this system trigger contained in it.
     */
    SMBaseTrigger getStepTrigger() {
        return internalData.getStepTrigger().getTrigger();
    }

}
