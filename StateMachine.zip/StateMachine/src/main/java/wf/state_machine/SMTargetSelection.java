package wf.state_machine;

/**
 * @author Boaz Nahum
 */
public interface SMTargetSelection {

    int DEFAULT = 0;

    /**
     * Select all available targets
     */
    int ALL = -1;

    int NONE = -1;
}
