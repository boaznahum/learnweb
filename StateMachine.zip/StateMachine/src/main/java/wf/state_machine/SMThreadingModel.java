package wf.state_machine;

/**
 * The threading model determines which thread will execute state machine steps
 * (calls to {@link StateMachine#handleTrigger(SMUTrigger)} }
 * @author Boaz Nahum
 * @version WI VX.6, V12.0X, ADC V0.95
 */

public enum SMThreadingModel {

    /**
     * Caller executes the entire step.
     * If upon ending there is more steps to execute then they will execute it's thread.
     * This is quite unfair, but it is the easiest model to implement.
     */
    Caller,
    /**
     * A single thread is dedicated fro processing all steps.
     * Caller of single step is return immediately after putting requests in queue.
     */
    SingleThread      

}
