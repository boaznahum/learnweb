package wf.state_machine;


/**
 * !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 * !! This interface is not intended to be implemented by client code
 * !! SM FW assumes that only its internal implementation exists
 * !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 * @author Boaz Nahum
 */
public interface SMTransition {

    /**
     * Define transition handlers.
     * <p/>
     * <ul>targetSelection == {@link SMTargetSelection#ALL}  all targets.</ul>
     * <ul>targetSelection == 0..N-1   one of n targets from list.</ul>
     * !! If targetSelection is not in range of target list then assert is thrown.
     */
    void onDo(SMTransitionHandler h,
              int targetSelection /* ALL all */);

    /**
     * Add handler to transition.
     * <p/>
     * Same as in  #addHandler
     * but instead of selection sub transition index you select it
     * by state target. targetState must be a member of targetList used
     * to define transition (otherwise assert is thrown).
     * If target is null, then all targets are used
     *
     * @see #onDo
     */

    void onDo(SMTransitionHandler h,
              SMState target);

    /**
     * See {@link #onDo(SMTransitionHandler, SMState)}.
     */
    void onDo(SMTransitionHandler h);

    /**
     * 'End' handlers are performed after the transition is completed - you exit the old state and entered the new one.
     * @param h
     * @param targetSelection
     */
    void onEndDo(SMTransitionHandler h,
                 int targetSelection /* ALL all */);

    void onEndDo(SMTransitionHandler h,
                 SMState target);
}
