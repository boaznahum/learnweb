package wf.state_machine;

/**
 * !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 * !! This interface is not intended to be implemented by client code
 * !! SM FW assumes that only its internal implementation exists
 * !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 * @author Boaz Nahum
 */
public interface SMTransitionGuardContext extends SMEventContext {
    SMStateVertex getSource();

    @Override
    SMBaseTrigger getTrigger();

    /**
     * Get the user data that was passed along with {@link #getTrigger()}
     * when calling {@link StateMachine#handleTrigger(SMUTrigger, Object)}
     * or {@link StateMachine#submitTrigger(SMTrigger, Object)}
     */
    @Override
    Object getTriggerData();

    /**
     * @return N Number of branches
     */
    int getN();

    /**
     * i in [0..N-1]
     */
    SMStateVertex getTarget(int i);

    SMTransition getTransition();

    /**
     * Find index of branch, so it can be used as return value in {@link SMGuard#select(SMTransitionGuardContext)}
     * @param state
     */
    int resolve(SMStateVertex state);

    // for GUI only
    SMGuard getGuard();

}
