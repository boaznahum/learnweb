package wf.state_machine;

@FunctionalInterface
public interface SMTransitionHandler extends SMHandler {

    /**
     * This method must not be called directly, Only via {@link SMTransitionHandlerExecutor}
     * @param i Current transition information
     */
    void handle(SMTransitionHandlerContext i);
}
