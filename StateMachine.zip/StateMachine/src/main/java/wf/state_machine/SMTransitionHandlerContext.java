package wf.state_machine;

/**
 * @author Boaz Nahum
 * @version x.5
 */
public interface SMTransitionHandlerContext extends SMHandlerContext {

    /**
     * return true if this is end of transition.
     * See {@link SMTransition#onEndDo(SMTransitionHandler, SMState)}
     */
    boolean endOfTransition();

    SMStateVertex getSource();

    SMStateVertex getTarget();

    /**
     * return a number in [0..N]
     */
    int getTargetSelection();

}
