package wf.state_machine;

class SMTransitionHandlerExecutor implements SMHandlerExecutor<SMTransitionHandler, SMTransitionHandlerContext> {

    private static SMTransitionHandlerExecutor mInstance;

    private SMTransitionHandlerExecutor() {
    }


    static SMTransitionHandlerExecutor get() {

        // no need to be thread safe, nothing wrong if create more than once
        if (mInstance == null) {
            mInstance = new SMTransitionHandlerExecutor();
        }

        return mInstance;
    }

    @Override
    public void execute(SMGlobalContext eventContext, SMTransitionHandlerContext eventInfo, SMTransitionHandler handler) {
        handler.handle(eventInfo);
    }

}


