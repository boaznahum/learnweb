package wf.state_machine;

import org.jetbrains.annotations.Nullable;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import wf.state_machine.outputers.DOMHelper;
import wf.state_machine.outputers.XMLAttributeAndValue;
import wf.state_machine.outputers.XMLContext;
import wf.state_machine.outputers.XMLWriteable;
import wf.state_machine.smlogger.SMLogEvent;
import wf.state_machine.smlogger.SMAuditor;

import java.lang.reflect.Method;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.function.Supplier;

/**
 * A transition may have from 1 to N branches.
 * You use sub classing because most of transitions are unary - have only one branch
 */
abstract class SMTransitionImp extends StateMachineElementImp implements SMTransition {

    @Nullable
    private final SMGuard guard;


    // lazy calculation
    @Nullable
    private Boolean guardGuaranteed;


    // create on demand
    @Nullable
    private TransitionHandlerList mCommonTransitionActions;

    @Nullable
    private TransitionHandlerList mCommonEndTransitionActions;


    /**
     * @param world
     * @param guard
     */
    SMTransitionImp(StateMachineImp world,
                 @Nullable SMGuard guard) {

        super(world);

        this.guard = guard;
    }

    /**
     * Define transition handlers.
     * <p/>
     * <ul>targetSelection == {@link SMTargetSelection#ALL}  all targets.</ul>
     * <ul>targetSelection == 0..N-1   one of n targets from list.</ul>
     * !! If targetSelection is not in range of target list then assert is thrown.
     */
    @Override
    public void onDo(final SMTransitionHandler h,
                     final int targetSelection /* ALL all */) {
        assert h != null;

        InternalCommand cmd = () -> addToTransitionList(h, targetSelection);

        getWorld().addStepCommand(cmd);
    }


    /**
     * 'End' handlers are performed after the transition is completed - you exit the old state and entered the new one.
     * @param h
     * @param targetSelection
     */
    @Override
    public void onEndDo(final SMTransitionHandler h,
                        final int targetSelection /* ALL all */) {
        if (h == null) {
            throw new SMDefinitionException("Handler can't be null");
        }

        InternalCommand cmd = () -> addToEndTransitionList(h, targetSelection);

        getWorld().addStepCommand(cmd);
    }

    /**
     * Add handler to transition.
     * <p/>
     * Same as in  #addHandler
     * but instead of selection sub transition index you select it
     * by state target. targetState must be a member of targetList used
     * to define transition (otherwise assert is thrown).
     * If target is null, then all targets are used
     *
     * @see #onDo
     */

    @Override
    public void onDo(SMTransitionHandler h,
                     SMState target) {
        assert h != null;

        int targetSelection =
            target != null ? getTargetSelector(target) : SMTargetSelection.ALL;

        onDo(h, targetSelection);
    }

    /**
     * See {@link #onDo(SMTransitionHandler, SMState)}.
     */
    @Override
    public void onDo(SMTransitionHandler h) {
        onDo(h, null);
    }

    @Override
    public void onEndDo(SMTransitionHandler h,
                        SMState target) {
        if (h == null) {
            throw new SMDefinitionException("Handler can't be null");
        }

        int targetSelection =
            target != null ? getTargetSelector(target) : SMTargetSelection.ALL;

        onEndDo(h, targetSelection);
    }


    @SuppressWarnings({"ClassReferencesSubclass"})
    static MemoryUnaryTransition createMemoryUnaryTransition(StateMachineImp world) {
        return new MemoryUnaryTransition(world);
    }

    static SMTransitionImp createTransition(StateMachineImp world,
                                         SMStateVertex[] targetStateList,
                                         SMGuard guard) {

        switch (targetStateList.length) {
            case 0:
                throw new SMDefinitionException("Must specify at least one target");

            case 1:
                return new UnaryTransition(world, (SMStateVertexImp)targetStateList[0], guard);

            case 2:
                return new BinaryTransition(world,
                                            (SMStateVertexImp)targetStateList[0],
                                            (SMStateVertexImp)targetStateList[1],
                                            guard);

            default:
                return new NaryTransition(world, targetStateList, guard);
        }
    }

    /**
     * Get with index checking
     *
     * @param i
     */
    private TransitionBranch getTransitionBranch(int i) {
        checkTransitionIndex(i);
        return getTransitionBranchNoCheck(i);
    }

    protected abstract TransitionBranch getTransitionBranchNoCheck(int i);


    @Override
    void init() {
        super.init();
    }

    @Override
    protected void checkValid() {
    }


    /**
     * targets are in range [0..N-1]
     */
    abstract int getN();


    final void checkTransitionIndex(int i) {

        int n = getN();

        if (i < 0 || i >= n) {
            throw new SMExecutionException(
                "Target index:" + i + " not in range:" +
                "0.." + (n - 1));
        }
    }

    // return true if this one branch transition with no guard

    final boolean is1Branch() {
        return getN() == 1 && !isGuardExists();
    }

    boolean isGuardExists() {
        return guard != null;
    }

    /**
     * A transition that guaranteed to find pah trough.
     */
    boolean isGuaranteed() {
        return (!isGuardExists() || guardIsGuaranteed())  && !endOnPossiblyImpassableTarget();
    }

    private boolean guardIsGuaranteed() {

        if ( guardGuaranteed != null) {
            return guardGuaranteed;
        }

        SMGuard theGuard  =  Objects.requireNonNull(guard);

        Method mSelect;
        try {
            /**
             * See {@link SMGuard#select(SMTransitionGuardContext)}
             */
            mSelect = SMGuard.MyMethod.getSelect(theGuard);
        } catch (NoSuchMethodException e) {
            throw new SMDefinitionException(e);
        }

        guardGuaranteed =  mSelect.isAnnotationPresent(SMGuaranteed.class);

        return guardGuaranteed;


    }

    @Nullable
    SMGuard getGuard() {
        return guard;
    }

    /**
     * Is one of the targets may refuse to let pass through them ?
     */
    private boolean endOnPossiblyImpassableTarget() {

        int n = getN();
        for (int i = 0; i < n; ++i) {
            SMStateVertexImp target = getTransitionBranchNoCheck(i).getTarget();
            if (target != null && target.possiblyImpassable()) {
                return true;
            }
        }

        return false;
    }


    /**
     * return 0 ( first branch selected) if selector is null
     * otherwise call selector
     */
    private int selectBranch(TriggerPacking triggerPacking,
                             SMStateVertex fromState) {
        if (guard == null) {
            return 0; // !!! always assume null selector return 0 - first and must have branch
        } else {

            TransitionGuardContextImp info =
                new TransitionGuardContextImp(getGlobalContext(), fromState, triggerPacking, this);

            int i = guard.select(info);

            if (i < 0 || i > getN()) {

                if (guardIsGuaranteed()) {

                    throw new SMExecutionException("In transition '" + this + "' guard '" + guard + "' select '" + i + "' but it promised to always select branch");

                }

                i = -1; // no branch selected


            }

            return i;

        }
    }

    // in following methods:
    //	targetSelection == 0..N-1   one of n targets from list

    SMStateVertexImp getBranchTarget(int targetSelection) {
        return getTransitionBranch(targetSelection).getTarget();
    }


    /**
     * Find target index in list of targets
     * throw assert if not found
     * return:
     *
     * @return 0 .. N-1
     */
    private int getTargetSelector(SMState fromState) {

        int n = getN();
        for (int i = 0; i < n; ++i) {
            //noinspection ObjectEquality
            if (getTransitionBranchNoCheck(i).getTargetAssert() == fromState) {
                return i;
            }
        }

        throw new SMExecutionException("Target " + fromState + " not in transition");
    }

    boolean transitionHandlersExists(int targetSelection) {
        return mCommonTransitionActions != null ||
               getTransitionBranch(targetSelection).transitionHandlersExist();
    }

    /**
     * @param trigger
     * @param target is not necessary same as {@link SMTransitionImp#getBranchTarget(int)}
     * because some targets as {@link ReturnPoint} choose not to allow pass through them
     */
    private SMTransitionHandlerContext createActionData(final SMStateVertex source,
                                                        final TriggerPacking trigger,
                                                        final int targetSelection,
                                                        final SMStateVertex target,
                                                        final boolean isEndOf) {

        return new TransitionHandlerContextImpl(getGlobalContext(),
                                                isEndOf,
                                                source,
                                                trigger,
                                                target,
                                                targetSelection);
    }

    void executeTransitionHandlers(StateMachineImp world,
                                   TriggerPacking triggerPacking,
                                   SMStateVertex sourceState,
                                   int targetSelection,
                                   SMStateVertex target) {
        if (transitionHandlersExists(targetSelection)) {

            // this is a problem, we create supplier even not in use
            Supplier<SMTransitionHandlerContext> actionData = ()->createActionData(
                sourceState,
                triggerPacking,
                targetSelection,
                target,
                false);

            TransitionHandlerList.execute(
                world, mCommonTransitionActions,
                actionData);

            getTransitionBranch(targetSelection).executeTransitionHandlers(world, actionData);
        }
    }

    boolean endTransitionHandlersExists(int targetSelection) {
        return mCommonEndTransitionActions != null ||
               getTransitionBranch(targetSelection).endTransitionHandlersExist();
    }

    void executeEndTransitionActions(StateMachineImp world,
                                     TriggerPacking triggerPacking,
                                     SMStateVertex sourceState,
                                     int targetSelection,
                                     SMStateVertex target) {
        if (endTransitionHandlersExists(targetSelection)) {

            // this is a problem, we create supplier even not in use
            Supplier<SMTransitionHandlerContext> actionData = ()->createActionData(
                sourceState,
                triggerPacking,
                targetSelection,
                target,
                true);

            TransitionHandlerList.execute(
                world, mCommonEndTransitionActions,
                actionData);

            getTransitionBranch(targetSelection).executeEndTransitionHandlers(world, actionData);
        }
    }


    private void addToTransitionList(SMTransitionHandler h,
                                     int targetSelection /* ALL all */) {
        if (targetSelection == SMTargetSelection.ALL) {
            mCommonTransitionActions =
                TransitionHandlerList.add(mCommonTransitionActions, h);
        } else {
            getTransitionBranch(targetSelection).addToTransitionList(h);
        }
    }


    private void addToEndTransitionList(SMTransitionHandler h,
                                        int targetSelection /* ALL all */) {
        if (targetSelection == SMTargetSelection.ALL) {
            mCommonEndTransitionActions =
                TransitionHandlerList.add(mCommonEndTransitionActions, h);
        } else {
            getTransitionBranch(targetSelection).addToEndTransitionList(h);
        }
    }

    /**
     * find a path to destination target
     * return a list of SMTransitionSegment
     */
    final LinkedList<SMTransitionSegmentImp> findPathThrough(SMStateImp beginOfPath,
                                                             SMStateVertexImp source,
                                                             TriggerPacking triggerPacking) {
        return findPathThrough(null, beginOfPath, source, triggerPacking);
    }

    /**
     * find a path  to destination target
     * return a list of SMTransitionSegment
     * this will add segment [source ...]
     *
     * @param pathSoFar If path is found then the segment [source .. selected-target]
     * is added to pathSoFar and then the rest of path from selected-target.
     * If no path found then pathSoFar is not modified.
     * @param triggerPacking
     * @return null if no branch is selected or the selected target is a
     *         {@link SMStateVertex} which no pass through (as in case of {@link StaticChoicePoint})
     */
    final LinkedList<SMTransitionSegmentImp> findPathThrough(LinkedList<SMTransitionSegmentImp> pathSoFar,
                                                             SMStateImp beginOfPath,
                                                             SMStateVertexImp source,
                                                             TriggerPacking triggerPacking) {
        boolean debuggerIsOn = isLoggerOn();

        if (debuggerIsOn) {

            int n = getN();
            SMStateVertex[] targets = new SMStateVertex[n];

            for (int i = 0; i < n; ++i) {
                targets[i] = getTransitionBranchNoCheck(i).getTarget();
            }

            logQueryingTransitionGuard(
                SMLogEvent.BEGIN_QUERYING_TRANSITION,
                source,
                triggerPacking.getTrigger(),
                guard,
                targets);
        }

        int branchNumber = selectBranch(triggerPacking, source);

        final SMStateVertexImp target;
        if (branchNumber < 0) {
            target = null;
        } else {
            target = getBranchTarget(branchNumber);
        }

        if (debuggerIsOn) {
            logEndQueryingTransitionGuard(
                SMLogEvent.END_QUERYING_TRANSITION,
                source,
                triggerPacking.getTrigger(),
                guard,
                target);
        }

        if (target == null) {
            return null; // no pathSoFar
        } else {
            if (pathSoFar == null) {
                pathSoFar = new LinkedList<>();
            }

            LinkedList<SMTransitionSegmentImp> pathFound = target.addYourSegmentAndFindPathThrough(
                pathSoFar,
                beginOfPath,
                source,
                triggerPacking, 
                this,
                branchNumber);

            return pathFound;

        }
    }

    /**
     * Check that branches are paths are in(or on) container.
     * If not, then return the first SMStateVertex that is not in container.
     * If all are in container then return null.
     */
    List<SMStateVertex> isAllPathTroughIsInContainer(SMComplexStateImp container,
                                                     boolean onEdgeIsOk) {
        int n = getN();

        for (int i = 0; i < n; ++i) {
            SMStateVertexImp target = getBranchTarget(i);

            if (target != null) {
                List<SMStateVertex> l = target.isAllPathTroughIsInContainer(container, onEdgeIsOk);

                if (l != null) {
                    return l;
                }
            }
        }

        return null; //OK !!!  All are in container
    }


    // ================ Logger support ===============================

    private void logQueryingTransitionGuard(SMLogEvent logEvent,
                                            SMStateVertex source,
                                            SMBaseTrigger trigger,
                                            SMGuard guard,
                                            SMStateVertex[] targets) {

        StateMachineImp sm = getWorld();

        SMAuditor logger = sm.getLogger();

        if (logger == null) {
            return;
        }

        logger.logQueryingTransitionGuard(logEvent,
                                          sm,
                                          source,
                                          trigger,
                                          guard,
                                          targets);


    }

    /**
     *
     * @param logEvent
     * @param source
     * @param trigger
     * @param guard
     * @param selectedTarget null if non was selected
     */
    private void logEndQueryingTransitionGuard(SMLogEvent logEvent,
                                               SMStateVertex source,
                                               SMBaseTrigger trigger,
                                               @Nullable SMGuard guard,
                                               @Nullable SMStateVertex selectedTarget) {

        StateMachineImp sm = getWorld();

        SMAuditor logger = sm.getLogger();

        if (logger == null) {
            return;
        }

        logger.logEndQueryingTransitionGuard(logEvent,
                                          sm,
                                          source,
                                          trigger,
                                          guard,
                                          selectedTarget);


    }


    // ================ DOM support ===============================

    public void writeTo(XMLContext xmlContext, Node myNode) {
        DOMHelper.addAndWrite(xmlContext, this, myNode);
    }

    // ====================================================================
    // for debug only

    private XMLWriteable getBranchesAsXML() {

        return new XMLWriteable() {

            @Override
            public String getElementName() {
                return "branches";
            }

            @Override
            public XMLAttributeAndValue[] getAttributes() {
                return null;
            }

            @Override
            public void writeBody(XMLContext xmlContext, Element inNode) {
                int n = getN();

                for (int i = 0; i < n; ++i) {

                    Element branchElement = DOMHelper.domAddElement(inNode, "branch");

                    branchElement.setTextContent("" + getBranchTarget(i));
                }

            }

        };

    }


    @Override
    public String getElementName() {
        return "transition";
    }

    @Override
    public XMLAttributeAndValue[] getAttributes() {
        return null;
    }

    @Override
    public void writeBody(XMLContext xmlContext, Element inNode) {
        DOMHelper.addAndWrite(xmlContext, getBranchesAsXML(), inNode);
    }


}