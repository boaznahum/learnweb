package wf.state_machine;

/**
 * !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 * !! This interface is not intended to be implemented by client code
 * !! SM FW assumes that only its internal implementation exists
 * !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 *
 * This class is used only for logging and debugging

 * @author Boaz Nahum
 */

public interface SMTransitionSegment {

    SMStateVertex getSource();

    SMBaseTrigger getTrigger();

    SMStateVertex getTarget();
}
