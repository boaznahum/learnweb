package wf.state_machine;

import java.util.List;

public abstract class SMTransitionSegmentImp implements SMTransitionSegment {

    private final SMStateImp mBeginOfPath;

    private final SMStateVertexImp mSource;

    /**
     * in case of 'and' event, it will be differ from the original event
     */
    private final TriggerPacking triggerPacking;
    
    private final SMStateVertexImp mTarget;
    

    SMTransitionSegmentImp(SMStateImp beginOfPath,
                        SMStateVertexImp source,
                        TriggerPacking triggerPacking,
                        SMStateVertexImp target) {
        mBeginOfPath = beginOfPath;
        mSource = source;
        this.triggerPacking = triggerPacking;
        mTarget = target;
    }

    final SMStateImp getBeginOfPath() {
        return mBeginOfPath;
    }

    @Override
    public final SMStateVertex getSource() {
        return getSourceInternal();
    }

    final SMStateVertexImp getSourceInternal() {
        return mSource;
    }

    final TriggerPacking getTriggerPacking() {
        return triggerPacking;
    }

    @Override
    public final SMBaseTrigger getTrigger() {
        return triggerPacking.getTrigger();
    }

    @Override
    public final SMStateVertex getTarget() {
        return mTarget;
    }

    final SMStateVertexImp getTargetInternal() {
        return mTarget;
    }

    boolean transitionHandlersExists() {
        return false;
    }

    void executeTransitionHandlers(StateMachineImp world) {
    }

    boolean endTransitionHandlersExists() {
        return false;
    }

    void executeEndTransitionHandlers(StateMachineImp world) {
    }

    /**
     * @param target is not necessary same as {@link SMTransitionImp#getBranchTarget(int)}
     * because some targets as {@link ReturnPoint} choose not to allow pass through them
     */ 
    static SMTransitionSegmentImp create(SMStateImp beginOfPath,
                                    SMStateVertexImp source,
                                    SMTransitionImp tran,
                                    int targetSelection,
                                    TriggerPacking triggerPacking,
                                    SMStateVertexImp target) {
        return new DefTransitionSegment(beginOfPath,
                source,
                tran,
                targetSelection,
                triggerPacking,
                target);

    }

    static SMTransitionSegmentImp createSimple(SMStateImp beginOfPath,
                                          SMStateVertexImp source,
                                          TriggerPacking triggerPacking,
                                          SMStateVertexImp target) {
        return new SimpleTransitionSegment(beginOfPath,
                source,
                triggerPacking,
                target);

    }

    /**
     * if continuePath is null then return null
     * else if pathSoFar is null return continuePath
     * else add continuePath to pathSoFar and return pathSoFar
     */
    static List<SMTransitionSegmentImp> add(List<SMTransitionSegmentImp> pathSoFar,
                                       List<SMTransitionSegmentImp> continuePath) {
        if (continuePath == null) {
            return null;
        }
        else {
            if (pathSoFar == null) {
                return continuePath;
            }
            else {
                pathSoFar.addAll(continuePath);
                return pathSoFar;
            }
        }
    }

    private static class SimpleTransitionSegment extends SMTransitionSegmentImp {


        SimpleTransitionSegment(SMStateImp beginOfPath,
                                SMStateVertexImp source,
                                TriggerPacking triggerPacking,
                                SMStateVertexImp target) {
            super(beginOfPath, source, triggerPacking, target);
        }
    }

    private static class DefTransitionSegment extends SMTransitionSegmentImp {

        private final SMTransitionImp mTransition;
        private final int mIndex; // in mTransition

        DefTransitionSegment(SMStateImp beginOfPath,
                             SMStateVertexImp source,
                             SMTransitionImp tran,
                             int targetSelection,
                             TriggerPacking triggerTrigger,
                             SMStateVertexImp target) {
            super(beginOfPath, source, triggerTrigger, target);

            mTransition = tran;
            mIndex = targetSelection;
        }

        @Override
        boolean transitionHandlersExists() {
            return mTransition.transitionHandlersExists(mIndex);
        }

        @Override
        void executeTransitionHandlers(StateMachineImp world) {
            mTransition.executeTransitionHandlers(
                    world,
                    getTriggerPacking(),
                    getSource(),
                    mIndex,
                    getTarget());
        }

        @Override
        boolean endTransitionHandlersExists() {
            return mTransition.endTransitionHandlersExists(mIndex);
        }

        @Override
        void executeEndTransitionHandlers(StateMachineImp world) {
            mTransition.executeEndTransitionActions(world,
                    getTriggerPacking(),
                    getSource(),
                    mIndex,
                    getTarget());
        }
    }

}
