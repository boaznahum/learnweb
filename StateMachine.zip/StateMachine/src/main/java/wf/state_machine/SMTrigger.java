package wf.state_machine;

public interface SMTrigger extends SMBaseTrigger {

    @Override
    String getName();
}
