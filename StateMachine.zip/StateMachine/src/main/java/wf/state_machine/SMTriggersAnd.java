package wf.state_machine;

/**
 * !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 * !! This interface is not intended to be implemented by client code
 * !! SM FW assumes that only its internal implementation exists
 * !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 *
 * If you need to define and event and use it only once, then use
 * {@link SMState#defineAndTrigger(wf.state_machine.SMTrigger, wf.state_machine.SMTrigger, wf.state_machine.SMTrigger...)}
 *
 * If you need to use it more than once then you have to options:
 *
 * 1. Use {@link #create(SMTrigger, SMTrigger...)}
 * 2. Use wf.state_machine.SMState#defineAndTrigger(wf.state_machine.SMTrigger, wf.state_machine.SMTrigger, wf.state_machine.SMTrigger...)
 * and save the value returned by it.

 *
 * @author Boaz Nahum
 */
public interface SMTriggersAnd {


    /**
     *
     */

    static SMTriggersAnd create(SMTrigger e1, SMTrigger... triggers) {
        return new SMTriggersAndImp(e1, triggers);
    }

}
