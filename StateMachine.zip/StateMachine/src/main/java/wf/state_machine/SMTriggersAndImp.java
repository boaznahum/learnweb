package wf.state_machine;

/**
 * The components of complex 'AND' trigger.
 */
final class SMTriggersAndImp implements SMTriggersAnd {

    private final SMTrigger[] subTriggers;

    public SMTriggersAndImp(SMTrigger e1, SMTrigger... triggers) {

        subTriggers = new SMTrigger[1 + triggers.length];

        subTriggers[0] = e1;

        int p = 0;
        for (SMTrigger ue : triggers) {
            subTriggers[++p] = ue;
        }
    }


    boolean completeAndEventInQueue(TriggerQueue triggerQueue) {
        return triggerQueue.containsAll(subTriggers);
    }

    void removeAndEventsFromAndQueue(TriggerQueue triggerQueue) {
        for (SMTrigger andComponent : subTriggers) {
            triggerQueue.remove(andComponent, false);
        }
    }

    // ====================================================================
    // for debug only
    /**
     * return A * B * C
     */
    @Override
    public String toString() {
        StringBuilder s = new StringBuilder();

        boolean isFirst = true;
        for (SMTrigger subTrigger : subTriggers) {

            if (isFirst) {
                isFirst = false;
            } else {
                s.append(" * ");
            }
            s.append(subTrigger.getName());
        }

        return s.toString();
    }

    /**
     * Iterator over the components of the 'AND' events
     */
    SMTrigger[] parts() {
        return subTriggers;
    }
}
