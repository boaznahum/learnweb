package wf.state_machine;

/**
 * User defined trigger.
 *
 * Because this is an interface yuu can implement is as enum:
 *
 * <pre>
 *     {@code
 *         private enum MyEvents implements SMUTrigger {

                E1,
                E2
                E3

                @Override
                public String getName() {
                    return super.name();
                }
        }

 *     }
 * </pre>
 *
 * To create simple trigger use {@link SMUTrigger#create(String)}
 *
 * Impementation nore: must have {@link #hashCode()} and {@link #equals(Object)}
 *
 *
 * @author Boaz Nahum
 * @version WI VX.6, V12.0X, ADC V0.95
 */

public interface SMUTrigger extends SMTrigger {

    /**
     * Default so you don't need to implement for enum
     */
    @Override
    default String getName() { return toString(); }

    static SMUTrigger create(String name) {return new SMSimpleTrigger(name);}
}
