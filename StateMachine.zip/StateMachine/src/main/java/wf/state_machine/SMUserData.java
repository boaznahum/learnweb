package wf.state_machine;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 * !! This interface is not intended to be implemented by client code
 * !! SM FW assumes that only its internal implementation exists
 * !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

 * A key value data.

 * @author Boaz Nahum
 */

public interface SMUserData {

    void setTrue(String key);

    boolean isTrue(String key);

    String getString(String key);

    void setString(String key, String data);

    @NotNull
    AtomicInteger getCounter(String key);

    @Nullable
    AtomicInteger hasCounter(String key);
}
