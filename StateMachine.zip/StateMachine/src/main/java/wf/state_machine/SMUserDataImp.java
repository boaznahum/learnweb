package wf.state_machine;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;


/**
 * @author Boaz Nahum
 */

class SMUserDataImp implements SMUserData {

    private final Map<String, Object> data = new HashMap<>();



    @Override
    public synchronized void setTrue(String key) {

        Boolean c = getData(Boolean.class, key);

        if (! Boolean.TRUE.equals(c)) {
            put(key, Boolean.TRUE);
        }
    }

    @Override
    public synchronized boolean isTrue(String key) {

        Boolean c = getData(Boolean.class, key);

        return Boolean.TRUE.equals(c);
    }

    @Override
    public String getString(String key) {

        String c = getData(String.class, key);

        return c;


    }

    @Override
    public void setString(String key, String data) {
        put(key, data);
    }


    @Override
    @NotNull
    public synchronized AtomicInteger getCounter(String key) {

        AtomicInteger c = getData(AtomicInteger.class, key);

        if (c == null ) {
            c = new AtomicInteger();

            put(key, c);
        }

        return c;

    }

    @Override
    @Nullable
    public synchronized AtomicInteger hasCounter(String key) {

        AtomicInteger c = getData(AtomicInteger.class, key);

        return c;

    }


    private void put(String key, Object data) {
        this.data.put(key, data);
    }

    private <T> T getData(Class<T> aClass, String key) {

        Object o = data.get(key);

        if (o == null) {
            return null;
        }

        return aClass.cast(o);

    }
}
