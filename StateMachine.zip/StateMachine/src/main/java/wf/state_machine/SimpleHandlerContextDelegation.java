package wf.state_machine;

/**
 * @author Boaz Nahum
 */

class SimpleHandlerContextDelegation extends HandlerContextImpl implements SMSimpleHandlerContext {

    SimpleHandlerContextDelegation(EventContextImpl delegatee) {
        super(delegatee.getGlobalContext(), delegatee.getTriggerPacking());

    }
}
