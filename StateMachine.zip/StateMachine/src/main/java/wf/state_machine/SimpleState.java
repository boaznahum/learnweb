package wf.state_machine;

final class SimpleState extends SMStateImp {
    SimpleState(SMCompositeStateImp parent, String sid) {
        super(parent.getWorld(), parent, sid);
    }

    @Override
    final String getTypeName() {
        return "Simple";
    }

    // ====================================================================
    // for debug only
    @Override
    public String getElementName() {
        return "SimpleState";
    }


}