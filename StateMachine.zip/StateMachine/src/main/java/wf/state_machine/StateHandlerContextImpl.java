package wf.state_machine;

/**
 * @author Boaz Nahum
 */
class StateHandlerContextImpl extends HandlerContextImpl implements SMStateHandlerContext {

    private SMStateImp smStateImp;
    private final SMStateHandlerType type;
    private final SMStateVertex source;
    private final SMStateVertex target;

    StateHandlerContextImpl(SMGlobalContext globalContext,
                            SMStateImp smStateImp, SMStateHandlerType type, SMStateVertex source,
                            TriggerPacking triggerPacking,
                            SMStateVertex target) {
        super(globalContext, triggerPacking);
        this.smStateImp = smStateImp;
        this.type = type;
        this.source = source;
        this.target = target;
    }

    @Override
    public SMStateHandlerType getType() {
        return type;
    }

    @Override
    public SMStateVertex getThisState() {
        return smStateImp;
    }

    @Override
    public SMStateVertex getSource() {
        return source;
    }




    @Override
    public SMStateVertex getTarget() {
        return target;
    }
}
