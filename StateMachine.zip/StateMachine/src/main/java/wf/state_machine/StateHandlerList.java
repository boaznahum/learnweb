package wf.state_machine;

import java.util.function.Supplier;

final class StateHandlerList extends HandlerList<SMStateHandler, SMStateHandlerContext> {

    void execute(StateMachineImp world, Supplier<SMStateHandlerContext> data) {

        SMStateHandlerExecutor executor =
                SMStateHandlerExecutor.get();

        execute(world, data, executor);
    }

    static StateHandlerList add(StateHandlerList list,
                                SMStateHandler h) {
        if (list == null) {
            list = new StateHandlerList();
        }

        list.addLast(h);

        return list;
    }

}

