package wf.state_machine;



/**
 * map between state name to it's instance.
 */
class StateIDMap extends StateVertexIDMap<SMStateImp> {

    final void resetEventQueues() {

        for( SMStateImp s:values()) {
            s.resetTriggerQueues();
        }
    }

    final SMStateImp[] getAllStates() {
        SMStateImp[] sts = new SMStateImp[size()];

        return values().toArray(sts);
    }
}