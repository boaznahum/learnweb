package wf.state_machine;

import org.jetbrains.annotations.Nullable;
import org.w3c.dom.Document;
import wf.state_machine.outputers.XMLContext;
import wf.state_machine.smlogger.SMAuditor;

import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/**
 * @author Boaz Nahum
 */

public interface StateMachine {


    //////////////////////////////////////////////////////////////////////
    // Factory methods:


    /**
     * Factory method
     *
     * @param name
     * @param threadingModel
     */
    static StateMachine createStateMachine(String name, SMThreadingModel threadingModel) {
        return new StateMachineImp(name, threadingModel);
    }

    /**
     * Factory method
     *
     * @param name
     */
    static StateMachine createStateMachine(String name) {return new StateMachineImp(name);}


    /**
     * Multi Threading: No issue.
     */
    String getName();


    //////////////////////////////////////////////////////////////////////
    // Constructing state machine:
    //


    /**
     * Multi Threading: No side effects. No issue if called after definition phase.
     * If called during definition phase then thread safety is the caller responsibility.
     */
    SMCompositeState getTopLevel();

    /**
     * Search for a state {@link SMComplexState#getState(String)} in {@link #getTopLevel()}
     *
     * @return may be null
     */
    @Nullable
    SMStateVertex getState(String name);

    /**
     * Multi Threading: Can be called only in phase of definition, so thread safety is the caller responsibility.
     */
    @SuppressWarnings({"OverloadedVarargsMethod"})
    void defineTriggers(SMUTrigger... triggers);

    /**
     * Define all Enum entries as triggers
     * Example:
     *
     * <pre>
     *     {@code
     *     private enum T implements SMUTrigger {

                ON, OFF, GO, END, PAUSE,RESUME;

                @Override
                public String getName() {
                    return name();
                }
            }

            sm.defineTriggers(T.class);

     * }
     *
     * </pre>
     *
     * @param type
     * @param <T>
     */
    <T extends Enum & SMUTrigger> void defineTriggers(Class<T> type);

    /**
     * Sugaring: Create {@link SMUTrigger#create(String)} and define {@link #defineTrigger(String)}
     *
     * @param triggerName
     * @return the new created trigger. It is already defined in SM so you don't need to call {@link #defineTrigger(String)}
     */
    SMUTrigger defineTrigger(String triggerName);


    //////////////////////////////////////////////////////////////////////
    // Handling state machine after constructing:
    // init and triggers
    //


    /**
     * This also end the definition phase.
     * Multi Threading: All queues are reset by the calling thread. Initialization is actually performed by
     * owner thread. See {@link #handleTrigger(SMUTrigger)}
     */
    Future<Object> init();

    /**
     * Submit trigger  {@link #handleTrigger(SMUTrigger)} in the future
     *
     * @param trigger
     * @param delay
     * @param timeUnit
     * @return See discussion in {@link SMScheduledFutureTrigger#cancel(boolean)}
     */
    SMScheduledFutureTrigger scheduleTrigger(SMUTrigger trigger, int delay,
                                             TimeUnit timeUnit);

    /**
     * Processing is done in caller's thread or on dedicated thread.
     * See {@link SMThreadingModel}
     *
     * @param trigger
     * @param userData this data is passed to handlers
     */
    void handleTrigger(SMUTrigger trigger, @Nullable Object userData);

    /**
     * Submit a trigger.
     * <p>
     * Processing is done in caller's thread or on dedicated thread.
     * See {@link SMThreadingModel}
     *
     * @param trigger
     */
    void handleTrigger(SMUTrigger trigger);

    /**
     * Submit a trigger and return a future to it.
     * <p>
     * Processing is done in caller's thread or on dedicated thread.
     * See {@link SMThreadingModel}
     * <p>
     * The future is set after trigger is handled, or canceled if queue is cleared from some reason
     * (for example call to init() }
     */
    Future<Object> submitTrigger(SMTrigger trigger);


    /**
     * Submit a trigger and return a future to it.
     * <p>
     * Processing is done in caller's thread or on dedicated thread.
     * See {@link SMThreadingModel}
     * <p>
     * The future is set after trigger is handled, or canceled if queue is clear from some reason
     * (for example call to init() }
     */
    Future<Object> submitTrigger(SMTrigger trigger, @Nullable Object userData);

    /**
     * Run async action.
     * <p>
     * If operation succeeded then trigger {@code successTrigger} if not null
     * otherwise, trigger {@code failTrigger} if not null or {@code successTrigger} if not null
     * <p>
     * @param context The context in which this asction is running
     * @param successTrigger If operation succeeded then trigger {@code successTrigger} if not null
     * @param failureTrigger If operation failed, trigger {@code failTrigger} if not null or {@code successTrigger} if not null
     * @param action
     */
    void runSync(SMEventContext context, @Nullable SMUTrigger successTrigger, @Nullable SMUTrigger failureTrigger,
                 SMSimpleHandler action);

    /**
     * Run async action.
     * <p>
     * If operation succeeded then trigger {@code successTrigger} if not null
     * otherwise, trigger {@code failTrigger} if not null or {@code successTrigger} if not null
     * <p>
     * <p>
     * <p>
     * //todo:boaz:fix: Return more specific cancelable that support all features as in {@link SMState#betweenEntryExitDo(boolean, boolean, SMUTrigger, SMUTrigger, SMUTrigger, SMStateHandler)}
     * ////todo:boaz:fix: trace the created threads/task and add the ability to wait on them (this is the reason it is method of State machine)
     * @param context The context in which this asction is running
     * @param cancelByInterrupt in case {@code async} is true, SM FW will try to cancel thread that is running the handler by {@link Thread#interrupt()}
     * @param successTrigger If operation succeeded then trigger {@code successTrigger} if not null
     * @param failureTrigger If operation failed, trigger {@code failTrigger} if not null or {@code successTrigger} if not null
     * @param cancelingTrigger The trigger to submit in case of cancellation
     * @param action
     */
    Future<Void> runAsync(SMEventContext context, boolean cancelByInterrupt, @Nullable SMUTrigger successTrigger,
                          @Nullable SMUTrigger failureTrigger, @Nullable SMUTrigger cancelingTrigger, SMSimpleHandler action);

    //////////////////////////////////////////////////////////////////////
    // Diagnostics and debugging
    //
    // Use these method with great care - they are here for debugging and not for modeling state machine
    // ! In many cases they might report a transient state !
    // Don't use them to affect your model behaviour


    //

    /**
     * @param logger
     * @throws SMDefinitionException if logger already attached.
     */
    void attachTo(SMAuditor logger);

    /**
     * Multi Threading: No side effects. But result may be transient.
     */
    SMStatePathTree getLastKnownCurrentStatePathTree();


    /**
     * Is definition of machine ended ?
     */
    boolean debugIsMachineDefinitionEnded();

    /**
     * Multi Threading: List of defined triggers can't change after definition end. If called at definition phase then
     * thread safety is the caller responsibility.
     */
    SMUTrigger[] debugGetAllDefinedTriggers();

    /**
     * Including user & system triggers
     */
    String[] debugGetAllDefinedTriggersNames();

    /**
     * All real and pseudo states
     */
    String[] debugGetAllStates();

    /**
     * Return triggers in 'main' queue and in 'in step' queues.
     * Multi Threading: No side effects, but results may be undefined.
     */
    String[] debugGetTriggerQueue();

    SMThreadingModel debugGetThreadingModel();

    /**
     * Write statistics into System.out }
     */
    void debugWriteStatistics();

    void writeToDOM(XMLContext xmlContext, Document doc);



}
