package wf.state_machine;

/**
 * !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 * !! This interface is not intended to be implemented by client code
 * !! SM FW assumes that only its internal implementation exists
 * !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 * @author Boaz Nahum
 */
interface StateMachineElement {

    void clearUserData();

    /**
     * Never !!! keep reference between methods call !!! {@link #clearUserData()} may be called
     */
    SMUserData getUserData();
}
