package wf.state_machine;

import wf.state_machine.outputers.XMLWriteable;

@SuppressWarnings({"ClassReferencesSubclass"})
abstract class StateMachineElementImp extends BaseStateMachineElement implements XMLWriteable, StateMachineElement {

    private SMUserData userData;

    StateMachineElementImp(StateMachineImp world) {
        super(world);
    }

    protected abstract void checkValid();

    void init() {
        userData = null;
    }



    final SMCompositeState getTopLevel() {
        return getWorld().getTopLevel();
    }

    /**
     * Ensure that:
     * SM is busy executing step.
     * Call is made from the thread that is executing the current step.
     */
    private void ensureValidThread() {
        getWorld().ensureValidThreadInStepCall();
    }

    void setModified() {
        getWorld().setModified();
    }

    @Override
    public final synchronized void clearUserData() {

        ensureValidThread();

        userData = null;
    }

    /**
     * Never !!! keep reference between methods call !!! {@link #clearUserData()} may be called
     */
    @Override
    public final synchronized SMUserData getUserData() {

        ensureValidThread();

        if ( userData == null ) {
            userData = new SMUserDataImp();
        }

        return userData;
    }

}