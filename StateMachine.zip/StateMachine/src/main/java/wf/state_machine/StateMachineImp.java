package wf.state_machine;

import org.jetbrains.annotations.Nullable;
import org.w3c.dom.Document;
import wf.state_machine.outputers.XMLContext;
import wf.state_machine.smlogger.SMAuditor;
import wf.state_machine.smlogger.SMLogEvent;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;


final class StateMachineImp implements StateMachine {

    /**
     * we use LinkedHashSet to keep order of insertion
     */
    private final Set<SMUTrigger> definedUserTriggers = new LinkedHashSet<>();


    private final TopLevelState mTopLevel;


    private final SMEventProcessor eventProcessor;

    /**
     * Create on demand
     */
    private volatile SMDelayedTriggersHandler delayedTriggersHandler;

    //====================================================================

    private boolean definitionEnded;


    // for now we hold just one debugger
    private SMAuditor mLogger;

    private long mModificationCounter;
    private long mLastCheckModificationCounter = -1; // mModificationCounter > mLastCheckModificationCounter

    private volatile SMGlobalContextImp context;


    /**
     * Constructs a new state machine object with top level state
     *
     * @param name name of top level state, see {@link #getTopLevel}
     */
    StateMachineImp(String name, SMThreadingModel threadingModel) {
        //noinspection ThisEscapedInObjectConstruction
        mTopLevel = new TopLevelState(this, name);
        eventProcessor = new SMEventProcessor(this, threadingModel);
    }

    StateMachineImp(String name) {
        this(name, SMThreadingModel.Caller);
    }

    /**
     * Multi Threading: No issue.
     */
    @Override
    public String getName() {
        return mTopLevel.getName();
    }


    /**
     * Multi Threading: Can be called only in phase of definition, so thread safety is the caller responsibility.
     */
    @Override
    @SuppressWarnings({"OverloadedVarargsMethod"})
    public final void defineTriggers(SMUTrigger... triggers) {

        for (SMUTrigger trigger : triggers) {
            doDefineTrigger(trigger);
        }
    }

    @Override
    public <T extends Enum & SMUTrigger> void defineTriggers(Class<T> type) {
        T[] enumS = type.getEnumConstants();
        defineTriggers(enumS);
    }

    @Override
    public SMUTrigger defineTrigger(String triggerName) {

        SMUTrigger trigger = SMUTrigger.create(triggerName);

        defineTriggers(trigger);

        return trigger;
    }


    /**
     * for debug - convert a name to trigger
     * <p/>
     * Multi Threading: No side effects. List of defined triggers can't change after definition end. If called during definition phase then
     * thread safety is the caller responsibility.
     *
     * @return null if not legal trigger. See {@link #defineTriggers(SMUTrigger...)}
     */
    @SuppressWarnings({"UnusedDeclaration"})
    public SMTrigger debugGetTriggerByName(String name) {

        for (SMTrigger trigger : definedUserTriggers) {
            String triggerName = trigger.getName();

            if (triggerName.compareToIgnoreCase(name) == 0) {
                return trigger;
            }
        }

        return null;

    }

    /**
     * Multi Threading: No side effects. No issue if called after definition phase.
     * If called during definition phase then thread safety is the caller responsibility.
     */
    @Override
    public SMCompositeState getTopLevel() {
        return getTopLevelInternal();
    }

    void traceAsyncAction(CompletableFuture<Void> future) {

        ////todo:boaz:fix: add tracing of uncompleted actions
        future.whenComplete((t,e)->{

            if (future.isCancelled()) {
                return;
            }

            if (e != null) {
                eventProcessor.handleAsyncError(e);
            }
        });




    }

    final SMCompositeStateImp getTopLevelInternal() {
        return mTopLevel;
    }

    /**
     * Search for a state in {@link #getTopLevel()}
     *
     * @return may be null
     */
    @Override
    public final SMStateVertex getState(String name) {
        return getTopLevel().getState(name);
    }

    /**
     * This also end the definition phase.
     * Multi Threading: All queues are reset by the calling thread. Initialization is actually performed by
     * owner thread. See {@link #handleTrigger(SMUTrigger)}
     */
    @Override
    public final Future<Object> init() {

        // was checked since last modification ?
        if (mLastCheckModificationCounter < mModificationCounter) {
            checkValid();
        }

        /** We assume that user call init after he finish to define machine.
         /*  This flag is reset in {@link #setModified() }
         */
        definitionEnded = true;

        return eventProcessor.init();
    }


    /**
     * Submit trigger  {@link #handleTrigger(SMUTrigger)} in the future
     *
     * @param trigger
     * @param delay
     * @param timeUnit
     * @return See discussion in {@link SMScheduledFutureTrigger#cancel(boolean)}
     */
    @Override
    public SMScheduledFutureTrigger scheduleTrigger(final SMUTrigger trigger, int delay,
                                                    TimeUnit timeUnit) {


        if (delayedTriggersHandler == null) {
            synchronized (this) {
                if (delayedTriggersHandler == null) {
                    delayedTriggersHandler = new SMDelayedTriggersHandler(this);
                }
            }
        }


        return delayedTriggersHandler.scheduleTrigger(trigger, delay, timeUnit);

    }


    /**
     * Processing is done in caller's thread or on dedicated thread.
     * See {@link SMThreadingModel}
     *
     * @param trigger
     * @param userData this data is passed to handlers
     */
    @Override
    public void handleTrigger(SMUTrigger trigger, @Nullable Object userData) {
        submitTrigger(trigger, userData);
    }

    /**
     * Submit a trigger.
     * <p>
     * Processing is done in caller's thread or on dedicated thread.
     * See {@link SMThreadingModel}
     *
     * @param trigger
     */
    @Override
    public void handleTrigger(SMUTrigger trigger) {
        submitTrigger(trigger, null);
    }


    /**
     * Submit a trigger and return a future to it.
     * <p>
     * Processing is done in caller's thread or on dedicated thread.
     * See {@link SMThreadingModel}
     * <p>
     * The future is set after trigger is handled, or canceled if queue is cleared from some reason
     * (for example call to init() }
     */
    @Override
    public Future<Object> submitTrigger(SMTrigger trigger) {
        return submitTrigger(trigger, null);
    }

    /**
     * Submit a trigger and return a future to it.
     * <p>
     * Processing is done in caller's thread or on dedicated thread.
     * See {@link SMThreadingModel}
     * <p>
     * The future is set after trigger is handled, or canceled if queue is clear from some reason
     * (for example call to init() }
     */
    @Override
    public Future<Object> submitTrigger(SMTrigger trigger, @Nullable Object userData) {
        return eventProcessor.submitStepTrigger(trigger, userData, false);
    }

    @Override
    public void runSync(SMEventContext context, @Nullable SMUTrigger successTrigger,
                        @Nullable SMUTrigger failureTrigger, SMSimpleHandler action) {

        runAnAction(
            true,
            context, false,
            successTrigger, failureTrigger, null, action);

    }

    @Override
    public Future<Void> runAsync(SMEventContext context, boolean cancelByInterrupt, @Nullable SMUTrigger successTrigger,
                                 @Nullable SMUTrigger failureTrigger, SMUTrigger cancelingTrigger,
                                 SMSimpleHandler action) {

        return runAnAction(
            true,
            context, cancelByInterrupt,
            successTrigger, failureTrigger, cancelingTrigger, action);
    }

    private Future<Void> runAnAction(boolean runAsync, SMEventContext context, boolean cancelByInterrupt,
                                     @Nullable SMUTrigger successTrigger,
                                     @Nullable SMUTrigger failureTrigger, SMUTrigger cancelingTrigger,
                                     SMSimpleHandler action) {

        legalTriggerAssertNullable(successTrigger);

        legalTriggerAssertNullable(failureTrigger);

        legalTriggerAssertNullable(cancelingTrigger);

        SimpleHandlerContextDelegation contextDelegation =
            new SimpleHandlerContextDelegation((EventContextImpl)context);


        ////todo:boaz:fix: trace async future
        return AsyncAction.runAsync(runAsync, contextDelegation,
                                    cancelByInterrupt, successTrigger, failureTrigger,
                                    cancelingTrigger, null,
                                    (c) -> action.handle(contextDelegation)
        );


    }

    /**
     * Return null if SM is busy.
     * Multi Threading: No side effects. But result may be transient.
     */
    @SuppressWarnings({"UnusedDeclaration"})
    final SMStatePathTree getCurrentStatePathTree() {
        if (isBusy()) {
            return null;
        } else {
            return mTopLevel.getCurrentStatePathTree();
        }
    }


    /**
     * Multi Threading: No side effects. But result may be transient.
     */
    @Override
    public final SMStatePathTree getLastKnownCurrentStatePathTree() {
        return mTopLevel.getCurrentStatePathTree();
    }

    /**
     * May return null.
     * Multi Threading: No side effects. But result may be transient.
     */
    @SuppressWarnings({"UnusedDeclaration"})
    public final SMState getLastKnownCurrentStateDeep() {
        return mTopLevel.getCurrentStateDeep();
    }

    @SuppressWarnings({"UnusedDeclaration"})
    public final void detachLogger() {

        if (mLogger != null) {
            mLogger.detach(SMLogEvent.DETACH, this);
            mLogger = null;
        }
    }

    /**
     * @param logger
     * @throws SMDefinitionException if logger already attached.
     */
    @Override
    public final void attachTo(SMAuditor logger) {

        if (mLogger != null) {
            throw new SMDefinitionException("Debugger is already attached");
        }

        mLogger = logger;

        if (logger != null) {
            mLogger.attach(SMLogEvent.ATTACH, this);
        }
    }

    public final void logUserMsg(String msg) {
        if (mLogger != null) {
            mLogger.logUserMsg(SMLogEvent.USER_MSG, this, msg);
        }
    }

    /**
     * Is definition of machine ended ?
     */
    @Override
    public final boolean debugIsMachineDefinitionEnded() {
        return definitionEnded;
    }

    /**
     * Multi Threading: List of defined triggers can't change after definition end. If called at definition phase then
     * thread safety is the caller responsibility.
     */
    @Override
    public SMUTrigger[] debugGetAllDefinedTriggers() {
        return definedUserTriggers.toArray(new SMUTrigger[definedUserTriggers.size()]);
    }

    /**
     * Including user & system triggers
     */
    @Override
    public String[] debugGetAllDefinedTriggersNames() {


        SystemTrigger[] systemTriggers = SystemTrigger.debugGetAllSystemTriggers();

        SMTrigger[] userTriggers = debugGetAllDefinedTriggers();

        ArrayList<String> es = new ArrayList<>(systemTriggers.length + userTriggers.length);

        for (SMBaseTrigger t : systemTriggers) {
            es.add(t.getName());
        }

        for (SMBaseTrigger t : userTriggers) {
            es.add(t.getName());
        }

        return es.toArray(new String[es.size()]);
    }

    /**
     * Write statistics into System.out }
     */
    @Override
    public void debugWriteStatistics() {
        eventProcessor.debugWriteStatistics();
    }

    // DOM support

    @Override
    public void writeToDOM(XMLContext xmlContext, Document doc) {

        // i have nothing to write - my top level is the real state machine
        mTopLevel.writeToDOM(xmlContext, doc);
    }

    /**
     * All real and pseudo states
     */
    @Override
    public String[] debugGetAllStates() {

        ArrayList<String> allStates = new ArrayList<>();

        mTopLevel.debugAddAllStates(allStates);

        return allStates.toArray(new String[allStates.size()]);

    }

    /**
     * Return triggers in 'main' queue and in 'in step' queues.
     * Multi Threading: No side effects, but results may be undefined.
     */
    @Override
    public String[] debugGetTriggerQueue() {
        return eventProcessor.debugGetTriggerQueue();
    }

    @Override
    public SMThreadingModel debugGetThreadingModel() {
        return eventProcessor.debugGetThreadingModel();
    }

    SMGlobalContextImp getContext() {

        if (context == null) {
            synchronized (this) {
                if (context == null) {
                    context = new SMGlobalContextImp(this);
                }
            }
        }

        return context;
    }


    /**
     * Handle triggers that are auto generated, such as  {@link SMState#getEnterEvent()} and {@link SMState#getExitEvent()}.
     *
     * Must be called from in step executing.
     * The trigger is handled as part or the current step executing.
     */
    void handleAGTrigger(SMAGTrigger trigger) {
        eventProcessor.handleAGTrigger(trigger);
    }

    ///**
    // * Must be called from in step executing.
    // * The trigger is handled as part or the current step executing.
    // */
    //void handleInStepTrigger(SMUTrigger trigger) {
    //    eventProcessor.handleInStepTrigger(trigger);
    //}


    /**
     * Return true if this is a system trigger, or a trigger defined by
     * user by calling to {@link #defineTriggers(SMUTrigger...)}
     *
     * @param trigger
     */
    private boolean isLegalTrigger(SMBaseTrigger trigger) {
        if (SMSystemTools.isSystemTrigger(trigger) || trigger instanceof SMAGTrigger) {
            return true;
        } else {

            SMUTrigger userTrigger = SMSystemTools.userTrigger(trigger);

            return userTrigger != null && definedUserTriggers.contains(userTrigger);

        }
    }

    void legalTriggerAssert(SMBaseTrigger eid) {

        if (!isLegalTrigger(eid)) {
            throw new SMDefinitionException("Invalid  SMTrigger: " + eid +
                                            " , use one of defineEvent methods to define it, or use auto generated events");
        }
    }

    void legalTriggerAssertNullable(SMUTrigger... ts) {

        for (SMUTrigger t : ts) {

            if (t == null) {
                return;
            }

            if (!isLegalTrigger(t)) {
                throw new SMDefinitionException("Invalid  SMTrigger: " + t +
                                                " , use one of defineEvent methods to define it, or use auto generated events");
            }
        }
    }


    /**
     * Add command that is executed as SM step
     *
     * @param cmd
     */
    void addStepCommand(final InternalCommand cmd) {
        addStepCommand(cmd, false);
    }

    /**
     * Add command that is executed as SM step
     *
     * @param cmd
     */
    void addStepCommand(final InternalCommand cmd, boolean headOfQueue) {
        eventProcessor.addStepCommand(headOfQueue, cmd);
    }

    /**
     * Ensure that:
     * SM is busy executing step.
     * Call is made from the thread that is executing the current step.
     * <p>
     * Not public, becuase this is called from handle context
     */
    void ensureValidThreadInStepCall() {
        eventProcessor.ensureValidThreadInStepCall();
    }

    /**
     * internal step command processing are executed as part of current step -
     * before any other SM step.
     *
     * Must be called from within step processing. See {@link SMEventProcessor#addInStepCommand(InternalCommand, boolean)}
     */
    private void addInStepCommand(InternalCommand cmd) {
        eventProcessor.addInStepCommand(cmd);
    }

    void addInternalSystemTrigger(SystemTrigger id,
                                  SMStateVertex target,
                                  SMInternalTriggerData internalData,
                                  boolean beginOfQueue) {

        eventProcessor.addInternalSystemTrigger(id, target, internalData, beginOfQueue);
    }

    ///**
    // * Mark state has having local triggers in queue, and process them if not busy.
    // * state mus be active.
    // *
    // * @param state
    // */
    //void addStateLocalTriggerQueue(final SMStateImp state) {
    //    eventProcessor.addStateLocalTriggerQueue(state);
    //}

    void processTransition(List<SMTransitionSegmentImp> l) {
        eventProcessor.processTransition(l);
    }

    private static boolean isLegalUserTrigger(SMBaseTrigger trigger) {
        return SMSystemTools.isUserTrigger(trigger);
    }


    /**
     * Return true is SM is busy executing step.
     */
    private boolean isBusy() {
        return eventProcessor.isBusy();
    }

    private void doDefineTrigger(SMUTrigger trigger) {
        if (!(isLegalUserTrigger(trigger))) {
            throw new SMDefinitionException("Not a legal user event");
        }

        if (definitionEnded) {
            throw new SMDefinitionException("Illegal state. Can't change SM definition after once was initialized");
        }

        if (!definedUserTriggers.contains(trigger)) {
            definedUserTriggers.add(trigger);
        } else {
            throw new SMDefinitionException("Trigger: " + trigger + "is already defined:");
        }
    }


    /**
     * Check validity of state machine.
     * throw {@link SMDefinitionException} if not valid
     * This method is called in {@link #init}
     */
    private void checkValid() throws SMDefinitionException {
        getTopLevelInternal().checkValid();

        mLastCheckModificationCounter = mModificationCounter;
    }


    void setModified() {
        ++mModificationCounter;
        definitionEnded = false;
    }

    void removeHandler(final HandlerList list, final SMHandler handler) {
        InternalCommand cmd =
            () -> list.remove(handler);

        addInStepCommand(cmd);

    }

    //debugger

    final boolean isLoggerOn() {
        return mLogger != null;
    }

    /**
     * Null if {@link #isLoggerOn()} is false
     */
    @Nullable
    final SMAuditor getLogger() {
        return mLogger;
    }

    final boolean isUserMsgLoggingIsOn() {
        return isLoggerOn();
    }

    Iterator<SMUTrigger> userTriggersIterator() {
        return definedUserTriggers.iterator();
    }


    void initImp() {

        if (delayedTriggersHandler != null) {
            delayedTriggersHandler.init();
        }

        eventProcessor.initImp();

        // One again, maybe during cleanup someone add more triggers

        if (delayedTriggersHandler != null) {
            delayedTriggersHandler.init();
        }

    }
}

