package wf.state_machine;

import java.util.List;
import java.util.Set;
import java.util.TreeMap;

/**
 * map between state name to it's instance.
 */
class StateVertexIDMap<S extends SMStateVertexImp> extends TreeMap<String, S> {

    StateVertexIDMap() {
        super(String.CASE_INSENSITIVE_ORDER);
    }

    final void add(S s) {
        put(s.getName(), s);
    }

    /**
     * return null if not found
     */

    final S find(String name) {
        S s = get(name);
        return s;
    }


    final Iterable<S> getStates() {
        return values();
    }

    // ====================================================================
    // for debug only
    final Set<String> getKeys() {
        return keySet();
    }

    final void debugAddAllStates(List<String> states) {
        for (SMStateVertexImp s : values()) {
            s.debugAddAllStates(states);
        }
    }

}