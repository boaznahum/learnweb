package wf.state_machine;

import java.util.LinkedList;

/**
 * Static choice point may be impassable
 */
final class StaticChoicePoint extends SMChoicePoint {

    StaticChoicePoint(SMCompositeStateImp parent,
                      String sid) {
        super(parent, sid);
    }


    @Override
    final String getTypeName() {
        return "Static Choice Point";
    }


    /**
     * find a path to destination target
     * return a list of {@link SMTransitionSegment}
     * if return null then no path trough this state
     */
    @Override
    LinkedList<SMTransitionSegmentImp> findPathThrough(LinkedList<SMTransitionSegmentImp> pathSoFar,
                                                    SMStateImp beginOfPath,
                                                    SMStateVertex source,
                                                    TriggerPacking triggerPacking) {

        // static choice point may have zero event2transitions
        if (transitions != null) {
            return transitions.findPathThrough(pathSoFar,
                                               beginOfPath,
                                               this,
                                               triggerPacking);
        }
        else {
            return null;
        }
    }

    @Override
    boolean possiblyImpassable() {
            return true;
    }

    @Override protected void checkValid() {
        super.checkValid();

        // todo:check_valid
        // static choice point may have no outgoing transition

    }


    // ====================================================================
// for debug only
    @Override
    public String getElementName() {
        return "StaticChoice";
    }


}
