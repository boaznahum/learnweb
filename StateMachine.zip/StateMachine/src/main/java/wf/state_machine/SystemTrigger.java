package wf.state_machine;

enum SystemTrigger implements SMBaseTrigger {

    STATE_FINAL("$FINAL$"),
    // pseudo states special events
    FORK_EXIT("$ForkExit$"),
    JOIN_EXIT("$JoinExit$"),
    DYNAMIC_CHOICE_EXIT("$DynamicChoiceExit$");

    private final String name;

    SystemTrigger(String name) {
        this.name = name;
    }

    @Override
    public String getName() {
        return name;
    }

    static SystemTrigger[] debugGetAllSystemTriggers() {
        return SystemTrigger.values();
    }

}
