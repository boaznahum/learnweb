package wf.state_machine;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import wf.state_machine.outputers.DOMHelper;
import wf.state_machine.outputers.XMLContext;
import wf.state_machine.outputers.dot.DotContext;

import java.util.Iterator;
import java.util.LinkedList;

final class TopLevelState extends SMCompositeStateImp {


    /**
     * A singleton used by all states
     */
    private ReturnPoint returnPoint;



    TopLevelState(StateMachineImp world, String name) {
        super(world, null, name);
    }

    @Override
    final String getTypeName() {
        return "Top Level";
    }

    // ============================================================================

    @Override
    protected void checkValid() {
        super.checkValid();


        /**
         * See {@link #enterBegin(SMStateImp, SMStateVertexImp, LinkedList, SMStateVertexImp, TriggerPacking)}
         */

        if (getInitialState() == null && ! isSingleInnerState()) {
            throw new SMDefinitionException(getTypeAndName() +
                                            " must have initial state in case there more then one inner states");
        }

    }



    @Override
    public final SMStateVertex getReturnPoint() {

        if (returnPoint == null) {
            returnPoint = new ReturnPoint(this);
        }

        return returnPoint;
    }

    // till now public interface, from now implementation

    // ================ DOM support ===============================

    /**
     * I'm the root so i begin with document
     *
     * @param xmlContext
     * @param doc
     */
    void writeToDOM(XMLContext xmlContext, Document doc) {

        String myTagName = getElementName();

        Element myElement = doc.createElement(myTagName);
        doc.appendChild(myElement);

        // top level is special
        xmlContext.registerElement(this, myElement);

        DOMHelper.write(xmlContext, this, myElement);
    }


    @Override
    public void writeBody(XMLContext xmlContext, Element myNode) {

        DotContext dotContext = xmlContext.getDotContext();

        if (dotContext != null) {
            String graphType;
            if (dotContext.isUseDirectGraph()) {
                graphType = "digraph";
            } else {
                graphType = "graph";

            }

            dotContext.addDotElement(myNode, "// Configuration:" + dotContext.getConfigurationName());
            dotContext.addDotElement(myNode, graphType + " G {\n" +
                                             DotContext.getDotLabelEqualsName(this) + ";");

            //noinspection SpellCheckingInspection
            dotContext.addDotElement(myNode, "rankdir=LR;"); // copied from graphviz-2.8\graphs\directed\states.dot

            // DotHelper.addDotElement(myNode, "size=\"4, 4\";");

            // !!! allow connections of edges
            //if (DotHelper.isSupportingNodeToClusterArrow(configuration) || DotHelper.isSupportingClusterToClusterArrow(configuration)) {
                // copied from graphviz-2.8\graphs\directed\states.dot
            dotContext.addDotElement(myNode, "compound=true;");
            //}
        } // DOt

        Document root = myNode.getOwnerDocument();

        Element legalTriggers = root.createElement("LegalEvents");
        myNode.appendChild(legalTriggers);

        Iterator<SMUTrigger> i = getWorld().userTriggersIterator();

        while (i.hasNext()) {
            String name = (i.next()).getName();

            Element trigger = root.createElement("SMTrigger");
            legalTriggers.appendChild(trigger);

            trigger.setAttribute("name", name);
        }

        if (returnPoint != null) {
            returnPoint.writeTo(xmlContext, myNode);
        }

        super.writeBody(xmlContext, myNode);

        if (dotContext != null) {
            dotContext.addDotElement(myNode, "} // end of state machine");
        }

    }

    @Override
    public String getElementName() {
        return "StateMachine";
    }




}