package wf.state_machine;

import org.jetbrains.annotations.Nullable;

import java.util.function.Supplier;

final class TransitionBranch {

    @Nullable
    private SMStateVertexImp mTarget;


    // these two are created on demand

    @Nullable
    private TransitionHandlerList mTransitionActions;

    @Nullable
    private TransitionHandlerList mEndTransitionActions;


    TransitionBranch() {
        mTarget = null;
    }

    SMStateVertexImp getTarget() {
        return mTarget;
    }

    /**
     * Wee need this method in case of {@link SMHistory}
     * @param state
     */
    void setTarget(SMStateVertexImp state) {
        mTarget = state;
    }

    SMStateVertex getTargetAssert() {
        if (mTarget == null) {
            throw new SMDefinitionException("target is null");
        }
        return mTarget;
    }


    boolean transitionHandlersExist() {
        return mTransitionActions != null &&
                !mTransitionActions.isEmpty();
    }

    void executeTransitionHandlers(StateMachineImp world, Supplier<SMTransitionHandlerContext> actionData) {
        TransitionHandlerList.execute(world, mTransitionActions, actionData);
    }


    boolean endTransitionHandlersExist() {
        return mEndTransitionActions != null && !mEndTransitionActions.isEmpty();
    }

    void executeEndTransitionHandlers(StateMachineImp world, Supplier<SMTransitionHandlerContext> actionDataS) {
        TransitionHandlerList.execute(world, mEndTransitionActions, actionDataS);
    }


    void addToTransitionList(SMTransitionHandler h) {
        if (mTransitionActions == null) {
            mTransitionActions = new TransitionHandlerList();
        }

        mTransitionActions.addLast(h);
    }


    void addToEndTransitionList(SMTransitionHandler h) {
        if (mEndTransitionActions == null) {
            mEndTransitionActions = new TransitionHandlerList();
        }

        mEndTransitionActions.addLast(h);
    }

}