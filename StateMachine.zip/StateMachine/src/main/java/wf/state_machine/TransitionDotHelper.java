package wf.state_machine;

import org.jetbrains.annotations.Nullable;
import org.w3c.dom.Element;
import wf.state_machine.outputers.XMLContext;
import wf.state_machine.outputers.dot.DotContext;
import wf.state_machine.outputers.dot.SMDotBuildError;

/**
 * Because the code involved in writing transition dot is so complicated,
 * I put in in separate class
 *
 * @author Boaz Nahum
 * @version WI VX.6, V12.0X, ADC V0.95
 */

class TransitionDotHelper {

    private TransitionDotHelper() {
    }

    static void writeDotData(XMLContext xmlContext,
                             Element nodeOfSource, // assume it is node of source
                             SMStateVertexImp source,
                             SMBaseTrigger trigger,
                             SMTransitionImp transition, boolean isInternal) {


        final DotContext dotContext = xmlContext.getDotContext();

        if (dotContext == null) {
            return;
        }

        boolean sourceIsComplex = source.isComplex();

        int nBranches = transition.getN();

        SMStateDotInfo sourceDotInfo = source.getDotInfo();

        boolean isNary = nBranches > 1;

        @Nullable
        final SMGuard guard = transition.getGuard();

        if (isNary) {
            // create dummy condition node
            String conditionNodeName = "__dummy_condition_" + dotContext.getRandomUniqueID();

            SMStateDotInfo conditionDotInfo = new SMStateDotInfo(source,
                                                                 conditionNodeName,
                                                                 conditionNodeName, true);

            SMComplexStateImp stateContainsCondition =
                SMStateVertexImp.firstStateContainsBothNoConcurrent(source, transition);

            String conditionDot = conditionNodeName +
                                  DotContext.concatenateAttributesWrap("label=\"C\"",
                                                                       "shape=circle",
                                                                       "fontsize=10",
                                                                       "margin=0",
                                                                       "width=0.2",
                                                                       "height=0.2"
                                  ) + ";";

            Element elementContainsCondition = DotContext.findElementOfParent(nodeOfSource, source,
                                                                              stateContainsCondition);
            if (elementContainsCondition == null) {
                throw new SMDefinitionException();
            }

            String comment = "Dummy node to support transition " +
                             buildTransitionDescription(source, transition, trigger);

            dotContext.addDotComment(elementContainsCondition, comment);

            dotContext.addDotElement(elementContainsCondition, conditionDot);


            String connectorLabel = getArrowLabel(trigger, guard);

            writeDotUnaryTransition(dotContext,
                                    nodeOfSource,
                                    sourceDotInfo,
                                    sourceIsComplex,
                                    conditionDotInfo,
                                    false,
                                    false,
                                    false,
                                    connectorLabel, false);


            sourceIsComplex = false;
            trigger = null;
            sourceDotInfo = conditionDotInfo;
        }

        for (int i = 0; i < nBranches; ++i) {

            String connectorLabel = null;

            if (!isNary) {
                connectorLabel = getArrowLabel(trigger, guard);
            } else {
                if (guard != null) {
                    String bn = guard.getBranchName(nBranches, i);
                    if (bn != null) {
                        connectorLabel = "[" + bn + "]";
                    }
                }
            }

            SMStateDotInfo targetDotInfo;
            boolean targetIsComplex;
            boolean targetIsInOrEqualSource;
            boolean sourceIsInOrEqualTarget;

            if (isInternal) {
                targetDotInfo = sourceDotInfo;
                targetIsComplex = sourceIsComplex;
                targetIsInOrEqualSource = true;
                sourceIsInOrEqualTarget = true;
            } else {
                SMStateVertexImp target = transition.getBranchTarget(i);

                targetIsComplex = target.isComplex();

                targetDotInfo = target.getDotInfo();

                // todo:boaz:fix this is not true, in case source is dummy node then it may be outside
                targetIsInOrEqualSource = source.isStateContainsOrEq(target);
                sourceIsInOrEqualTarget = target.isStateContainsOrEq(source);
            }


            writeDotUnaryTransition(dotContext, nodeOfSource,
                                    sourceDotInfo, sourceIsComplex,
                                    targetDotInfo,
                                    targetIsComplex,
                                    targetIsInOrEqualSource,
                                    sourceIsInOrEqualTarget,
                                    connectorLabel,
                                    isInternal);
        }
    }

    /**
     * Return ull if empty
     */
    @Nullable
    private static String getArrowLabel(@Nullable SMBaseTrigger trigger, @Nullable SMGuard guard) {

        String triggerName = "";

        if (trigger != null && !(trigger instanceof SystemTrigger)) {
            triggerName = trigger.getName();
        }

        // if name is not known then we write []
        if (guard != null) {

            triggerName += "[";
            String guardName = guard.getName();
            if (guardName != null) {
                triggerName += guardName;
            }
            triggerName += "]";
        }
        if (triggerName.isEmpty()) {
            return null;
        } else {
            return triggerName;
        }
    }

    private static String buildTransitionDescription(SMStateVertexImp source,
                                                     SMTransitionImp transition,
                                                     SMBaseTrigger trigger) {

        String s = source.getAbsName();

        s += " --";

        SMGuard guard = transition.getGuard();
        String arrow = getArrowLabel(trigger, guard);

        if (arrow != null) {
            s += " " + arrow + " ";
        }

        s += "--> {";

        int n = transition.getN();
        boolean first = true;
        for (int i = 0; i < n; ++i) {
            if (first) {
                first = false;
            } else {
                s += ", ";
            }

            if (guard != null) {
                String bn = guard.getBranchName(n, i);
                if (bn != null) {
                    s += "[" + bn + "]";
                }
            }

            s += transition.getBranchTarget(i).getAbsName();
        }

        s += "}";

        return s;

    }

    private static void writeDotUnaryTransition(DotContext dotContext, Element nodeOfSource,
                                                SMStateDotInfo sourceDotInfo, boolean sourceIsComplex,
                                                SMStateDotInfo targetDotInfo,
                                                boolean targetIsComplex,
                                                boolean targetIsInOrEqualSource,
                                                boolean sourceIsInOrEqualTarget,
                                                String connectorLabel, boolean isInternal) {


        if (sourceIsComplex) {

            if (targetIsInOrEqualSource && !dotContext.isSupportingClusterToClusterArrow()) {
                dotDummyCluster2SameCluster(
                    dotContext, nodeOfSource,
                    sourceDotInfo,
                    targetDotInfo,
                    connectorLabel, isInternal);

            } else if (!targetIsInOrEqualSource && !dotContext.isSupportingNodeToClusterArrow()) {
                dotDummyCluster2X(
                    dotContext, nodeOfSource,
                    sourceDotInfo,
                    targetDotInfo,
                    connectorLabel, isInternal);
            } else {
                dotRegularTransition(dotContext, nodeOfSource, sourceDotInfo, targetDotInfo, connectorLabel, isInternal);
            }
        } else {
            // simple state source
            if (targetIsComplex) {

                if (!dotContext.isSupportingNodeToClusterArrow()) {
                    dotDummyNode2Cluster(dotContext,
                                         nodeOfSource,
                                         sourceDotInfo,
                                         targetDotInfo,
                                         sourceIsInOrEqualTarget,
                                         connectorLabel, isInternal);
                } else {
                    dotRegularTransition(dotContext, nodeOfSource, sourceDotInfo, targetDotInfo, connectorLabel,
                                         isInternal);
                }
            } else {
                dotRegularTransition(dotContext, nodeOfSource, sourceDotInfo, targetDotInfo, connectorLabel, isInternal);
            }
        }
    }

    /**
     * Do transition from node to cluster using dummy nodes in cluster or outside of it
     */
    private static void dotDummyNode2Cluster(DotContext dotContext,
                                             Element inNode,
                                             SMStateDotInfo source,
                                             SMStateDotInfo target,
                                             boolean sourceIsInOrEqualTarget,
                                             @Nullable String connectorLabel, boolean isInternal) {

        String sourceName = source.getDotNameAsSourceOfTransition(target);

        if (sourceIsInOrEqualTarget) {
            // We need to create one point outside target
            String targetName = dotCreateDummyNodeOutsideCluster(dotContext, target);

            // create transition to this node

            String dotTran = dotContext.createDotTransition(sourceName, targetName,
                                                            getDotDefaultTransitionAttributes(connectorLabel, false,
                                                                                              isInternal));

            addDotTransition(dotContext, inNode, dotTran, source, target);

            connectorLabel = null;
            sourceName = targetName;
        }

        String targetName = dotCreateDummyNodeInCluster(dotContext, target);

        String edgeAttributes = DotContext.concatenateAttributes("lhead=" + target.getDotName(),
                                                                 getDotDefaultTransitionAttributes(connectorLabel,
                                                                                                   isInternal));

        String dotTran = dotContext.createDotTransition(sourceName, targetName, edgeAttributes);

        addDotTransition(dotContext, inNode, dotTran, source, target);
    }

    /**
     * Handle case when source is cluster and target is cluster or node.
     * Use dummy nodes in clusters
     */
    private static void dotDummyCluster2X(DotContext dotContext,
                                          Element inNode,
                                          SMStateDotInfo source,
                                          SMStateDotInfo target,
                                          @Nullable String connectorLabel, boolean isInternal) {

        String dummySourceName = dotCreateDummyNodeInCluster(dotContext, source);

        String edgeAttributes = "ltail=" + source.getDotName();
        edgeAttributes = DotContext.concatenateAttributes(edgeAttributes,
                                                          getDotDefaultTransitionAttributes(connectorLabel, isInternal));

        String targetName;

        if (target.isComplex() && !dotContext.isSupportingNodeToClusterArrow()) {
            targetName = dotCreateDummyNodeInCluster(dotContext, target);
            edgeAttributes = DotContext.concatenateAttributes(edgeAttributes, "lhead=" + target.getDotName());

        } else {
            targetName = target.getDotName();
        }

        String dotTran = dotContext.createDotTransition(dummySourceName, targetName, edgeAttributes);

        addDotTransition(dotContext, inNode, dotTran, source, target);
    }

    /**
     * This is the case were source and target in the same cluster, so wee need to put dummy target outside
     *
     * @param dotContext
     * @param inNode
     * @param source
     * @param target
     * @param connectorLabel
     * @param isInternal
     */
    private static void dotDummyCluster2SameCluster(DotContext dotContext, Element inNode,
                                                    SMStateDotInfo source,
                                                    SMStateDotInfo target,
                                                    @Nullable String connectorLabel, boolean isInternal) {

        String dummySourceName = dotCreateDummyNodeInCluster(dotContext, source);

        String intermediateDummyTargetName = dotCreateDummyNodeOutsideCluster(dotContext, source);

        String edge1Attributes = DotContext.concatenateAttributes("ltail=" + source.getDotName());

        edge1Attributes = DotContext.concatenateAttributes(edge1Attributes,
                                                          getDotDefaultTransitionAttributes(connectorLabel, false,
                                                                                            isInternal));

        // from dummy inside cluster to dummy outside cluster
        String intermediateTransition = dotContext.createDotTransition(
            dummySourceName,
            intermediateDummyTargetName,
            edge1Attributes);

        addDotTransition(dotContext, inNode, intermediateTransition, source, target);


        String targetName;

        String edge2Attributes = getDotDefaultTransitionAttributes(null, true,
                                                                   isInternal);

        if (target.isComplex()) {
            targetName = dotCreateDummyNodeInCluster(dotContext, target);
            //noinspection StringWithMistakes
            edge2Attributes = DotContext.concatenateAttributes(edge2Attributes, "lhead=" + target.getDotName());

        } else {
            targetName = target.getDotName();
        }


        String outsideInTran = dotContext.createDotTransition(
            intermediateDummyTargetName,
            targetName,
            edge2Attributes);

        addDotTransition(dotContext, inNode, outsideInTran, source, target);
    }

    private static void dotRegularTransition(DotContext dotContext, Element inNode,
                                             SMStateDotInfo source,
                                             SMStateDotInfo target,
                                             @Nullable String connectorLabel, boolean isInternal) {

        String sourceName;

        sourceName = source.getDotNameAsSourceOfTransition(target);

        String edgeAttributes = getDotDefaultTransitionAttributes(connectorLabel, isInternal);

        String targetName;
        targetName = target.getDotNameAsTargetOfTransition(source);

        String dotTran = dotContext.createDotTransition(sourceName, targetName, edgeAttributes);

        addDotTransition(dotContext, inNode, dotTran, source, target);
    }

    private static String getDotDefaultTransitionAttributes(@Nullable String connectorLabel, boolean isInternal) {
        return getDotDefaultTransitionAttributes(connectorLabel, true, isInternal);

    }

    private static String getDotDefaultTransitionAttributes(@Nullable String label,
                                                            boolean hasArrow, boolean isInternal) {

        String directionAttr;

        if (hasArrow && ! isInternal) {
            // although fdp is un-directed graph, is supports drawings arrows
            directionAttr = DotContext.concatenateAttributes(
                "dir=\"" + "forward" + "\"",
                "arrowhead=empty");

        } else {
            directionAttr = DotContext.concatenateAttributes("dir=none");
        }

        if (isInternal) {
            //directionAttr += ",style=dashed";
            directionAttr += ",style=dotted";
        }


        return DotContext.concatenateAttributes(
            directionAttr,
            getDotTransitionLabelAttributes(label));
    }

    /**
     * @return null if label is null
     */
    private static String getDotTransitionLabelAttributes(@Nullable String label) {

        if (label == null) {
            return null;
        } else {
            return DotContext.concatenateAttributes(
                "label=\"" + label + "\"",
                //"headlabel=\"" + trigger.getName() + "\"",
                "labelfontcolor=\"blue\"");
        }
    }


    /**
     * All transitions are added in root
     */
    private static void addDotTransition(DotContext dotContext, Element inNode,
                                         String dotTran,
                                         SMStateDotInfo actualSource,
                                         SMStateDotInfo actualTarget) {

        int transitionID = dotContext.getRandomUniqueID();
        // add comment for the delayed transition
        final String s = "Transition #" + transitionID + ":" +
                         actualSource.getTypeAndDotName() +
                         "-->" +
                         actualTarget.getTypeAndDotName();
        dotContext.addDotElement(inNode, "// See " + s);

        // we delayed all transitions to end of file after all nodes are known
        Element root = inNode.getOwnerDocument().getDocumentElement();
        dotContext.addDotElement(root, "//" + s);
        dotContext.addDotElement(root, dotTran);
    }

    /**
     * Add dummy node in cluster. The node is not actually added now, it will be added
     * at second pass
     *
     * @param dotContext
     * @param inCluster - Assume to complex state @return Name of dummy node add to cluster
     * @return name of dummy node
     */
    private static String dotCreateDummyNodeInCluster(DotContext dotContext, SMStateDotInfo inCluster) {

        String dummyNodeAttributes = getDummyNodeAttributes();

        String dummyName = createDummyNameInCluster(dotContext, inCluster);

        // add dummy node in source
        final String dummyNodeStatement = dummyName +
                                          DotContext.wrapAttributes(dummyNodeAttributes) +
                                          ";";

        dotContext.addDummyNodeToCluster(inCluster, dummyNodeStatement);

        return dummyName;
    }

    /**
     * Create dummy node outside inNode
     */
    private static String dotCreateDummyNodeOutsideCluster(DotContext dotContext,
                                                           SMStateDotInfo clusterInfo) {

        if (clusterInfo.isFake()) {
            throw new SMDotBuildError("Can't handle fake cluster");
        }

        String actualName = clusterInfo.getDotName();

        //noinspection SpellCheckingInspection
        String dummyName = "__dummy_" + dotContext.getRandomUniqueIDStr() +
                           "_outdise_" + actualName;


        // !!! Assume it is not a fake
        Element outsideSource = dotContext.findElementAssert(clusterInfo.getStateInternal().getParent());

        String dummyNodeAttributes = getDummyNodeAttributes();

        dotContext.addDotElement(outsideSource,
                                 dummyName +
                                 DotContext.wrapAttributes(dummyNodeAttributes) +
                                 ";");

        return dummyName;

    }

    private static String createDummyNameInCluster(DotContext dotContext, SMStateDotInfo cluster) {

        String actualSourceName = cluster.getDotName();

        return "__dummy_" + dotContext.getRandomUniqueIDStr() +
               "_in_" + actualSourceName;
    }

    private static String getDummyNodeAttributes() {
        //noinspection SpellCheckingInspection
        String dummyNodeAttributes = DotContext.concatenateAttributes(
            "label=\"\"",
            "shape=point",
            "style=invis");

        return dummyNodeAttributes;
    }


}
