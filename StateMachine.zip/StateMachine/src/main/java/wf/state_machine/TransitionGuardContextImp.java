package wf.state_machine;

// till we have better thing to do

class TransitionGuardContextImp implements SMTransitionGuardContext {

    private final SMGlobalContext globalContext;
    private final SMStateVertex source;
    private final TriggerPacking triggerPacking;
    private final SMTransitionImp transitionsData;

    TransitionGuardContextImp(SMGlobalContext globalContext, SMStateVertex source, TriggerPacking triggerPacking,
                              SMTransitionImp transitionsData) {
        this.globalContext = globalContext;
        this.source = source;
        this.triggerPacking = triggerPacking;
        this.transitionsData = transitionsData;
    }

    @Override
    public SMStateVertex getSource() {
        return source;
    }

    @Override
    public SMBaseTrigger getTrigger() {
        return triggerPacking.getTrigger();
    }

    /**
     * Get the user data that was passed along with {@link #getTrigger()}
     * when calling {@link StateMachine#handleTrigger(SMUTrigger , Object)}
     * or {@link StateMachine#submitTrigger(SMTrigger, Object)}
     */
    @Override
    public Object getTriggerData() {
        return triggerPacking.getUserData();

    }

    @Override
    public SMGlobalContext getGlobalContext() {
        return globalContext;

    }

    @Override
    public int getN() {
        return transitionsData.getN();
    }

    @Override
    public SMStateVertex getTarget(int i) {
        return transitionsData.getBranchTarget(i);
    }

    @Override
    public SMTransition getTransition() {
        return transitionsData;
    }

    @Override
    public int resolve(SMStateVertex state) {
        for(int i = 0; i < getN(); ++i) {
            //noinspection ObjectEquality
            if (getTarget(i) == state) {
                return i;
            }
        }

        return -1;
    }

    @Override
    public SMGuard getGuard() {
        return transitionsData.getGuard();
    }


}

