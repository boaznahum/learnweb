package wf.state_machine;

/**
 * @author Boaz Nahum
 */
class TransitionHandlerContextImpl extends HandlerContextImpl implements SMTransitionHandlerContext {

    private final boolean isEndOf;
    private final SMStateVertex source;
    private final SMStateVertex target;
    private final int targetSelection;

    TransitionHandlerContextImpl(SMGlobalContext globalContext, boolean isEndOf,
                                 SMStateVertex source,
                                 TriggerPacking triggerPacking,
                                 SMStateVertex target,
                                 int targetSelection) {
        super(globalContext, triggerPacking);
        this.isEndOf = isEndOf;
        this.source = source;
        this.target = target;
        this.targetSelection = targetSelection;
    }

    @Override
    public boolean endOfTransition() {
        return isEndOf;
    }

    @Override
    public SMStateVertex getSource() {
        return source;
    }


    @Override
    public SMStateVertex getTarget() {
        return target;
    }

    @Override
    public int getTargetSelection() {
        return targetSelection;
    }
}
