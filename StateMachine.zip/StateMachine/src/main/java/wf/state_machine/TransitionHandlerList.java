package wf.state_machine;

import org.jetbrains.annotations.Nullable;

import java.util.function.Supplier;

final class TransitionHandlerList extends HandlerList<SMTransitionHandler, SMTransitionHandlerContext> {

    static void execute(StateMachineImp world, @Nullable TransitionHandlerList list,
                        Supplier<SMTransitionHandlerContext> dSupplier) {

        SMTransitionHandlerExecutor executor =
            SMTransitionHandlerExecutor.get();

        if (list != null) {
            list.execute(world, dSupplier, executor);
        }
    }

    static TransitionHandlerList add(TransitionHandlerList list,
                                     SMTransitionHandler h) {
        if (list == null) {
            list = new TransitionHandlerList();
        }

        list.addLast(h);

        return list;
    }

}

