package wf.state_machine;

import org.w3c.dom.Element;
import wf.state_machine.outputers.XMLAttributeAndValue;
import wf.state_machine.outputers.XMLContext;
import wf.state_machine.outputers.XMLWriteable;
import wf.state_machine.smlogger.SMLogEvent;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * A list of {@link SMTransition} all share same event
 * Date: Mar 17, 2005
 *
 * @author Boaz Nahum
 */
class Transitions extends StateMachineElementImp implements XMLWriteable {

    //todo:boaz:improve: convert it to light array
    private final ArrayList<SMTransitionImp> transitions = new ArrayList<>();

    Transitions(StateMachineImp world) {
        super(world);
    }



    void add(SMTransitionImp t) {


        if (hasAtLeastOneGuaranteedTransition()) {
            // todo:boaz:fix: message is very un clear
            throw new SMDefinitionException("Trying to add un reachable transition: " +
                                            t);
        }

        transitions.add(t);
    }

    boolean hasAtLeastOneGuaranteedTransition() {

        // this is called only during setup. So don't worry
        //  about performance
        for (SMTransitionImp t : transitions) {

            if (t.isGuaranteed()) {
                return true;
            }
        }

        return false; // all event2transitions are guarded

    }

    public void checkTargetIsInParent(PseudoState pseudoState) {
        for (SMTransitionImp t : transitions) {
            pseudoState.checkTargetIsInParent(t);
        }
    }


    @Override
    protected void checkValid() {
        for (SMTransitionImp transition : transitions) {
            transition.checkValid();
        }
    }

    @Override
    void init() {
        super.init();

        transitions.trimToSize();

        for (SMTransitionImp transition : transitions) {
            transition.init();
        }
    }

    /**
     * find a path  to destination target
     * return a list of {@link SMTransitionSegment}
     * this will add segment [source ...].<br>
     * This method will try to find the first transition that
     * there is path trough it (it is not necessary the default branch)
     * see {@link SMTransitionImp#findPathThrough}
     *
     * @param pathSoFar If no path found then pathSoFar is not modified.
     * @param triggerPacking
     * @return null if no path found.
     */
    final LinkedList<SMTransitionSegmentImp> findPathThrough(LinkedList<SMTransitionSegmentImp> pathSoFar,
                                                             SMStateImp beginOfPath,
                                                             SMStateVertexImp source,
                                                             TriggerPacking triggerPacking) {
        boolean debuggerIsOn = isLoggerOn();


        if (debuggerIsOn) {
            logEvent(SMLogEvent.BEGIN_QUERYING_CANDIDATE_TRANSITIONS, source, triggerPacking, null);
        }

        LinkedList<SMTransitionSegmentImp> found = null;

        for (SMTransitionImp t : transitions) {

            LinkedList<SMTransitionSegmentImp> pathTrough = t.findPathThrough(
                pathSoFar,
                beginOfPath,
                source, triggerPacking);

            if (pathTrough != null) {
                found = pathTrough;
                break;
            }
        }

        if (debuggerIsOn) {

            SMStateVertex target;
            if (found == null) {
                target = null;
            } else {
                target = found.getFirst().getTarget();
            }
            logEvent(SMLogEvent.END_QUERYING_CANDIDATE_TRANSITIONS, source, triggerPacking, target);
        }

        // null if not found
        return found;
    }

    final LinkedList<SMTransitionSegmentImp> findPathThrough(SMStateImp beginOfPath,
                                                          SMStateVertexImp source,
                                                          TriggerPacking triggerPacking) {

        return findPathThrough(null,
                               beginOfPath,
                               source,
                               triggerPacking);
    }

    /**
     * Check that branches are paths are in(or on) container.
     * If not, then return the first SMStateVertex that is not in container.
     * If all are in container then return null.
     */
    List<SMStateVertex> isAllPathTroughIsInContainer(SMComplexStateImp container,
                                                     boolean onEdgeIsOk) {

        for (SMTransitionImp transition : transitions) {

            List<SMStateVertex> l = transition.isAllPathTroughIsInContainer(container, onEdgeIsOk);

            if (l != null) {
                return l;
            }
        }

        return null; //OK !!!  All are in container
    }

    // ====================================================================

    // for debug only

    @Override
    public String getElementName() {
        return "transitions";
    }

    @Override
    public XMLAttributeAndValue[] getAttributes() {
        return null;
    }

    @Override
    public void writeBody(XMLContext xmlContext, Element inNode) {
        for (SMTransitionImp t : transitions) {
            t.writeTo(xmlContext, inNode);
        }
    }

    void writeDotData(XMLContext xmlContext, Element inNode, SMStateVertexImp source, SMBaseTrigger trigger) {
        for (SMTransitionImp t : transitions) {
            TransitionDotHelper.writeDotData(xmlContext, inNode, source, trigger, t, false);
        }
    }
}
