package wf.state_machine;

import gnu.trove.THashMap;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;

/**
 * A map between an 'and' (composite trigger) trigger (the key) to it's definition.
 * For example, if:
 * --  W = X * Y * Z
 * Then the key is W, and teh value is {@link SMTriggersAnd SMTriggersAnd(X,Y,X)}
 *
 * Rules:
 * 1. A composite trigger can be defined only once: if you define W = X * Y then you can't also define it as Y * Z
 * 2. If trigger  X is used to define a complex trigger then it can't be used to define other complex trigger
 */
final class Trigger2AndDefinitionMap {

    private final Map<SMTrigger, SMTriggersAndImp> complex2definitionMap = new LinkedHashMap<>();

    /**
     * A mapping between sub triggers (X, Y, Z) to their complex definition.
     * See rule 2.
     */
    private final Map<SMTrigger, SMTrigger> subTrigger2ComplexMap = new THashMap<>();



    void insert(SMTrigger complexTrigger, SMTriggersAndImp definition) {
        complex2definitionMap.put(complexTrigger, definition);

        for (SMTrigger sub : definition.parts()) {
            subTrigger2ComplexMap.put(sub, complexTrigger);
        }
    }

    SMTriggersAndImp find(SMTrigger eid) {
        SMTriggersAndImp o = complex2definitionMap.get(eid);

        return o;
    }

    /**
     * Return the complex trigger if the given trigger is part of complex trigger definition
     * return null if not found
     */
    SMTrigger isPartOfComplexAndEvent(SMTrigger subTrigger) {
        return subTrigger2ComplexMap.get(subTrigger);
    }

    /**
     * is eventQueue satisfy any complex event
     *
     * @return null if not
     */
    SMTrigger completeAndEventInQueue(TriggerQueue triggerQueue) {

        for (Entry<SMTrigger, SMTriggersAndImp> me : complex2definitionMap.entrySet()) {
            SMTriggersAndImp and = me.getValue();

            if (and.completeAndEventInQueue(triggerQueue)) {
                return me.getKey();
            }
        }

        return null;
    }

    /**
     * complexTrigger must be in map
     */

    void removeAndEventsFromQueue(TriggerQueue triggerQueue, SMTrigger complexTrigger) {
        SMTriggersAndImp found = find(complexTrigger);

        if (found == null)  {
            throw new SMDefinitionException("found == null");
        }

        found.removeAndEventsFromAndQueue(triggerQueue);
    }

    // ====================================================================
    Iterable<SMTrigger> keys() {
        return complex2definitionMap.keySet();
    }

    // for debug only
    public String[] toStrings() {

        String[] ss = new String[complex2definitionMap.size()];

        int j = 0;

        for (Entry<SMTrigger, SMTriggersAndImp> me : complex2definitionMap.entrySet()) {

            SMBaseTrigger trigger = me.getKey();
            SMTriggersAnd and = me.getValue();

            ss[j++] = trigger.getName() + " = " + and;
        }
        return ss;
    }
}