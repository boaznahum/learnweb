package wf.state_machine;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.concurrent.CompletableFuture;

/**
 * A packing of trigger nad it's user data.
 * See {@link StateMachine#handleTrigger(SMUTrigger, Object)}  or {@link StateMachine#submitTrigger(SMTrigger, Object)}
 *
 * @author Boaz Nahum
 */
final class TriggerPacking {

    private final SMBaseTrigger trigger;
    private final Object userData;

    @Nullable
    private final CompletableFuture<Object> future;



    TriggerPacking(@NotNull SMBaseTrigger trigger,
                   Object userData,
                   @Nullable CompletableFuture<Object> future) {
        this.trigger = trigger;
        this.userData = userData;
        this.future = future;
    }

    //TriggerPacking(SMCommandTrigger trigger,
    //                 SMCompletableFuture<Object> future) {
    //    this(trigger, null, future);
    //}

    public SMBaseTrigger getTrigger() {
        return trigger;
    }


    public Object getUserData() {
        return userData;
    }

    /**
     * The future of the processed trigger
     */
    @Nullable
    public CompletableFuture<Object> getFuture() {
        return future;
    }


    /**
     * We compare and hash only using trigger data, so
     * when we putting packing in collections, the can be look for
     * using trigger as key
     */

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null) {
            return false;
        } else {

            SMBaseTrigger thatTrigger;
            if (getClass() == o.getClass()) {
                TriggerPacking that = (TriggerPacking)o;

                thatTrigger = that.trigger;
            } else if (o instanceof SMBaseTrigger) {
                thatTrigger = ((SMBaseTrigger)o);
            } else {
                return false;
            }

            if (trigger == thatTrigger) {
                return true;
            } else if (trigger == null) {
                // thatTrigger is not null
                return false;
            } else {
                return trigger.equals(thatTrigger);
            }
        }
    }


    @Override
    public int hashCode() {
        return trigger.hashCode();
    }

    public String getTriggerName() {
        return trigger.getName();
    }

}