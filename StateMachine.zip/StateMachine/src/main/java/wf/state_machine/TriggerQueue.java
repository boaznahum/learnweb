package wf.state_machine;

import java.util.*;

/**
 * FIFO of SMBaseTrigger
 */
final class TriggerQueue {

    private final LinkedList<SMBaseTrigger> mList = new LinkedList<>();

    void clear() {
        mList.clear();
    }


    /**
     * add event to back of queue
     */
    void push(SMBaseTrigger triggerID) {
        mList.addLast(triggerID);
    }

    boolean find(SMBaseTrigger triggerID) {
        return mList.contains(triggerID);
    }


    public boolean containsAll(SMTrigger[] subTriggers) {
        for (SMTrigger trigger : subTriggers) {
            if ( ! mList.contains(trigger)) {
                return false;
            }
        }

        return true;
    }


    // return number of removed
    int remove(SMBaseTrigger triggerID, boolean removeAll) {

        ListIterator<SMBaseTrigger> i = mList.listIterator();
        int removed = 0;

        while (i.hasNext()) {

            SMBaseTrigger o = i.next();

            if (triggerID.equals(o)) {
                i.remove();
                ++removed;
                if (!removeAll) {
                    break;
                }
            }
        }

        return removed;
    }

    // for debug only
    @Override
    public String toString() {
        return mList.toString();
    }

}

