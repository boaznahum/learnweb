package wf.state_machine;

/**
 * Transition with 1 branch
 *
 * @author Boaz Nahum
 * @version WI VX.6, V12.0X, ADC V0.95
 */

class UnaryTransition extends PermanentTransition {

    private final TransitionBranch branch0;

    UnaryTransition(StateMachineImp world,
                    SMStateVertexImp target0,
                    SMGuard guard) {

        super(world, guard);

        branch0 = createAndSetTarget(target0);
    }

    @Override
    protected TransitionBranch getTransitionBranchNoCheck(int i) {
        return branch0;
    }


    @Override
    int getN() {
        return 1;
    }
}
