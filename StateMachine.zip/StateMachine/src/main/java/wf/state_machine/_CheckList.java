package wf.state_machine;

@SuppressWarnings({"ClassNamingConvention", "PackageVisibleInnerClass", "UnusedDeclaration", "EmptyClass"})
class _CheckList {
/**
 * <b>Valid check</b>
 * <li> OK - TopLevelState/Composite SMState has initial state
 * <li> OK- composite has at least one sub state
 * <li> check state transition and 'return' and internal transition not conflict
 * <li> guard return integer in range [0..n] -if not set to 0
 * no transition from final state
 * no transition to/from top level state
 * transition to final state only from brothers
 * no outgoing event2transitions from choose point
 * initial state must no be final state
 * region must have no outgoing transition nor final transition except to a 'join'
 * incoming transitions to final state only from inside parent
 * todo: this is a bug, no default state any more
 * initial state must not be fork or 'join', can be choice point with default branch
 * OK - incoming to final only from brother or brother descendant
 * OK - no outgoing transition from SMChoicePoint (handled by it's type SMStateVertex)
 * <p/>
 * PSEUDO STATES:
 * no trigger in outgoing transition
 * todo:boaz: move add transition method to concrete states, to avoid using wrong methods.for example add transition
 * with trigger to a pseudo state
 * <p/>
 * INITIAL STATE:
 * OK - no incoming event2transitions
 * OK - no two initial states
 * OK - initial state contained in state - do it recursively
 * OK - exactly one outgoing transition
 * OK - transition must be unary
 * <p/>
 * HISTORY:
 * OK at most one shallow and one deep history
 * OK - exactly one outgoing transition
 * OK - transition must be unary
 * - target:
 * OK - must be in container,
 * - and must be real state, (!! rec )
 * - and not final state (!! rec )
 * OK - top level state has no history ( no incoming/outgoing event2transitions )
 * <p/>
 * REGION:
 * outgoing from region is valid only out of or edge of concurrent container, or to
 * a 'join' in container
 * <p/>
 * FORK
 * OK - outgoing transition must end on region edge or inside transition, also it must not end
 * on 'join', we should check it recursively, because maybe a transition from a fork
 * is ended in choice point in region (which its ok), but later choice point will take
 * it outside region
 * OK - incoming transition must come from outside parent container
 * <p/>
 * CHOICE-POINT
 * check the c-p->target is valid transition (see REGION)
 * // todo: this is a bug, no default state any more
 * OK - dynamic - exactly one outgoing transition & default branch
 * OK - static - at most one outgoing transition
 * <p/>
 * <p/>
 * Join
 * OK - has at least one incoming transition
 * OK - all incoming event2transitions are from regions under 'join' parent
 * OK- exactly one outgoing transition out of parent
 * todo:boaz: outgoing transition must have default branch ?  if rule is too strict then how we leave Join later ?
 *            we can leave from transition from edge(currently). also we can that join can have more than one transition
 *            so if one failed, we can try the other one, in none is selected then still we can leave from edge.
 *            The current situation is that join can have transition with no default, and the only way to leave it, is
 *            if we have transition from edge.
 * OK - outgoing transition can't have trigger
 * OK     "-"               must end outside concurrent state
 * TODO: Check that all incoming are from different regions.

 * <p/>
 * Others:
 * NOT GOING TO IMP - endless loop in:
 * isAllPathTroughIsInContainer
 * findPathThrough
 *
 * todo:boaz: optimize resolve in SMTransitionGuardContext
 * <p/>
 * Not handled yet:
 * OK - 'and' events ( in SMState.processEvent)
 * OK - 'return transition' ( in SMState.processEvent)
 * OK - in state enter clear and events
 * in state exit clear local queue
 * OK - final states (composite & concurrent become final recursively)
 * check legal events in:
 * NO - handle (it's seems to me too much)
 * OK - define transitions
 * OK - internal transition
 * OK - return transition
 * CANT - after return transition - set target to null
 * <p/>
 * <p/>
 * <p/>
 * <B>need to implement</B>
 * <li> OK - Different handler type for each action: transition/do-activity/enter-state/exit-state
 * <li> OK - add method to cancel handler !!!
 *
 * <li> OK-Done.
 *              Add the ability to add unnamed states without ambiguity - and d'ont plot them</li>
 *              Need to document all places
 *
 * <p/>
 * <p/>
 *
 *
 *
 *
 *
 * <B>Errors</B>
 * <li>How to prevent add to 'return' transition handler 'by state'
 * <li>todo:boaz:fix: Many methods that modified machine don't call {@link StateMachineElementImp#setModified()}
 *                    Also there is no check that method modify machine during it's work
 *                    I suggest to add 3 states, definition, initialization, ready-to-go. In each public
 *                    method we should if we in valid state. For example handleTrigger is valid only in ready-to-go.
 *                    In initialization we should suspend all handlers(?). We should add method stop that will bring back to
 *                    'definition' state. Modification is allowed only in 'definition' state.
 *
 *
 * <p/>
 * <B>Removed features</B>
 * <li> OK - handlers queues (will be replaced by canceling handler)
 * <li> addToEndTransitionByEvent
 * <li> sub state machine
 *
 */

/**
 * Known Issues:
 * ============
 */
    /**
     * 1. In case of transition from/to inner state, there is asymmetric in action execution.
     * See comment in {@link SMState#onStateDo(wf.state_machine.SMStateHandler)}
     */
    interface KnownIssue1 {

    }

    /**
     * 2. In case of composite triggers. We try to resolve outer state before inner state.
     * This is in conflict with other logic that we try to resolve transitions from inner states
     * before outer states. I see it as a very minor problem: If some one declare translation
     * rule in inner state that conflict with outer state then he is playing with fire.
     * personally I don't believe that some one even will try to use inner state composite triggers.
     */
    interface KnownIssue2 {

    }



}