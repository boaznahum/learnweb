package wf.state_machine.outputers;

import org.jetbrains.annotations.NotNull;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

/**
 * User: Boaz Nahum
 * Date: Feb 20, 2006
 * Time: 2:53:08 AM
 */
public class DOMHelper {

    private DOMHelper() {
    }

    /**
     * Add node under inNode
     */
    public static Element domAddElement(Node inNode, String elementName) {

        Document root = inNode.getOwnerDocument();

        Element childNode = root.createElement(elementName);
        inNode.appendChild(childNode);

        return childNode;
    }

    /**
     * Add new node to parentNode. Given it name {@link XMLWriteable#getElementName()}.
     * Write body {@link XMLWriteable#writeBody(XMLContext, Element)} to the new create node
     * @param xmlContext
     * @param xmlWriteable
     * @param parentNode
     */
    public static void addAndWrite(XMLContext xmlContext, @NotNull XMLWriteable xmlWriteable,
                                Node parentNode) {

        String elementName = xmlWriteable.getElementName();

        addAndWrite(xmlContext, xmlWriteable, parentNode, elementName);
    }

    /**
     * Same as {@link #addAndWrite(XMLContext, XMLWriteable, Node)} but the node name is
     * explicitly specified.
     * This also will register xmlWriteable so it can be later retrieved by {@link XMLContext#findElementAssert(XMLWriteable)}
     * @param xmlContext
     * @param xmlWriteable
     * @param parentNode
     * @param elementName
     */
    public static void addAndWrite(XMLContext xmlContext,
                                   @NotNull  XMLWriteable xmlWriteable,
                                Node parentNode,
                                String elementName) {

        Element newNode = domAddElement(parentNode, elementName);

        xmlContext.registerElement(xmlWriteable, newNode);


        write(xmlContext, xmlWriteable, newNode);
    }

    /**
     * Write body and attributes in inNode
     * @param xmlContext
     * @param xmlWriteable
     * @param inNode
     */
    public static void write(XMLContext xmlContext, @NotNull  XMLWriteable xmlWriteable, Element inNode) {
        domWriteAttributes(xmlWriteable, inNode);
        xmlWriteable.writeBody(xmlContext, inNode);
    }

    private static void domWriteAttributes(@NotNull  XMLWriteable xmlWriteable, Element newNode) {
        XMLAttributeAndValue[] atvs = xmlWriteable.getAttributes();

        if (atvs != null) {

            for (XMLAttributeAndValue attributeAndValue : atvs) {
                String name = attributeAndValue.getName();
                String value = attributeAndValue.getValue().toString();

                newNode.setAttribute(name, value);
            }
        }
    }
}
