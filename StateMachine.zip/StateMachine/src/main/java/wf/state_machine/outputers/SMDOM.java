package wf.state_machine.outputers;

import org.w3c.dom.Document;
import org.jetbrains.annotations.Nullable;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.dom.DOMSource;
import java.io.File;

import wf.state_machine.StateMachine;

/**
 * User: Boaz Nahum
 * Date: Feb 19, 2006
 * Time: 11:25:31 PM
 */
public class SMDOM {

    private SMDOM() {
    }

    public static void write(@Nullable XMLContext xmlContext, String fileName, StateMachine sm) {

        Document doc = createSMDocument(xmlContext, sm);

        writeDoc(fileName, doc);
    }


//    public static Document createSMDocument(StateMachine sm) {
//    }

    /**
     *
     * @param sm
     */
    public static Document createSMDocument(@Nullable XMLContext xmlContext, StateMachine sm) {

        if (xmlContext == null) {
            xmlContext = new XMLContext(null);
        }

        Document doc = createDocument();

        sm.writeToDOM(xmlContext, doc);

        doc.normalize();
        return doc;

    }


    private static void writeDoc(String fileName, Document doc) {
        Source source = new DOMSource(doc);

        // Prepare the output file
        File file = new File(fileName);
        Result result = new StreamResult(file);

        // Write the DOM document to the file
        Transformer transformer;
        try {
            transformer = TransformerFactory.newInstance().newTransformer();
        } catch (TransformerConfigurationException e) {
            throw new RuntimeException(e);
        }

        transformer.setOutputProperty(OutputKeys.INDENT, "yes");

        try {
            transformer.transform(source, result);
        } catch (TransformerException e) {
            throw new RuntimeException(e);
        }
    }

    private static Document createDocument() {
        Document doc;
        DocumentBuilder builder;

        try {
            builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        } catch (ParserConfigurationException e) {
            throw new RuntimeException(e);
        }

        doc = builder.newDocument();

        return doc;
    }

}
