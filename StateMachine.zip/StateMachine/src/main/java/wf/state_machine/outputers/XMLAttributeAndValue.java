package wf.state_machine.outputers;

/**
 * Date: Mar 17, 2005
 *
 * @author Boaz Nahum
 */
public class XMLAttributeAndValue {

    private final String name;
    private final Object value;

    public XMLAttributeAndValue(String name, Object value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public Object getValue() {
        return value;
    }
}
