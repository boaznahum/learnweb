package wf.state_machine.outputers;

import gnu.trove.THashMap;
import org.w3c.dom.Element;
import wf.state_machine.outputers.dot.DotContext;
import wf.state_machine.outputers.dot.SMDotBuildError;

/**
 * @author Boaz Nahum
 * @version x.5
 */

public class XMLContext {

    private final DotContext dotContext;

    private final THashMap<XMLWriteable, Element> writeable2ElementMap = new THashMap<>();

    public XMLContext(DotContext dotContext) {
        this.dotContext = dotContext;
        if (dotContext != null) {
            dotContext.setParent(this);
        }
    }

    public DotContext getDotContext() {
        return dotContext;
    }

    /**
     * Associate writeable with it's element
     */
    public void registerElement(XMLWriteable xmlWriteable, Element element) {
        writeable2ElementMap.put(xmlWriteable, element);
    }

    public Element findElementAssert(XMLWriteable xmlWriteable) {

        Element element = writeable2ElementMap.get(xmlWriteable);

        if (element == null) {
            throw new SMDotBuildError("Can't find element for:" + xmlWriteable);
        }
        return element;
    }
}
