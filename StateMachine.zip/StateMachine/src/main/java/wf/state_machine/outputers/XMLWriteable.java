package wf.state_machine.outputers;

import org.w3c.dom.Element;

import wf.state_machine.outputers.XMLAttributeAndValue;

/**
 * Date: Mar 17, 2005
 *
 * @author Boaz Nahum
 */
public interface XMLWriteable {

    String getElementName();

    /**
     * @return null if none
     */
    XMLAttributeAndValue[] getAttributes();

    void writeBody(XMLContext xmlContext, Element inNode);

}
