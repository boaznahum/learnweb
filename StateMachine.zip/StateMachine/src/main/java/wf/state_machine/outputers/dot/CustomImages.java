package wf.state_machine.outputers.dot;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Boaz Nahum
 * @version WI VX.6, V12.0X, ADC V0.95
 */

class CustomImages {

    private static final Map<String, String> cache = new HashMap<>();

    private CustomImages() {}

    public static String getImagePath(String imageName) {

        String imageFullPath = cache.get(imageName);

        if (imageFullPath == null) {
            imageFullPath = createImage(imageName);
            cache.put(imageName, imageFullPath);
        }

        return imageFullPath;

    }

    private static String createImage(String imageName) {

        InputStream stream = CustomImages.class.getResourceAsStream("custom_images/" + imageName);

        try {
            File tempDir = new File(System.getProperty("java.io.tmpdir"), "sm-custom_images");
            //noinspection ResultOfMethodCallIgnored
            tempDir.mkdirs();
            tempDir.deleteOnExit();

            File tempFile = File.createTempFile("temp-", imageName, tempDir);

            tempFile.deleteOnExit();

            int size = stream.available();

            byte[] data = new byte[size];

            //noinspection ResultOfMethodCallIgnored
            stream.read(data);

            stream.close();

            FileOutputStream outputStream = new FileOutputStream(tempFile);

            outputStream.write(data);

            outputStream.close();

            return tempFile.getAbsolutePath();

        } catch (IOException e) {
            throw new SMDotBuildError("Unable to read custom image", e);
        }
    }
}
