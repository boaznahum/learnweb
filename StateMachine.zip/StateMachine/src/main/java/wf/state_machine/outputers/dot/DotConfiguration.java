package wf.state_machine.outputers.dot;

/**
 * @author Boaz Nahum
* @version x.5
*/ // dot configuration
public enum DotConfiguration {

    FDP("fdp", false, true, true, "LR"),
    DOT("dot", true, false, false, "LR"),
    DOT_TB("dot", true, false, false, "TB");

    public final boolean supportNode2ClusterArrow;
    /**
     * As above, for transitions from complex state to complex state
     */
    public final boolean supportCluster2ClusterArrow;

    //public static final String engineName = "dot";
    public final String engineName;
    public final boolean supportDirectGraph; // dot support direct - fdp un-direct ?

    //"TB", "LR", "BT", "RL"
    private final String rankDir;

    private DotConfiguration(String engineName,
                             boolean supportDirectGraph,
                             boolean supportNode2ClusterArrow,
                             boolean supportCluster2ClusterArrow,
                             String rankDir) {
        this.supportNode2ClusterArrow = supportNode2ClusterArrow;
        this.supportCluster2ClusterArrow = supportCluster2ClusterArrow;
        this.engineName = engineName;
        this.supportDirectGraph = supportDirectGraph;
        this.rankDir = rankDir;
    }

    public String getRankDir() {
        return rankDir;
    }
}
