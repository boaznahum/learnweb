package wf.state_machine.outputers.dot;

import org.jetbrains.annotations.Nullable;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import wf.state_machine.HiddenName;
import wf.state_machine.SMStateDotInfo;
import wf.state_machine.SMStateVertex;
import wf.state_machine.outputers.DOMHelper;
import wf.state_machine.outputers.XMLContext;
import wf.state_machine.outputers.XMLWriteable;

import java.io.PrintWriter;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

/**
 * @author Boaz Nahum
 * @version x.5
 */

public class DotContext {


    private static final String DOT_DATA_TAG = "dot_data";
    private static final String DUMMY_NODES_GO_HERE = "^DummyNodesGoHere:";

    private static final String SPACES;

    static {
        int log2N = 9; // N = 512;
        StringBuilder s = new StringBuilder(1 << log2N);
        s.append(" ");
        for (int i = 0; i < log2N; ++i) {
            s.append(s.toString());
        }
        SPACES = s.toString();
    }

    private final DotConfiguration dotConfiguration;
    private int uniqueID;

    private final HashMap<String, List<String>> state2DummyNodesMap = new HashMap<>();

    private XMLContext parent;


    public DotContext(DotConfiguration dotConfiguration) {
        this.dotConfiguration = dotConfiguration;
    }

    public static DotContext createDefaultConfiguration() {
        return new DotContext(DotHelper.getDefaultConfiguration());
    }

    public String getRandomUniqueIDStr() {
        return "_" + getRandomUniqueID();
    }

    public int getRandomUniqueID() {
        return (uniqueID++);
    }

    //public DotConfiguration getDotConfiguration() {
    //    return dotConfiguration;
    //}


    public boolean isSupportingNodeToClusterArrow() {
        return DotHelper.isSupportingNodeToClusterArrow(dotConfiguration);
    }

    public boolean isUseDirectGraph() {
        return DotHelper.isUseDirectGraph(dotConfiguration);
    }

    public String getConfigurationName() {
        return dotConfiguration.engineName;
    }

    public void addDotElement(Element inNode, String dotData) {
        Element dotElem = DOMHelper.domAddElement(inNode, DOT_DATA_TAG);
        dotElem.setTextContent(dotData);
    }

    public void addDotComment(Element inNode, String comment) {
        addDotElement(inNode, "// " + comment);
    }

    public static String concatenateAttributes(String... as) {

        StringBuilder c = new StringBuilder();

        boolean empty = true;
        for (String a : as) {

            if (a != null && !a.isEmpty()) {

                if (!empty) {
                    c.append(", ");
                } else {
                    empty = false;
                }

                c.append(a);
            }
        }
        return c.toString();
    }

    /**
     * If after concatenation as it is null or empty then return empty string, otherwise wrap it with '[' ']'
     *
     * @param as
     */
    public static String concatenateAttributesWrap(String... as) {

        String c = concatenateAttributes(as);

        return wrapAttributes(c);
    }

    /**
     * If a is null or empty then return empty string, otherwise wrap it with '[' ']'
     *
     * @param a
     */
    public static String wrapAttributes(String a) {

        if (a != null && !a.isEmpty()) {
            return "[" + a + "]";
        } else {
            return "";
        }
    }


    public boolean isSupportingClusterToClusterArrow() {
        return DotHelper.isSupportingClusterToClusterArrow(dotConfiguration);
    }

    private String getEdgeOperator() {
        return DotHelper.getEdgeOperator(dotConfiguration);
    }

    /**
     * Convert dot element to dot language
     */
    public void convertDotElement(Element element, PrintWriter pw, int nesting) {

        NodeList nodeList = element.getChildNodes();

        int n = nodeList.getLength();

        String nestingStr = getIndent(nesting);

        for (int i = 0; i < n; ++i) {

            Node node = nodeList.item(i);

            if (node instanceof Element) {

                Element e = (Element)node;

                if (e.getTagName().equals(DOT_DATA_TAG)) {
                    String dotData = e.getTextContent();
                    //is it place holder for dummy nodes
                    if (dotData.startsWith(DUMMY_NODES_GO_HERE)) {
                        String clusterName = dotData.substring(DUMMY_NODES_GO_HERE.length());
                        List<String> nodes = state2DummyNodesMap.get(clusterName);
                        if (nodes != null) {
                            for (String dummyNode : nodes) {
                                pw.print(nestingStr);
                                pw.println(dummyNode);
                            }
                        }
                    } else {
                        pw.print(nestingStr);
                        pw.println(dotData);
                    }
                } else {
                    convertDotElement(e, pw, nesting + 1);
                }
            }
        }
    }

    private static String getIndent(int nesting) {
        return SPACES.substring(0, nesting * 2);
    }

    public static String quoteLabel(String label) {

        return "\"" + label + "\"";

    }

    /**
     * Return "label=" + getName()
     *
     * @param state
     */
    public static String getDotLabelEqualsName(SMStateVertex state) {
        return "label=" + quoteStateLabel(state);
    }

    private static String quoteStateLabel(SMStateVertex state) {

        String dotLabel = state.getDotLabel();

        if (HiddenName.isHidden(dotLabel)) {
            dotLabel = "";
        }


        return quoteLabel(dotLabel);
    }


    public void addDummyNodesMarker(Element node, SMStateVertex smComplexState) {
        String dotName = smComplexState.getDotName();
        String dotElement = DUMMY_NODES_GO_HERE + dotName;
        addDotElement(node, dotElement);
    }

    public void addDummyNodeToCluster(SMStateDotInfo smComplexState, String nodeStatement) {

        String targetStateKey = smComplexState.getDotName();

        List<String> nodes = state2DummyNodesMap.get(targetStateKey);
        if (nodes == null) {
            nodes = new LinkedList<>();
            state2DummyNodesMap.put(targetStateKey, nodes);
        }

        nodes.add(nodeStatement);
    }

    public String createDotTransition(String sourceName,
                                      String targetName,
                                      String edgeAttributes) {

        String edgeOperator = getEdgeOperator();

        return sourceName + " " + edgeOperator + " " + targetName +
               wrapAttributes(edgeAttributes) +
               ";";
    }

    @Nullable
    public static Element findElementOfParent(Element myElement, SMStateVertex myState,
                                              SMStateVertex myParent) {

        //noinspection ObjectEquality
        if (myState == myParent) {
            return myElement;
        }

        myState = myState.getParent();
        if (myState == null) {
            return null;
        }

        myElement = (Element)myElement.getParentNode();
        if (myElement == null) {
            return null;
        }

        return findElementOfParent(myElement, myState, myParent);
    }

    public Element findElementAssert(XMLWriteable writeable) {
        return parent.findElementAssert(writeable);
    }

    public void setParent(XMLContext parent) {
        this.parent = parent;
    }

    /**
     * Return full path of image name
     * @param imageName for example final.png
     */
    public String getCustomImagePath(String imageName) {
        return CustomImages.getImagePath(imageName);

    }
}
