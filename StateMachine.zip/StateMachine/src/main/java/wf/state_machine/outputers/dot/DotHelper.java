package wf.state_machine.outputers.dot;

import org.jetbrains.annotations.Nullable;
import wf.state_machine.HiddenName;
import wf.state_machine.SMConcurrentState;
import wf.state_machine.SMStateVertex;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * User: Boaz Nahum
 * Date: Feb 20, 2006
 * Time: 7:46:56 PM
 */
public class DotHelper {

    //static final String DOT_INSTALL_DIR = "C:\\data\\my-sm\\graphviz\\2.20.2";

    // This version crash
    //static final String DOT_INSTALL_DIR = "C:\\data\\my-sm\\graphviz\\2.8";

    //static final String DOT_INSTALL_DIR = "C:\\data\\my-sm\\graphviz\\2.24\\installed";


    private static final DotConfiguration CURRENT_CONFIG = DotConfiguration.DOT;
    //private static final DotConfiguration CURRENT_CONFIG = DotConfiguration.FDP;


    public static final boolean LOG = true;


    private DotHelper() {
    }


    /**
     * When transition end in edge of complex state(cluster is behaved like a node),
     * We add a dummy node inside cluster, and cut the transition on edge of cluster.
     * This is because there is bug in DOT, that don't handle it correctly
     */
    public static boolean isSupportingNodeToClusterArrow(DotConfiguration configuration) {
        return configuration.supportNode2ClusterArrow;
    }

    /**
     * As above, for transitions from complex state to complex state
     */
    public static boolean isSupportingClusterToClusterArrow(DotConfiguration configuration) {
        return configuration.supportCluster2ClusterArrow;
    }

    public static boolean isUseDirectGraph(DotConfiguration configuration) {
        return configuration.supportDirectGraph;
    }

    public static String getUseEngine(DotConfiguration configuration) {
        return configuration.engineName;
    }

    public static DotConfiguration getDefaultConfiguration() {
        return CURRENT_CONFIG;
    }

    /**
     * Return edge operator. -- for un-direct, -> for direct
     */
    public static String getEdgeOperator(DotConfiguration configuration) {
        if (isUseDirectGraph(configuration)) {
            return "->";
        } else {
            return "--";
        }

    }

    /**
     * @param label if null then it is not added
     * @param parent
     */
    public static String buildRecordLabelForConcurrent(@Nullable String label, SMConcurrentState parent) {
        String record = "";
        boolean first = true;

        if (label != null && !HiddenName.isHidden(label)) {
            record += label;
            first = false;
        }

        for (int i = 0; i < parent.getSubStates().size(); ++i) {

            String id = "" + (i + 1);

            if (!first) {
                record += "|";
            } else {
                first = false;
            }
            String subLabel = " ";
            record += "<" + id + ">" + subLabel;
        }

        return record;
    }

    /**
     * Return "label:1"
     */
    public static String getRecordSubLabel(String mainLabel,
                                           SMConcurrentState parent,
                                           SMStateVertex subState) {

        SMStateVertex region = parent.findSubStateContainsOrEq(subState);

        if (region == null) { // bug
            return mainLabel;

        }

        // find the id of target
        int i = findSubStateIndex(parent, region);
        if (i < 0) { // bug
            return mainLabel;
        }

        String id = "" + (i + 1);

        return mainLabel + ":" + id;
    }

    static String getGraphvizInstallDir() {

        String installDir = System.getProperty("graphviz.install.dir");

        if (installDir != null && !installDir.isEmpty()) {
            return installDir;
        }

        Path sandboxRoot = findSandboxRoot();

        if (sandboxRoot != null) {
            Path defDir = sandboxRoot.resolve("Qlinks\\java\\graphviz");
            if (Files.exists(defDir)) {
                return defDir.toString();
            }
        }


        //noinspection SpellCheckingInspection
        String msg = "Please set 'graphviz.install.dir' property\n" +
                     "For example, from Intellij\n" +
                     "-Dgraphviz.install.dir=$VR$\\Qlinks\\java\\graphviz";

        throw new RuntimeException(msg);
    }


    /**
     * @return -1 if not found
     */
    private static int findSubStateIndex(SMConcurrentState parent, SMStateVertex region) {

        int i = 0;
        for (SMStateVertex r : parent.getSubStates()) {
            //noinspection ObjectEquality
            if (r == region) {
                return i;
            }
            ++i;
        }

        return -1;
    }

    private static Path findSandboxRoot() {

        Path p = Paths.get(".").toAbsolutePath();

        while (p != null) {

            if (
                Files.exists(p.resolve(".git")) ||
                Files.exists(p.resolve("VIEW.ROOT")) ||
                Files.exists(p.resolve(".jazz5"))
                ) {
                return p;
            }

            p = p.getParent();


        }
        return null;

    }



}
