package wf.state_machine.outputers.dot;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import wf.state_machine.StateMachine;
import wf.state_machine.outputers.SMDOM;
import wf.state_machine.outputers.XMLContext;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.List;


/**
 * Support for  Graphviz library
 * <p/>
 * User: Boaz Nahum
 * Date: Feb 20, 2006
 * Time: 7:40:38 PM
 */
@SuppressWarnings("UseOfSystemOutOrSystemErr")
public class SMDot {

    private SMDot() {
    }

    private static void createDotFile(@NotNull DotConfiguration dotConfiguration,
                                      StateMachine sm,
                                      File file) {

        final DotContext dotContext = new DotContext(dotConfiguration);
        XMLContext xmlContext = new XMLContext(dotContext);

        Document smDoc = SMDOM.createSMDocument(xmlContext, sm);

        Element rootElement = smDoc.getDocumentElement();

        PrintWriter pw;

        try {
            pw = new PrintWriter(new FileWriter(file));
        } catch (IOException e) {
            throw new RuntimeException("Can't create file:" + file, e);
        }

        try {
            dotContext.convertDotElement(rootElement, pw, 0);
        } finally {
            pw.close();
        }

    }

    //public static void createImageFile(StateMachine sm, File imageFile) {
    //    createImageFile(null, sm, imageFile, null);
    //}


    /**
     * @param sm
     * @param imageFileName - if null then a temporary file is created
     * @param dotFileName
     * @param dotConfiguration if null then default is used.see {@link DotHelper#getDefaultConfiguration()}
     */
    public static void createImageFile(@Nullable DotConfiguration dotConfiguration,
                                       StateMachine sm,
                                       String imageFileName,
                                       String dotFileName) {

        dotConfiguration = getDefault(dotConfiguration);

        File imageFile = new File(imageFileName);

        createImageFile(dotConfiguration, sm,
                        imageFile,
                        dotFileName == null ? null : new File(dotFileName));
    }

    private static DotConfiguration getDefault(DotConfiguration dotConfiguration) {

        if (dotConfiguration == null) {
            return DotHelper.getDefaultConfiguration();
        } else {
            return dotConfiguration;
        }

    }

    /**
     * Create jpg file
     *
     * @param sm
     * @param dotFile if null then temporary file is created and deleted at end of processing
     * @param imageFile
     */
    public static void createImageFile(DotConfiguration dotConfiguration,
                                       StateMachine sm,
                                       File imageFile,
                                       File dotFile) {

        dotConfiguration = getDefault(dotConfiguration);

        boolean tempDotFile;

        if (dotFile == null) {

            tempDotFile = true;

            try {
                dotFile = File.createTempFile("state_machine_dot_file", ".dot");
            } catch (IOException e) {
                throw new RuntimeException("Can't create temp file", e);
            }
        } else {
            tempDotFile = false;
        }

        createDotFile(dotConfiguration, sm, dotFile);

        try {
            runDotCommand(dotConfiguration, dotFile, imageFile.getAbsolutePath());
        } finally {
            if (tempDotFile) {
                //noinspection ResultOfMethodCallIgnored
                dotFile.delete();
            }
        }

        if (DotHelper.LOG) {
            //noinspection UseOfSystemOutOrSystemErr
            System.out.println("Image file is:" + imageFile.getAbsoluteFile());
        }


        }

    @SuppressWarnings("SpellCheckingInspection")
    private static void runDotCommand(DotConfiguration configuration, File dotFile, String imageFileName) {

        String os = System.getProperty("os.name").toLowerCase();

        String dotCommand;

        String useEngine = DotHelper.getUseEngine(configuration);

        if (isUnix(os)) {
            dotCommand = useEngine;
        }else {

            dotCommand = DotHelper.getGraphvizInstallDir() + "\\bin\\" + useEngine + ".exe";
        }


        String arg1 = dotFile.getAbsolutePath();//.replace("\\", "/");
        String arg2 = "-Tjpg";
        String arg3 = "-o";
        String arg4 = new File(imageFileName).getAbsolutePath();//.replace("\\", "/");


        ProcessBuilder pb = new ProcessBuilder(
            dotCommand,
            "-Grankdir=" + configuration.getRankDir(), // copied from graphviz-2.8\graphs\directed\states.dot
            arg1,
            arg2,
            arg3,
            arg4);

        if (DotHelper.LOG) {
            System.out.println("Dot file is:" + dotFile.getAbsoluteFile());
            System.out.println("param: USE_DOT_VS_FDP=" + useEngine);
            System.out.println("param: USE_DUMMY_FOR_NODE_CLUSTER=" + !DotHelper.isSupportingNodeToClusterArrow(
                configuration));
            System.out
                .println("param: USE_DUMMY_FOR_CLUSTER_CLUSTER=" + !DotHelper.isSupportingClusterToClusterArrow(
                    configuration));
            System.out.println("Running command:");
            List<String> command = pb.command();
            for (String c : command) {
                System.out.println("  " + c);
            }
        }

        pb.redirectErrorStream(true);

        Process p;

        try {
            p = pb.start();
        } catch (IOException e) {
            throw new RuntimeException("Can't create process", e);
        }

        InputStream is = p.getInputStream();

        OutputStream myOutput = new ByteArrayOutputStream();

        try {
            int c;
            while ((c = is.read()) != -1) {
                System.err.write(c);
                myOutput.write(c);
            }
        } catch (IOException e) {
            throw new RuntimeException("Error reading error stream", e);
        }

        int exitCode;


        try {
            exitCode = p.waitFor();
        } catch (InterruptedException e) {
            throw new RuntimeException("Interrupted when running process", e);
        }

        if (DotHelper.LOG) {
            System.out.println("--------------------------------------------------------");
        }


        if (exitCode != 0) {
            throw new RuntimeException("Process finished with error code:" + exitCode +
                                       "\n" + myOutput.toString());
        }
    }

    private static boolean isUnix(String os) {

        return (os.contains("nix") || os.contains("nux") || os.indexOf("aix") > 0 );

    }

}
