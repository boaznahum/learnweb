package wf.state_machine.outputers.dot;

/**
 * @author Boaz Nahum
 * @version WI VX.6, V12.0X, ADC V0.95
 */

public class SMDotBuildError extends Error {

    public SMDotBuildError(String s) {
        super(s);
    }

    public SMDotBuildError(String message, Throwable cause) {
        super(message, cause);
    }
}
