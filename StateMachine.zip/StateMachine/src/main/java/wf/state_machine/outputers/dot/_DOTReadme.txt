Line attributes and other
//http://www.graphviz.org/doc/info/attrs.html

