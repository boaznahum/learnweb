package wf.state_machine.smlogger;

import org.jetbrains.annotations.Nullable;
import wf.state_machine.SMBaseTrigger;
import wf.state_machine.SMGuard;
import wf.state_machine.SMStateVertex;
import wf.state_machine.SMTransitionSegment;
import wf.state_machine.StateMachine;

import java.util.List;

/**
 * All logging methods must be thread safe.
 */
public interface SMAuditor {

    /**
     * Attach state machine to log.<br>
     * This is event {@link SMLogEvent#ATTACH}
     */
    void attach(SMLogEvent logEvent, StateMachine sm);

    /**
     * Detach state machine from log.<br>
     * This is event {@link SMLogEvent#DETACH}
     */
    void detach(SMLogEvent logEvent, StateMachine sm);

    void logEvent(StateMachine sm,
                  SMLogEvent event,
                  SMStateVertex source,
                  SMBaseTrigger trigger,
                  SMStateVertex target);

    void logQueryingTransitionGuard(SMLogEvent logEvent,
                                    StateMachine sm, SMStateVertex source,
                                    SMBaseTrigger trigger,
                                    SMGuard guard, SMStateVertex[] candidateTargets);

    void logEndQueryingTransitionGuard(SMLogEvent logEvent,
                                    StateMachine sm, SMStateVertex source,
                                    SMBaseTrigger trigger,
                                    @Nullable SMGuard guard,
                                    @Nullable SMStateVertex selectedTarget);

    /**
     * Actually this is event {@link SMLogEvent#START_OF_SEGMENTS_PROCESSING}
     * @param event
     * @param sm
     * @param segments
     */
    void beginTransitionsSegments(SMLogEvent event,
                                  StateMachine sm,
                                  List<? extends SMTransitionSegment> segments);

    void logUserMsg(SMLogEvent logEvent, StateMachine sm, String msg);

}