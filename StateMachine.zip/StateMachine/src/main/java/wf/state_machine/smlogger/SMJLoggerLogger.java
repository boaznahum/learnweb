package wf.state_machine.smlogger;

import java.util.EnumMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * A logger wrapped java logger {@link java.util.logging.Logger}
 * <p/>
 * User: Boaz Nahum
 * Date: Feb 16, 2006
 * Time: 9:56:54 PM
 */
public class SMJLoggerLogger extends SMTextualLogger {

    protected final Logger logger;

    protected final Map<SMLogEvent, Level> eventsLogLevel =
        new EnumMap<>(SMLogEvent.class);

    /**
     * @param logger
     * @param defaultLevel default level for all events,
     *                     can be modified by {@link #setEventLevel(SMLogEvent, java.util.logging.Level)}
     */

    private SMJLoggerLogger(Logger logger, Level defaultLevel) {
        this.logger = logger;
        for(SMLogEvent event: SMLogEvent.values()) {
            eventsLogLevel.put(event, defaultLevel);
        }
    }

    /**
     * Set default level for all events {@link Level#FINEST}
     * @param logger
     */
    public SMJLoggerLogger(Logger logger) {
        this(logger, Level.FINEST);
    }

    public void setEventLevel(SMLogEvent event, Level level) {
        eventsLogLevel.put(event, level);
    }


    @Override
    protected void log(SMLogEvent event, String msg) {

        Level eventLevel = eventsLogLevel.get(event);
        logger.log(eventLevel, msg);
    }


}
