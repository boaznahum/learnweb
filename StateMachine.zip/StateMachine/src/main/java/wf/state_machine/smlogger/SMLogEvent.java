package wf.state_machine.smlogger;

import static wf.state_machine.smlogger.SMLogEventType.*;

public enum SMLogEvent {

    /**
     * Attach to log
     */
    ATTACH("Attach to logger"),
    DETACH("Detach from logger"),
    USER_MSG("User Msg"),


    /**
     * SMState machine got init command
     */
    GOT_INIT_COMMAND("Got Init Command"),

    /**
     * Start processing init command
     */
    START_OF_INIT_COMMAND_PROCESSING("Start Init", BEGIN_OF_SEQ),

    /**
     * End of processing init command
     */
    END_OF_INIT_COMMAND_PROCESSING("End Init", END_OF_SEQ),

    /**
     *State Machine got trigger
     * !!! This trigger may logged outside 'machine processing thread' !!!
     *
     */
    MACHINE_GOT_TRIGGER("Machine got trigger"),

    /**
     * SMState Machine is processing trigger
     */
    MACHINE_START_PROCESSING_TRIGGER("State Machine is processing trigger", BEGIN_OF_SEQ),

    /**
     * SMState Machine finished processing trigger
     * Msg: source the state when processing trigger
     *      target: the state we arrived at end
     */
    MACHINE_END_PROCESSING_TRIGGER("Machine finished processing trigger", END_OF_SEQ),

    MACHINE_IGNORING_CANCELED_TRIGGER("Machine ignoring canceled trigger"),


    MACHINE_SCHEDULING_TRIGGER("Machine scheduling trigger"),
    MACHINE_CANCELING_SCHEDULED_TRIGGER("Machine canceling scheduled trigger"),


    /**
     * SMState got and processing trigger
     */
    STATE_GOT_TRIGGER("State got and processing trigger"),

    /**
     * SMState got part of and trigger
     */
    GOT_PART_OF_COMPLEX_TRIGGER("State got part of and trigger"),

    /**
     * SMState got completed complex trigger
     */
    GOT_END_COMPLEX_TRIGGER("State got completed complex trigger"),

    /**
     * Adding trigger to state local queue
     */
    PROCESSING_STATE_LOCAL_TRIGGER("Start processing state local trigger"),

    /**
     * Sending local trigger to state
     */
    ADDING_LOCAL_TRIGGER_TO_STATE("Adding local trigger to state"),

    /**
     * Begin 'internal transition' handlers
     */
    BEGIN_INTERNAL_TRANSITION_HANDLERS(BEGIN_HANDLERS_S + "'internal transition'", BEGIN_HANDLERS),

    /**
     * End 'internal transition' handlers
     */
    END_INTERNAL_TRANSITION_HANDLERS(END_HANDLERS_S + "'internal transition'", END_HANDLERS),

    /**
     * Start checking candidate transitions
     */
    BEGIN_QUERYING_CANDIDATE_TRANSITIONS("Checking candidate transitions", BEGIN_OF_SEQ),

     /**
     * End of checking candidate transitions
     */
    END_QUERYING_CANDIDATE_TRANSITIONS("End checking candidate transitions", END_OF_SEQ),

    /**
     * Querying transition guard
     */
    BEGIN_QUERYING_TRANSITION("Querying transition", BEGIN_OF_SEQ),

    /**
     * After querying transition guard
     */
    END_QUERYING_TRANSITION("End querying transition", END_OF_SEQ),

    /**
     * Start transition
     */
    START_OF_TRANSITION("Start transition", BEGIN_OF_SEQ),

    /**
     * End of transition
     */
    END_OF_TRANSITION("End of transition", END_OF_SEQ),

    /**
     * Start of multi segment transition
     */
    START_OF_SEGMENTS_PROCESSING("Start of segments processing", BEGIN_OF_SEQ),

    /**
     * End of multi segment transition
     */
    END_OF_SEGMENTS_PROCESSING("End of segments processing", END_OF_SEQ),

    /**
     * Begin state exit
     */
    BEGIN_STATE_EXIT("Begin state exit", BEGIN_OF_SEQ),

    /**
     * Begin terminate 'Do Activity' handlers
     */
    BEGIN_TERMINATE_STATE_ACTIVITY_HANDLERS(BEGIN_HANDLERS_S + "'terminate state activity' handlers", BEGIN_HANDLERS),

    /**
     * End terminate 'Do Activity' handlers
     */
    END_TERMINATE_STATE_ACTIVITY_HANDLERS(END_HANDLERS_S + "'terminate state activity'", END_HANDLERS),
    // state exit

    /**
     * Begin exit handlers
     */
    BEGIN_EXIT_HANDLERS(BEGIN_HANDLERS_S + "'exit'", BEGIN_HANDLERS),

    /**
     * End exit handlers
     */
    END_EXIT_HANDLERS(END_HANDLERS_S + "'exit'", END_HANDLERS),

    /**
     * End state exit
     */
    END_STATE_EXIT("End state exit", END_OF_SEQ),

    /**
     * Begin transition handlers
     */
    BEGIN_TRANSITION_HANDLERS(BEGIN_HANDLERS_S + "'transition'", BEGIN_HANDLERS),

    /**
     * End transition handlers
     */
    END_TRANSITION_HANDLERS(END_HANDLERS_S + "'transition'", END_HANDLERS),

    /**
     * Begin 'end transition' handlers
     */
    BEGIN_END_TRANSITION_HANDLERS(BEGIN_HANDLERS_S + "'end transition'", BEGIN_HANDLERS),

    /**
     * End 'end transition' handlers
     */
    END_END_TRANSITION_HANDLERS(END_HANDLERS_S + "'end transition'", END_HANDLERS),

    /**
     * Begin state Entry
     */
    BEGIN_STATE_ENTRY("Begin state Entry", BEGIN_OF_SEQ),

    /**
     * Begin entry handlers
     */
    BEGIN_ENTRY_HANDLERS(BEGIN_HANDLERS_S + "'state entry'", BEGIN_HANDLERS),

    /**
     * End entry handlers
     */
    END_ENTRY_HANDLERS(END_HANDLERS_S + "state entry", END_HANDLERS),

    /**
     * End state Entry
     */
    END_STATE_ENTRY("End state Entry", END_OF_SEQ),


    /**
     * on state
     */
    ON_STATE("On SMState"),

    /**
     * Begin 'Do Activity' handlers
     */
    BEGIN_START_STATE_ACTIVITY_HANDLERS(BEGIN_HANDLERS_S + "'start state activity'", BEGIN_HANDLERS),

    /**
     * End 'Do Activity' handlers
     */
    END_START_STATE_ACTIVITY_HANDLERS(END_HANDLERS_S + "'start state activity'", END_HANDLERS);



    private final String mName;
    private final SMLogEventType type;


    SMLogEvent(String name, SMLogEventType type) {
        mName = name;
        this.type = type;
    }

    SMLogEvent(String name) {
        this(name, NONE);
    }

    @Override
    public final String toString() {
        return mName;
    }

    public boolean isBeginOfSequence() {
        return type == BEGIN_OF_SEQ || type == BEGIN_HANDLERS;
    }

    public boolean isEndOfSequence() {
        return type == END_OF_SEQ || type == END_HANDLERS;
    }
}