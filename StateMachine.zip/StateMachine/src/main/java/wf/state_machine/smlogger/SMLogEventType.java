package wf.state_machine.smlogger;

/**
 * @author Boaz Nahum
 * @version 7.3
 */
enum SMLogEventType {

    NONE,
    BEGIN_OF_SEQ,
    END_OF_SEQ,
    BEGIN_HANDLERS,
    END_HANDLERS;

    static final String BEGIN_HANDLERS_S = "-->";
    static final String END_HANDLERS_S = "<--";
}
