package wf.state_machine.smlogger;

import wf.state_machine.SMStateVertex;

/**
 * @author Boaz Nahum
 * @version WI VX.6, V12.0X, ADC V0.95
 */

public class SMLogHelper {

    private SMLogHelper() {
    }

    public static String getSourceName(SMStateVertex source) {
        return getStateName(source);
    }

    public static String getTargetName(SMStateVertex target) {
        return getStateName(target);
    }

    private static String getStateName(SMStateVertex state) {
        if(state == null) {
            return "";
        } else if (state.isTopLevel()) {
            return "^TOP^";
        } else {
            return state.getName();
        }
    }
}
