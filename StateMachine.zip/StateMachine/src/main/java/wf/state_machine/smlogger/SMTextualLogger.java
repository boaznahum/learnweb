package wf.state_machine.smlogger;

import org.jetbrains.annotations.Nullable;
import wf.state_machine.*;

import java.util.List;

public abstract class SMTextualLogger implements SMAuditor {

    SMTextualLogger() {
    }

    protected abstract void log(SMLogEvent event, String msg);

    @Override
    public void attach(SMLogEvent logEvent, StateMachine sm) {
        log(logEvent, "SMState machine: " + sm.getName() + " attached");
    }

    @Override
    public void detach(SMLogEvent logEvent, StateMachine sm) {
        log(logEvent, "SMState machine: " + sm.getName() + " detached");
    }

    @Override
    public void logEvent(StateMachine sm,
                         SMLogEvent event,
                         SMStateVertex source,
                         SMBaseTrigger trigger,
                         SMStateVertex target) {

        log(event, formatEvent(sm, event, source, trigger, target));
    }

    @Override
    public void logQueryingTransitionGuard(SMLogEvent logEvent, StateMachine sm, SMStateVertex source,
                                           SMBaseTrigger trigger,
                                           SMGuard guard, SMStateVertex[] candidateTargets) {
        //throw new RuntimeException("not yet");
    }

    @Override
    public void logEndQueryingTransitionGuard(SMLogEvent logEvent, StateMachine sm, SMStateVertex source,
                                              SMBaseTrigger trigger, @Nullable SMGuard guard,
                                              @Nullable SMStateVertex selectedTarget) {
        //throw new RuntimeException("not yet");
    }


    protected String formatEvent(StateMachine sm, SMLogEvent event, SMStateVertex source, SMBaseTrigger trigger,
                       SMStateVertex target) {
        return sm.getName() + ": " + event + "\n" +
                "\tSource: " + source +
                "\tTrigger:" + trigger +
                "\tTarget: " + target;
    }

    @Override
    public void beginTransitionsSegments(SMLogEvent event, StateMachine sm, List<? extends SMTransitionSegment> segments) {

        StringBuilder msg = new StringBuilder("begin of segments processing");

        for (SMTransitionSegment segment : segments) {

            msg.append("\n");

            msg.append("\tSource: ");
            msg.append(segment.getSource());
            msg.append(", Trigger:");
            msg.append(segment.getTrigger());
            msg.append(", Target: ");
            msg.append(segment.getTarget());

        }



        log(SMLogEvent.START_OF_SEGMENTS_PROCESSING, msg.toString());
    }

    @Override
    public void logUserMsg(SMLogEvent logEvent, StateMachine sm, String msg) {
        log(SMLogEvent.USER_MSG, "User Msg: " + msg);
    }

}