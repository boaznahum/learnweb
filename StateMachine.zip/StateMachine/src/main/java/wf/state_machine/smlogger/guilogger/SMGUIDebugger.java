package wf.state_machine.smlogger.guilogger;

import wf.state_machine.StateMachine;
import wf.state_machine.smlogger.SMAuditor;

/**
 * @author Boaz Nahum
 */

public interface SMGUIDebugger extends SMAuditor {

    /**
     * Create multi machine debugger that can display/debug multiple machines
     */
    static SMGUIDebugger createMM() {
        return new SMMultiMachineGUIDebugger();
    }

    /**
     * Create multi machine debugger that can display/debug multiple machines and attach one SM to it
     */
    static SMGUIDebugger createMM(StateMachine sm) {
        SMGUIDebugger d = new SMMultiMachineGUIDebugger();
        sm.attachTo(d);
        return d;
    }
}
