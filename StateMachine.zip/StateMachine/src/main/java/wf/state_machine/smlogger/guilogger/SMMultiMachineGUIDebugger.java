package wf.state_machine.smlogger.guilogger;

import org.jetbrains.annotations.Nullable;
import wf.state_machine.SMBaseTrigger;
import wf.state_machine.SMGuard;
import wf.state_machine.SMStateVertex;
import wf.state_machine.SMTransitionSegment;
import wf.state_machine.StateMachine;
import wf.state_machine.smlogger.SMLogEvent;
import wf.state_machine.smlogger.guilogger.iforms.DebuggerMainPanelForm;

import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;

/**
 * @author Boaz Nahum
 * @version 7.3
 */
public class SMMultiMachineGUIDebugger implements SMGUIDebugger  {

    private final DebuggerMainPanelForm mainForm;

    private final Map<StateMachine, SMSingleMachineGUIDebugger> machines =
            new HashMap<>();

    /**
     * {@link #showInFrame()} was already called
     */
    private boolean showed;


    SMMultiMachineGUIDebugger() {
        this(true);
    }

    /**
     *
     * @param show if false, then you need later to call {@link #showInFrame()}
     */
    private SMMultiMachineGUIDebugger(boolean show) {

        mainForm = new DebuggerMainPanelForm();

        if (show) {
            showInFrame();
        }

    }

    private SMSingleMachineGUIDebugger findSMDebugger(StateMachine sm) {
        return machines.get(sm);
    }

    @Override
    public void attach(SMLogEvent logEvent, StateMachine sm) {

        SMSingleMachineGUIDebugger smDebugger = new SMSingleMachineGUIDebugger();

        mainForm.getTabbedPaneSMs().addTab(sm.getName(), smDebugger.getMainPanel());

        smDebugger.attach(logEvent, sm);

        machines.put(sm, smDebugger);

    }

    @Override
    public void detach(SMLogEvent logEvent, StateMachine sm) {

        SMSingleMachineGUIDebugger  smDebugger = findSMDebugger(sm);

        smDebugger.detach(logEvent, sm);

        machines.remove(sm);

        mainForm.getTabbedPaneSMs().remove(smDebugger.getMainPanel());

    }

    @Override
    public void logEvent(StateMachine sm,
                         SMLogEvent event,
                         SMStateVertex source,
                         SMBaseTrigger trigger,
                         SMStateVertex target) {

        SMSingleMachineGUIDebugger  smDebugger = findSMDebugger(sm);

        smDebugger.logEvent(sm,
                            event,
                            source,
                            trigger,
                            target);

    }

    @Override
    public void logQueryingTransitionGuard(SMLogEvent logEvent,
                                           StateMachine sm,
                                           SMStateVertex source,
                                           SMBaseTrigger trigger,
                                           SMGuard guard,
                                           SMStateVertex[] candidateTargets) {

        SMSingleMachineGUIDebugger  smDebugger = findSMDebugger(sm);

        smDebugger.logQueryingTransitionGuard(logEvent,
                                              sm,
                                              source,
                                              trigger,
                                              guard,
                                              candidateTargets);




    }

    @Override
    public void logEndQueryingTransitionGuard(SMLogEvent logEvent, StateMachine sm, SMStateVertex source,
                                              SMBaseTrigger trigger, @Nullable SMGuard guard,
                                              @Nullable SMStateVertex selectedTarget) {
        SMSingleMachineGUIDebugger smDebugger = findSMDebugger(sm);

        smDebugger.logEndQueryingTransitionGuard(logEvent,
                                              sm,
                                              source,
                                              trigger,
                                              guard,
                                              selectedTarget);

    }

    @Override
    public void beginTransitionsSegments(SMLogEvent event,
                                         StateMachine sm,
                                         List<? extends SMTransitionSegment> segments) {

        SMSingleMachineGUIDebugger  smDebugger = findSMDebugger(sm);

        smDebugger.beginTransitionsSegments(
                event,
                sm,
                segments
        );

    }

    @Override
    public void logUserMsg(SMLogEvent logEvent,
                           StateMachine sm,
                           String msg) {

        SMSingleMachineGUIDebugger  smDebugger = findSMDebugger(sm);

        smDebugger.logUserMsg(logEvent, sm, msg);

    }

    private JFrame createAndShowFrame() {
        //Make sure we have nice window decorations.
        JFrame.setDefaultLookAndFeelDecorated(true);

        //Create and set up the window.
        JFrame frame = new JFrame("State Machine");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel mainPanel = mainForm.getMainPanel();
        mainPanel.setOpaque(true); //content panes must be opaque

        frame.setContentPane(mainPanel);

        //Display the window.
        //frame.pack();
        Rectangle rect = GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds();
        double fraction = 0.75;
        frame.setSize((int)(rect.getWidth() * fraction), (int)(rect.getHeight() * fraction));
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        

        return frame;
    }

    @SuppressWarnings({"CallToPrintStackTrace"})
    private void showInFrame() {

        if (showed) {
            return;
        }

        showed = true;

        Callable<JFrame> cl = this::createAndShowFrame;

        FutureTask<JFrame> f = new FutureTask<>(cl);

        SwingUtilities.invokeLater(f);

        try {
            f.get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }

    }

}
