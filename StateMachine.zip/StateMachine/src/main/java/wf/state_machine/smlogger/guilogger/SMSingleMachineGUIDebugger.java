package wf.state_machine.smlogger.guilogger;

import org.jetbrains.annotations.Nullable;
import wf.state_machine.SMBaseTrigger;
import wf.state_machine.SMGuard;
import wf.state_machine.SMStatePathTree;
import wf.state_machine.SMStateVertex;
import wf.state_machine.SMTransitionSegment;
import wf.state_machine.SMUTrigger;
import wf.state_machine.StateMachine;
import wf.state_machine.outputers.dot.DotConfiguration;
import wf.state_machine.outputers.dot.DotHelper;
import wf.state_machine.outputers.dot.SMDot;
import wf.state_machine.smlogger.SMLogEvent;
import wf.state_machine.smlogger.SMLogHelper;
import wf.state_machine.smlogger.SMAuditor;
import wf.state_machine.smlogger.guilogger.iforms.DebuggerSMPanelForm;
import wf.state_machine.util.TextUtil;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.io.File;
import java.io.IOException;
import java.lang.ref.SoftReference;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Date: Mar 24, 2005
 *
 * @author Boaz Nahum
 */
@SuppressWarnings("SSBasedInspection")
public class SMSingleMachineGUIDebugger extends DebuggerSMPanelForm implements SMAuditor {

    private boolean initialized;

    private StateMachine sm;
    private final DefaultStyledDocument doc;

    private final JTextPane textPane;
    private final DefaultListModel<String> eventsQueueListModel = new DefaultListModel<>();

    //private SMImageIcon imageComponent;

    private final List<Runnable> commandQueue = new LinkedList<>();

    // pause
    private boolean isPaused;
    private int nextPressed;
    private final Lock pauseLock = new ReentrantLock();
    private final Condition pauseCondition = pauseLock.newCondition();

//    private Thread myEventsSendingThread;
//    private BlockingQueue<SMTrigger> myEventsSendingQueue;
//    private SMTrigger myDieTrigger;


    // styles
    private Style arrowStyle;
    private Style logEventStyle;
    private Style sourceStateStyle;
    private Style triggerStyle;
    private Style targetStateStyle;
    private Style userMsgStyle;

    private int indentLevel;

    private int triggerFieldWidth = 10;
    private int sourceStateFieldWidth = 25;
    private int targetStateFieldWidth = 25;

    //=================================================
    // support for imaging caching
    private final HashMap<String, ImageData> state2image = new HashMap<>();

    private String lastDisplayedState = "-1";


    private static final int MAX_LOG_EVENT_WIDTH;
    private static final String ARROW_LEFT = "-->";
    private static final String ARROW_RIGHT = "-->";

    static {
        int max = 0;
        for (SMLogEvent e : SMLogEvent.values()) {
            int n = e.toString().length();
            if (n > max) {
                max = n;
            }
        }

        MAX_LOG_EVENT_WIDTH = max;
    }

    private static final int MAX_INDENT = 8;
    private static final int INDENT_WIDTH = 1;

    private static class ImageData {

        private final SoftReference<BufferedImage> imageRef;
        private final File tmpImageFile;

        ImageData(File tmpImageFile, BufferedImage image) {
            this.tmpImageFile = tmpImageFile;
            imageRef = new SoftReference<>(image);
        }

        /**
         * @return null if image GC
         */
        public BufferedImage getImage() {
            return imageRef.get();
        }

        public File getTmpImageFile() {
            return tmpImageFile;
        }
    }


    public SMSingleMachineGUIDebugger() {

        doc = new DefaultStyledDocument();

        listEventsQueue.setModel(eventsQueueListModel);

        //Create an editor pane.
        textPane = createTextPane(doc);
        JComponent logTextPane = createLogPane(textPane);
        logPanel.setLayout(new OverlayLayout(logPanel));
        logPanel.add(logTextPane);
        createStyles();

        setUpPauseButtons();

        setUpEventsQueue();


        setUpInitButton();

        setUpConfigControls();

        setAttackButton();

        setupShowButton();

        setupReDrawButton();

        setupOpenImageButton();

        makeTabbedPaneDetachable();


//        imageComponent = new SMImageIcon();
//
//        drawPanel.setLayout(new GridLayout(1,1));
//
//        drawPanel.add(imageComponent);
    }


    @Override
    protected void createUIComponents() {
        super.createUIComponents();
        comboBoxDotConfiguration = new JComboBox<>(DotConfiguration.values());
        comboBoxDotConfiguration.setSelectedItem(DotHelper.getDefaultConfiguration());

        comboBoxDotConfiguration.addActionListener(e -> {

            // clear cache
            state2image.clear();
            lastDisplayedState = "-1";

        });

    }

    private void setAttackButton() {
        attackButton.addActionListener(e -> attack());
    }


    private void setupShowButton() {
        showButton.addActionListener(ev -> updateMachineImageFrame());
    }

    private void setupOpenImageButton() {
        openImageButton.addActionListener(ev -> openImageInExternalViewer());
    }


    private void setupReDrawButton() {
        reDrawButton.addActionListener(e -> invalidateAndRedrawImageIfNeed());
    }


    private void makeTabbedPaneDetachable() {
        tabbedPane.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                if (e.getClickCount() == 2) {
                    detachTab(e);
                }
            }
        });
    }

    private void detachTab(MouseEvent e) {
        final int tabIdx = tabbedPane.getUI().tabForCoordinate(tabbedPane, e.getX(), e.getY());

        if (tabIdx > -1) {
            final Component tab = tabbedPane.getComponentAt(tabIdx);
            final String tabName = tabbedPane.getTitleAt(tabIdx);
            tabbedPane.remove(tabIdx);
            final JFrame frame = new DetachedFrame(tabbedPane, tab,
                                                   tabName, tabIdx,
                                                   sm.getName() + ":" + tabName);

            frame.pack();
            frame.setVisible(true);
        }
    }

    private static class DetachedFrame extends JFrame {

        private final JTabbedPane originalContainer;
        private final Component tab;
        private final String originalTabName;
        private final int originalTabIndex;


        private DetachedFrame(JTabbedPane originalContainer,
                              Component tab,
                              String originalTabName,
                              int originalTabIndex,
                              String nameWhenDetached) throws HeadlessException {
            this.originalContainer = originalContainer;
            this.tab = tab;
            this.originalTabName = originalTabName;
            this.originalTabIndex = originalTabIndex;

            add(tab);
            setTitle(nameWhenDetached);
            addWindowListener(new OnCloseListener());

        }

        private class OnCloseListener extends WindowAdapter {

            @Override
            public void windowClosing(WindowEvent e) {
                super.windowClosing(e);
                //To change body of overridden methods use File | Settings | File Templates.
                removeAll();
                int insertionIndex =
                    Math.min(originalTabIndex, originalContainer.getTabCount());
                originalContainer.insertTab(originalTabName, null,
                                            tab, "",
                                            insertionIndex);
                dispose();
            }
        }
    }

    private void updateMachineImageFrame() {

        if (sm == null) {
            return;
        }

        String currentState = getCurrentStateString();

        if (currentState.endsWith(lastDisplayedState)) {
            return;
        }

        //ImageIcon imageIcon = state2image.get(currentState);
        ImageData imageData = state2image.get(currentState);

        File tmpImageFile;
        BufferedImage image;

        if (imageData == null) {
            image = null;
            tmpImageFile = null;
        } else {
            image = imageData.getImage();
            tmpImageFile = imageData.getTmpImageFile();
        }

        if (image == null) {

            if (tmpImageFile == null) {

                File tmpDotFile; // keep null if you want a temp one

                try {
                    tmpImageFile = createTempFile(".jpg");
                    tmpDotFile = createTempFile(".dot");
                } catch (IOException e) {
                    e.printStackTrace();
                    return;
                }

//            DotHelper.USE_DUMMY_FOR_CLUSTER_CLUSTER = checkBoxDDummuEdgeEdge.isSelected();
//            DotHelper.USE_ENGINE = (String)comboBoxEngine.getSelectedItem();
//            DotHelper.USE_DUMMY_FOR_NODE_CLUSTER = checkBoxDummyNodes.isSelected();

                final DotConfiguration configuration = getCurrentDotConfiguration();
                SMDot.createImageFile(configuration, sm, tmpImageFile, tmpDotFile);

            }

            //BufferedImage image;
            try {
                image = ImageIO.read(tmpImageFile);
            } catch (IOException e) {
                e.printStackTrace();
                return;
            }

            imageData = new ImageData(tmpImageFile, image);

            state2image.put(currentState, imageData);
        }

        updateImageComponent(image);


        lastDisplayedState = currentState;
    }

    private void updateImageComponent(BufferedImage image) {
        imageComponent.setImage(image);
        openImageButton.setEnabled(image != null);
    }

    private File createTempFile(String postFix) throws IOException {
        File dir = new File(System.getProperty("java.io.tmpdir"));

        dir = new File(dir, "sm_debugger");

        String subDir = sm.getName();
        dir = new File(dir, subDir);
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();

        File tempFile = File.createTempFile("sm_debugger_show_image", postFix, dir);
        tempFile.deleteOnExit();
        return tempFile;
    }

    private DotConfiguration getCurrentDotConfiguration() {
        return (DotConfiguration)comboBoxDotConfiguration.getSelectedItem();
    }

    private void setUpInitButton() {
        buttonInit.addActionListener(e -> {

            Runnable command = () -> {
                if (sm == null) {
                    return;
                }

                sm.init();
            };

            runCommandSepThread(command);

        });
    }

    /**
     * Invalidate images cache and redraw
     */
    private void invalidateAndRedrawImageIfNeed() {

        boolean draw = imageComponent.getImage() != null;

        lastDisplayedState = "-1";
        state2image.clear();
        updateImageComponent(null);

        if (draw) {
            updateMachineImageFrame();
        }

    }

    private void openImageInExternalViewer() {
        ImageData imageData = state2image.get(lastDisplayedState);

        if (imageData != null) {
            File file = imageData.getTmpImageFile();

            try {
                Desktop.getDesktop().open(file);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    private void setUpConfigControls() {
    }


    private static JComponent createLogPane(JTextPane textPane) {
        JScrollPane scrollPane = createScrollPane(textPane);
        return scrollPane;
    }


    private static JTextPane createTextPane(DefaultStyledDocument doc) {
        JTextPane textPane = new JTextPane(doc) {
            /* The code is stolen from Internet - http://forum.java.sun.com/thread.jsp?forum=57&thread=122354
     Its purpose is to disable line wrapping */
            @Override
            public boolean getScrollableTracksViewportWidth() {
                return getSize().width < getParent().getSize().width;
            }

            @Override
            public void setSize(Dimension d) {
                if (d.width < getParent().getSize().width) {
                    d.width = getParent().getSize().width;
                }
                super.setSize(d);
            }
        };
        textPane.setEditable(false);
        //textPane.setPreferredSize(new Dimension(600, 300));
        return textPane;
    }

    private static JScrollPane createScrollPane(JComponent component) {
        JScrollPane scrollPane =
            new JScrollPane(component, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                            JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        /* Keep the scroll bar at the bottom. However, do not bring it to
           the bottom if it is not there currently. */
        scrollPane.getVerticalScrollBar().getModel().addChangeListener
            (new ChangeListener() {
                private int maximum;

                @Override
                public void stateChanged(ChangeEvent e) {
                    BoundedRangeModel model = (BoundedRangeModel)e.getSource();
                    int newMaximum = model.getMaximum();
                    int extent = model.getExtent();
                    if (model.getValue() >= maximum - extent) {
                        model.setValue(newMaximum - extent);
                    }
                    maximum = newMaximum;
                }
            });
        return scrollPane;
    }


    JPanel getMainPanel() {
        return mainPanel;
    }

    private void createStyles() {

        Style commonFont = textPane.addStyle(null, null);
        StyleConstants.setFontFamily(commonFont, "Monospaced");

        logEventStyle = textPane.addStyle(null, commonFont);
        StyleConstants.setForeground(logEventStyle, new Color(0, 128, 128));
//        StyleConstants.setBold(arrowStyle, true);


        arrowStyle = textPane.addStyle(null, commonFont);
        StyleConstants.setForeground(arrowStyle, new Color(0, 0, 0));
//        StyleConstants.setBold(arrowStyle, true);

        sourceStateStyle = textPane.addStyle(null, commonFont);
        StyleConstants.setForeground(sourceStateStyle, new Color(128, 0, 0));
        StyleConstants.setBold(sourceStateStyle, true);

        triggerStyle = textPane.addStyle(null, commonFont);
        StyleConstants.setForeground(arrowStyle, new Color(0, 0, 255));
        StyleConstants.setBold(triggerStyle, true);

        targetStateStyle = textPane.addStyle(null, commonFont);
        StyleConstants.setForeground(targetStateStyle, new Color(128, 0, 0));
        StyleConstants.setBold(targetStateStyle, true);

        userMsgStyle = null;


    }

    private void setUpPauseButtons() {

        isPaused = false;
        nextButton.setEnabled(false);


        pauseButton.addActionListener(e -> {

            pauseLock.lock();
            try {
                if (isPaused) {
                    isPaused = false;
                    nextPressed = 0;
                    nextButton.setEnabled(false);
                    pauseButton.setText("Pause");
                } else {
                    isPaused = true;
                    nextPressed = 0;
                    pauseButton.setText("Continue");
                    nextButton.setEnabled(true);
                }
                pauseCondition.signalAll();
            } finally {
                pauseLock.unlock();
            }
        });

        nextButton.addActionListener(e -> {

            pauseLock.lock();
            try {
                ++nextPressed;
                pauseCondition.signalAll();
            } finally {
                pauseLock.unlock();
            }

        });

    }

    private void setUpEventsQueue() {

        listEventsQueue.setCellRenderer((list, value, index, isSelected, cellHasFocus) -> {

            String s = (String)value;
            return new JButton(s);
        });

    }


    private static String addEOLIfNeed(String msg) {

        if (!msg.endsWith("\n")) {
            msg += "\n";
        }

        return msg;

    }

    private void writeToDoc(String msg, Style style) {

        while (doc.getLength() > 500000) {
            try {
                int toRemove = 250000;
                doc.remove(0, toRemove);
            } catch (BadLocationException ignore) {
            }
        }

        int insertPost = doc.getEndPosition().getOffset() - 1;
        try {
            doc.insertString(insertPost, msg, style);
        } catch (BadLocationException e) {
            e.printStackTrace();
        }
    }

    private void writeEOL() {
        writeToDoc("\n", null);
    }


    private void unsafeWriteBeginEvent(SMLogEvent event) {

        String eventSS;

        if (event != null) {

            if (event.isEndOfSequence()) {
                --indentLevel;
            }

            int indent = indentLevel;

            if (indent > MAX_INDENT) {
                indent = MAX_INDENT;
            } else if (indent < 0) {
                indent = 0;
            }

            indent = indent * INDENT_WIDTH;

            String indentS;

            indentS = TextUtil.space(indent);


            String eventS = TextUtil.rightPadLeftCut("" + event, MAX_LOG_EVENT_WIDTH - indent);

            eventSS = indentS + "[" + eventS + "]: ";

            if (event.isBeginOfSequence()) {
                ++indentLevel;
            }

        } else {
            eventSS = "";
        }

        writeToDoc(TextUtil.rightPadLeftCut(eventSS, MAX_INDENT * INDENT_WIDTH + 1 + MAX_LOG_EVENT_WIDTH + 3),
                   logEventStyle);
    }

    private void writeEventInfo(@Nullable SMLogEvent event,
                                SMStateVertex source,
                                SMBaseTrigger trigger,
                                @Nullable SMGuard guard,
                                SMStateVertex target,
                                @Nullable String branchName) {

        checkInitialization();

        unsafeWriteBeginEvent(event);

        if (source != null) {
            String sn = SMLogHelper.getSourceName(source);
            writeToDoc(TextUtil.rightPadLeftCut(sn, sourceStateFieldWidth),
                       sourceStateStyle);
            writeToDoc(ARROW_LEFT, arrowStyle);
        } else {
            writeToDoc(TextUtil.space(sourceStateFieldWidth), sourceStateStyle);
            writeToDoc(TextUtil.space(ARROW_LEFT.length()), arrowStyle);
        }

        String triggerS = "";
        if (trigger != null) {
            triggerS += trigger.getName();
        }

        if (guard != null) {
            String gn = guard.getName();
            if (gn != null) {
                triggerS += "[" + gn + "]";
            }
        }

        if (branchName != null) {
            triggerS += branchName;
        }


        writeToDoc(TextUtil.rightPadLeftCut(triggerS, triggerFieldWidth),
                   triggerStyle);

        if (target != null) {

            writeToDoc(ARROW_RIGHT, arrowStyle);
            String tn = SMLogHelper.getTargetName(target);
            writeToDoc(TextUtil.rightPadLeftCut("" + tn, targetStateFieldWidth), targetStateStyle);

        } else {
            writeToDoc(TextUtil.space(ARROW_RIGHT.length()), arrowStyle);
            writeToDoc(TextUtil.space(targetStateFieldWidth), targetStateStyle);
        }

        writeEOL();

    }

    private static void checkNotGUIThread() {

        if (SwingUtilities.isEventDispatchThread()) {
            throw new RuntimeException("Must not called from GUI thread");
        }

    }

    private void waitOnPause() {

        checkNotGUIThread();

        pauseLock.lock();
        try {


            while (isPaused && nextPressed <= 0) {
                try {
                    pauseCondition.await();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

            if (isPaused) {
                --nextPressed;
            }


        } finally {
            pauseLock.unlock();
        }

    }

    //==================================================================================
    // on gui thread implementation of logger interface

    private void guiDoAttach(SMLogEvent logEvent, StateMachine sm) {
        this.sm = sm;
//        jSMNameTextField.setText(sm.getName());

        checkInitialization();

        unsafeWriteBeginEvent(logEvent);
        writeEOL();

        // un comment this if you don't want to show SM image at first attach  
        updateMachineImageFrame();

        updateCurrentState();
    }

    private void guiDoLogEvent(SMLogEvent event,
                               SMStateVertex source,
                               SMBaseTrigger trigger,
                               SMStateVertex target) {

        writeEventInfo(event, source, trigger, null, target, null);

        updateCurrentState();

        switch (event) {
            case MACHINE_GOT_TRIGGER: {
                updateEventsQueue();
                break;
            }

            case MACHINE_START_PROCESSING_TRIGGER: {
                updateEventsQueue();
                break;
            }

            default: {
            }
        }
    }


    private void guiDoLogQueryingTransitionGuard(SMLogEvent logEvent,
                                                 SMStateVertex source,
                                                 SMBaseTrigger trigger,
                                                 SMGuard guard,
                                                 SMStateVertex[] targets) {
        checkInitialization();

        writeEventInfo(logEvent, source, trigger, guard, null, null);

        int targetIndex = 0;
        for (SMStateVertex target : targets) {
            String branchName = null;
            if (guard != null) {
                branchName = guard.getBranchName(targets.length, targetIndex);
            } else if (targets.length == 1) {
                branchName = "unconditional";
            }
            writeEventInfo(null, null, null, null, target, branchName);
            ++targetIndex;
        }

    }

    private void guiDoEndLogQueryingTransitionGuard(SMLogEvent logEvent,
                                                    SMStateVertex source,
                                                    SMBaseTrigger trigger,
                                                    SMGuard guard,
                                                    SMStateVertex selectedTarget) {

        checkInitialization();

        writeEventInfo(logEvent, source, trigger, guard, selectedTarget, null);
    }

    private void guiDoBeginTransitionsSegments(SMLogEvent logEvent, List<? extends SMTransitionSegment> segments) {
        checkInitialization();

        unsafeWriteBeginEvent(logEvent);
        writeEOL();

        for (SMTransitionSegment segment : segments) {
            writeEventInfo(null, segment.getSource(), segment.getTrigger(), null, segment.getTarget(), null);
        }

    }

    private void guiDoDetach(SMLogEvent logEvent) {
        unsafeWriteBeginEvent(logEvent);
        writeEOL();

//        if (myEventsSendingThread != null) {
//
//            myEventsSendingQueue.clear();
//            try {
//                myEventsSendingQueue.put(myDieTrigger);
//            } catch (InterruptedException e) {
//                e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
//            }
//
//            try {
//                myEventsSendingThread.join();
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//
//            myEventsSendingThread = null;
//            myEventsSendingQueue = null;
//        }

//        jSMNameTextField.setText("");
        sm = null;
    }


    @Override
    public void attach(final SMLogEvent logEvent, final StateMachine sm) {
        doSafe(
            () -> guiDoAttach(logEvent, sm));

    }


    @Override
    public void detach(final SMLogEvent logEvent, StateMachine sm) {

        doSafe(
            () -> guiDoDetach(logEvent));
    }


    @Override
    public void logEvent(StateMachine sm,
                         final SMLogEvent event,
                         final SMStateVertex source,
                         final SMBaseTrigger trigger,
                         final SMStateVertex target) {

        checkNotGUIThread();

        doSafe(
            () -> guiDoLogEvent(event, source, trigger, target));

        waitOnPause();

    }


    @Override
    public void logQueryingTransitionGuard(final SMLogEvent logEvent,
                                           StateMachine sm,
                                           final SMStateVertex source,
                                           final SMBaseTrigger trigger,
                                           final SMGuard guard,
                                           final SMStateVertex[] candidateTargets) {
        doSafe(
            () -> guiDoLogQueryingTransitionGuard(logEvent, source, trigger, guard, candidateTargets));

        waitOnPause();

    }

    @Override
    public void logEndQueryingTransitionGuard(final SMLogEvent logEvent,
                                              StateMachine sm,
                                              final SMStateVertex source,
                                              final SMBaseTrigger trigger,
                                              @Nullable final SMGuard guard,
                                              @Nullable final SMStateVertex selectedTarget) {
        doSafe(
            () -> guiDoEndLogQueryingTransitionGuard(logEvent, source, trigger, guard, selectedTarget));

        waitOnPause();
    }


    @Override
    public void beginTransitionsSegments(final SMLogEvent logEvent, StateMachine sm,
                                         final List<? extends SMTransitionSegment> segments) {
        doSafe(
            () -> guiDoBeginTransitionsSegments(logEvent, segments));

        waitOnPause();


    }

    @Override
    public void logUserMsg(final SMLogEvent logEvent, StateMachine sm, final String msg) {
        doSafe(
            () -> {
                unsafeWriteBeginEvent(logEvent);
                writeToDoc(addEOLIfNeed(msg), userMsgStyle);

            });
    }

    private void doSafe(Runnable r) {

        synchronized (commandQueue) {
            commandQueue.add(r);
        }


        SwingUtilities.invokeLater(() -> {

            while (true) {
                Runnable rr;

                synchronized (commandQueue) {
                    if (commandQueue.isEmpty()) {
                        return;
                    }

                    rr = commandQueue.remove(0);
                }

                rr.run();
            }
        });
    }

    private void checkInitialization() {

        if (initialized) {
            return;
        }

        if (!sm.debugIsMachineDefinitionEnded()) {
            return;
        }

        // ok now you can do initialization
        setEventsButtons();

        computeFieldsWidth();


        initialized = true;
    }

    private static int computeMaxLength(String[] ss) {

        int maxLength = 0;

        for (String s : ss) {
            if (s.length() > maxLength) {
                maxLength = s.length();
            }
        }

        return maxLength;

    }

    private void computeFieldsWidth() {

        String[] triggers = sm.debugGetAllDefinedTriggersNames();

        triggerFieldWidth = computeMaxLength(triggers);

        String[] states = sm.debugGetAllStates();

        sourceStateFieldWidth = computeMaxLength(states);
        targetStateFieldWidth = sourceStateFieldWidth;
    }


    private void updateCurrentState() {

        String currentStateStr = getCurrentStateString();

        currentStateTextField.setText(currentStateStr);

        if (imageComponent.getImage() != null) {
            updateMachineImageFrame();
        }

    }

    private String getCurrentStateString() {
        SMStatePathTree currentStateTree = sm.getLastKnownCurrentStatePathTree();

        String currentStateStr;

        if (currentStateTree != null) {
            currentStateStr = currentStateTree.toString();
        } else {
            currentStateStr = "?";
        }
        return currentStateStr;
    }

    private void updateEventsQueue() {

        String[] events = sm.debugGetTriggerQueue();

        eventsQueueListModel.removeAllElements();

        for (String s : events) {
            eventsQueueListModel.add(0, s);
        }

        // System.out.println("Added " + events.length + " to queue");


    }


    private void setEventsButtons() {

        // todo: remove prev buttons

        SMUTrigger[] events = sm.debugGetAllDefinedTriggers();

        //panelEventsLayout.setRows(events.length);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;
        for (final SMUTrigger event : events) {

            String name = event.getName();

            JButton button = new JButton(name);
            button.setMargin(new Insets(3, 3, 3, 3));

            button.addActionListener(
                e -> sendMyEvent(event));
            buttonPanel.add(button, gbc);
            gbc.gridy++;


        }
        gbc.weighty = 1;
        gbc.weightx = 1;
        buttonPanel.add(new JPanel(new BorderLayout()), gbc);

        eventsPane.setViewportView(buttonPanel);
        eventsPane.revalidate();
        eventsPane.repaint();

//        mainPanel.validate();
//        mainPanel.setSize(mainPanel.getPreferredSize());
    }

    private void sendMyEvent(final SMUTrigger event) {

        Runnable command = () -> sm.handleTrigger(event);

        runCommandSepThread(command);
    }

    private static void runCommandSepThread(Runnable command) {
        // i'm using new thread for each event because may i'm blocking my self in pause mode

        Thread myEventsSendingThread = new Thread(command);

        myEventsSendingThread.setDaemon(true);
        myEventsSendingThread.start();
    }

    private void attack() {


        int nThreads = 30;
        final int nEventsPerThread = 50;
        final SMUTrigger[] events = sm.debugGetAllDefinedTriggers();
        final Random random = new Random();

        for (int i = 0; i < nThreads; ++i) {
            Runnable command = () -> {

                int tillNow = 0;

                try {
                    while (true) {

                        int nEvents = random.nextInt(5) + 1;
                        for (int j = 0; j < nEvents; ++j) {
                            if (++tillNow > nEventsPerThread) {
                                return; // end run()
                            }

                            int eI = random.nextInt(events.length);
                            SMUTrigger trigger = events[eI];
                            sm.handleTrigger(trigger);
                        }

                        try {
                            Thread.sleep(random.nextInt(5));
                        } catch (InterruptedException ignore) {
                        }
                    }
                } finally {
                    //noinspection UseOfSystemOutOrSystemErr
                    System.out.println(
                        "Attack " + Thread.currentThread().getName() + " finished, events=" + tillNow);
                }
            };

            runCommandSepThread(command);
        }

    }
}
