package wf.state_machine.smlogger.guilogger.iforms;

import javax.swing.*;
import java.awt.image.BufferedImage;

public class SMImageIcon extends JLabel {

    private BufferedImage image;

    public void setImage(BufferedImage image) {
        setIcon(image == null ? null : new ImageIcon(image));
        this.image = image;
    }

    public BufferedImage getImage() {
        return image;
    }


//    public void paint(Graphics g) {
//        super.paint(g);    //To change body of overridden methods use File | Settings | File Templates.
//
//        if (image == null) {
//            return;
//        }
//
//        Graphics2D g2 = (Graphics2D)g;
//
//        int w = getWidth();
//        int h = getHeight();
//
//        int iw = image.getWidth();
//        int ih = image.getHeight();
//
//        if (iw <= w && ih <= h) {
//            w = iw;
//            h = ih;
//        }
//
//        g2.drawImage(image, 0, 0, w, h, this);
//
//    }
}
