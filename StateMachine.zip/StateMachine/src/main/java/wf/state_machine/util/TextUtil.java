package wf.state_machine.util;

// for debug only

import java.util.Arrays;

public class TextUtil {
    private static final int MAX_SPACES = 512;
    private static final int TAB_SIZE = 2;
    private static final String SPACES;

    private TextUtil() {
    }

    static {
        char[] cs = new char[MAX_SPACES];
        Arrays.fill(cs, ' ');
        SPACES = new String(cs);
        Arrays.fill(cs, '\t');
    }

    public static String space(int n) {
        return SPACES.substring(0, n);
    }

    public static String tab(int n) {
        return space(n * TAB_SIZE);
    }

    /**
     * Pad and cut
     *
     * @param s
     * @param length
     */
    public static String rightPadLeftCut(String s, int length) {
        return (s + space(length)).substring(0, length);
    }

    public static String leftCut(String s, int length) {

        if (length > s.length()) {
            return s;
        } else {
            return s.substring(0, length);
        }
    }


}
