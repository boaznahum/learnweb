package wf.state_machine.tests.doc_examples;

import wf.state_machine.SMCompositeState;
import wf.state_machine.SMState;
import wf.state_machine.SMUTrigger;
import wf.state_machine.tests.infra.SMAbstractTest;
import wf.state_machine.tests.infra.SMExampleRunner;

import java.util.concurrent.TimeUnit;

/**
 * This example demonstrate a timer event.
 *
 * An transition event (TimeOut) is generated
 *
 */
public class ExampleScheduledTrigger extends SMAbstractTest {

    private static final SMUTrigger eS = SMUTrigger.create("Scan");
    private static final SMUTrigger eX = SMUTrigger.create("Stop");
    private static final SMUTrigger eD = SMUTrigger.create("Done");
    private static final SMUTrigger eT = SMUTrigger.create("TimeOut");

    private ExampleScheduledTrigger() {
        super("Auto Time Out");

        sm.defineTriggers(eS, eX, eD, eT);

        SMCompositeState tl = sm.getTopLevel();

        SMState sIdle = tl.addSimpleState("Idle");
        SMState scanning = tl.addSimpleState("Scanning");
        SMState stopping = tl.addSimpleState("Stopping");
        SMState sDone = tl.addSimpleState("Done");
        SMState sTimeOut = tl.addSimpleState("TimeOut");

        tl.addInitialState().addTransition(sIdle);

        sIdle.addUTransition(eS, scanning);

        scanning.addUTransition(eD, sDone);
        scanning.addUTransition(eX, stopping);
        scanning.addUTransition(eT, sTimeOut);

        stopping.addUTransition(eD, sIdle);


        //scanning.addEntryHandler(new SMStateHandler() {
        //    @Override
        //    public void handle(SMGlobalContext eventContext, SMStateHandlerContext info) {
        //        eventContext.sm().scheduleTrigger(eT, 5, TimeUnit.SECONDS);
        //    }
        //});


        //final AtomicReference<SMScheduledFutureTrigger> fRef = new AtomicReference<>();
        //scanning.addEntryHandler(new SMStateHandler() {
        //    @Override
        //    public void handle(SMGlobalContext eventContext, SMStateHandlerContext info) {
        //        fRef.set(eventContext.sm().scheduleTrigger(eT, 5, TimeUnit.SECONDS));
        //    }
        //});
        //
        //scanning.addExitHandler(new SMStateHandler() {
        //    @Override
        //    public void handle(SMGlobalContext eventContext, SMStateHandlerContext info) {
        //        SMScheduledFutureTrigger future = fRef.get();
        //        if (future != null) {
        //            future.cancel(true);
        //        }
        //    }
        //});

        /**
         * THis demonstrate how a long entry handler before canceling a trigger
         * cause a bug:
         * If during this handler the trigger is submitted,
         * only canceling the submit-operation is not enough, we must also cancel
         * the trigger itself.
         */
        //preparing.addExitHandler(new SMStateHandler() {
        //    @Override
        //    public void handle(SMGlobalContext eventContext, SMStateHandlerContext info) {
        //        try {
        //            eventContext.logUserMsg("Sleeping...");
        //            TimeUnit.SECONDS.sleep(6);
        //        } catch (InterruptedException e) {
        //            throw new RuntimeException(e);
        //        }
        //    }
        //});


        scanning.scheduleTriggerOnEntry(eT, 2, TimeUnit.SECONDS);
    }


    public static void main(String[] args) {
        SMAbstractTest test = new ExampleScheduledTrigger();
        SMExampleRunner.runGUI(test);

    }
}


