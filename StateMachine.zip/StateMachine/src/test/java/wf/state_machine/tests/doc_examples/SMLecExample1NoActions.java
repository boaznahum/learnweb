package wf.state_machine.tests.doc_examples;

import wf.state_machine.SMCompositeState;
import wf.state_machine.SMState;
import wf.state_machine.SMUTrigger;
import wf.state_machine.StateMachine;
import wf.state_machine.smlogger.guilogger.SMGUIDebugger;

/**
 * @author Boaz Nahum
 */

public class SMLecExample1NoActions {

    private SMLecExample1NoActions() {
    }

    public static void main(String[] args) {


        // Create the state machine
        StateMachine sm = StateMachine.createStateMachine("Example-1");

        // Create and define the legal set of triggers
        SMUTrigger e1 = SMUTrigger.create("E1");
        SMUTrigger e2 = SMUTrigger.create("E2");
        sm.defineTriggers(e1, e2);

        // Get top level state, for which we are adding states.
        SMCompositeState tl = sm.getTopLevel();

        // Add states
        SMState s1 = tl.addSimpleState("S1");
        SMState s2 = tl.addSimpleState("S2");

        // set s1 to be initial state in top level state
        tl.addInitialState(s1);

        // Add transitions
        s1.addUTransition(e1, s2);
        s2.addUTransition(e2, s1);
        s1.addUTransition(e2, s1);
        s2.addUTransition(e1, s2);

        // Attach the sm to GUI debugger so we can play with
        SMGUIDebugger debugger = SMGUIDebugger.createMM();
        sm.attachTo(debugger);


    }
}
