package wf.state_machine.tests.examples;

import wf.state_machine.SMCompositeState;
import wf.state_machine.SMConcurrentState;
import wf.state_machine.SMGuaranteed;
import wf.state_machine.SMGuard;
import wf.state_machine.SMNaryGuard;
import wf.state_machine.SMState;
import wf.state_machine.SMStateVertex;
import wf.state_machine.SMTransition;
import wf.state_machine.SMTransitionGuardContext;
import wf.state_machine.SMTrigger;
import wf.state_machine.SMUTrigger;
import wf.state_machine.tests.infra.SMAbstractTest;
import wf.state_machine.tests.infra.SMExampleRunner;

/**
 * @author Boaz Nahum
 * @version x.5
 */

public class Devices extends SMAbstractTest {

    private static final String FAILURES = "failures";

    //public static class TheDevices {
    //    //private boolean opXFailed;
    //    //
    //    //public boolean isOpXFailed() {
    //    //    return opXFailed;
    //    //}
    //    //
    //    //public void setOpXFailed(boolean opXFailed) {
    //    //    this.opXFailed = opXFailed;
    //    //}
    //}

    private Devices() {
        super("Devices");

        int nDevices = 3;

        //final TheDevices theDevices = new TheDevices();
        //theDevices.setOpXFailed(false);

        SMUTrigger doX = SMUTrigger.create("DoX");
        SMUTrigger reset = SMUTrigger.create("Reset");
        SMUTrigger[] devicesOKTriggers = buildOkTriggers(nDevices);
        SMUTrigger[] devicesFailedTriggers = buildFailedTriggers(nDevices);

        sm.defineTriggers(doX, reset);
        sm.defineTriggers(devicesOKTriggers);
        sm.defineTriggers(devicesFailedTriggers);

        SMCompositeState topLevel = sm.getTopLevel();

        SMState idle = topLevel.addSimpleState("Idle");

        idle.onEntryDo(i -> i.getGlobalContext().clearUserData());

        //idle.addEntryHandler(new SMStateHandler() {
        //    @Override
        //    public void handle(SMGlobalContext eventContext, SMStateHandlerContext info) {
        //        theDevices.setOpXFailed(false);
        //    }
        //});

        final SMState sXOk = topLevel.addSimpleState("XOk");
        final SMState sXFailed = topLevel.addSimpleState("XFailed");
        SMConcurrentState sDoingX = topLevel.addConcurrentState("DoingX");
        SMStateVertex sDoingXJoin = sDoingX.addJoin();
        SMStateVertex sDoingFork = sDoingX.addFork();

        topLevel.addInitialState().addTransition(idle);

        idle.addUTransition(doX, sDoingFork);

        final SMGuard guard = new SMNaryGuard() {

            @Override
            public String getName() {
                return "final guard";
            }

            @SMGuaranteed
            @Override
            public int select(SMTransitionGuardContext info) {

                boolean hasFailures = info.getGlobalContext().getUserData().isTrue(FAILURES);

                //boolean hasFailures = theDevices.isOpXFailed()

                if (hasFailures) {
                    return info.resolve(sXFailed);
                } else {
                    return info.resolve(sXOk);
                }
            }
        };

        sDoingXJoin.addTransition(guard, sXOk, sXFailed);

        buildDevicesDoingStates(
            sDoingX,
                sDoingFork,
                sDoingXJoin,
                devicesOKTriggers,
                devicesFailedTriggers
        );

       //idle.addTransitionsFromMany(reset, null, sDoingX, sXOk, sXFailed);
       topLevel.addTransitionFromAllSubStates(reset, null, idle);

    }

    private void buildDevicesDoingStates(SMConcurrentState sDoingX,
                                         SMStateVertex fork,
                                         SMStateVertex join,
                                         SMTrigger[] devicesOKTriggers, SMTrigger[] devicesFailedTriggers) {

        int n = devicesOKTriggers.length;

        for(int i = 0; i < n; ++i) {

            int id = i + 1;

            SMCompositeState doingContainer = sDoingX.addCompositeState("P" + id);

            SMState doingX = doingContainer.addSimpleState("Doing" + id);

            fork.addTransition(doingX);

            doingX.addUTransition(devicesOKTriggers[i], join);
            SMTransition t =  doingX.addUTransition(devicesFailedTriggers[i], join);
            t.onDo((info) -> info.getGlobalContext().getUserData().setTrue(FAILURES));
        }
    }

    private SMUTrigger[] buildOkTriggers(int nDevices) {
        SMUTrigger[] triggers = new SMUTrigger[nDevices];

        for(int i = 0; i < nDevices; ++i) {
            int id = i + 1;
            triggers[i] = SMUTrigger.create("" + id + "OK");
        }

        return triggers;

    }

    private SMUTrigger[] buildFailedTriggers(int nDevices) {

        SMUTrigger[] triggers = new SMUTrigger[nDevices];

        for (int i = 0; i < nDevices; ++i) {
            int id = i + 1;
            triggers[i] = SMUTrigger.create("" + id + "Failed");
        }

        return triggers;
    }

    public static void main(String[] args) {
        Devices test = new Devices();

        SMExampleRunner.runGUI(test);

        
    }



}
