package wf.state_machine.tests.examples;

import wf.state_machine.*;
import wf.state_machine.tests.infra.SMAbstractTest;
import wf.state_machine.tests.infra.SMExampleRunner;
import wf.state_machine.tests.infra.SMTestsCommonTriggers;

import static wf.state_machine.tests.infra.SMTestsCommonTriggers.*;

public class Example0 extends SMAbstractTest {


    //private SMTrigger e1 = new SMSimpleTrigger("E1");
    //private SMTrigger e2 = new SMSimpleTrigger("E2");

    public Example0() {
        super("Example0");
        SMTransition t;


        sm.defineTriggers(SMTestsCommonTriggers.class);

        SMCompositeState tl = sm.getTopLevel();

        final SMState s1 = tl.addSimpleState("S1");
        addStateHandlers(s1, SMTestsCommonTriggers.values());
        final SMState s2 = tl.addSimpleState("S2");
        addStateHandlers(s2, SMTestsCommonTriggers.values());
        t = tl.addInitialState().addTransition(s1);
        addTranHandlers(t);


        SMTransition t1_2 = s1.addUTransition(E1, s2);
        addTranHandlers(t1_2);
        SMTransition t2_1 = s2.addUTransition(E2, s1);
        addTranHandlers(t2_1);
        t = s1.addUTransition(E2, s1);
        addTranHandlers(t);
        t = s2.addUTransition(E1, s2);
        addTranHandlers(t);

        // for testing local events                     s
        t1_2.onDo((info) -> {
            s1.addToLocalEventQueue(L1);
            s2.addToLocalEventQueue(L2);
        }, null);

        // for testing local events
        t2_1.onDo((info) -> {
            s1.addToLocalEventQueue(L3);
            s2.addToLocalEventQueue(L4);
        }, null);
    }

    public static void main(String[] args) {
        final Example0 test = new Example0();

        SMExampleRunner.runGUI(test);
        //SMExampleRunner.run(test, SMExampleLoggerType.NONE, true, CommonTriggers.values());
    }
}

