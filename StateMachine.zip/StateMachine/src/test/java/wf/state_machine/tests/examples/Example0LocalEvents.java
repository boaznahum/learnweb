package wf.state_machine.tests.examples;

import wf.state_machine.SMCompositeState;
import wf.state_machine.SMState;
import wf.state_machine.SMTransition;
import wf.state_machine.SMTransitionHandler;
import wf.state_machine.tests.infra.SMAbstractTest;
import wf.state_machine.tests.infra.SMExampleRunner;
import wf.state_machine.tests.infra.SMTestsCommonTriggers;

import static wf.state_machine.tests.infra.SMTestsCommonTriggers.E1;
import static wf.state_machine.tests.infra.SMTestsCommonTriggers.E2;
import static wf.state_machine.tests.infra.SMTestsCommonTriggers.L1;
import static wf.state_machine.tests.infra.SMTestsCommonTriggers.L2;


/**
 *  --------            ------                ------               -------
 *  | SL1  |<----L1---->| S1 |---E1/addL12--->| S2 |<-------L2---->| SL2 |
 *  |      |            |    |<---E2/addL12---|    |               |     |
 *  --------            ------                ------               -------
 *
 * Action addL12=
 * -- Add trigger L1,L2 to local state queue of S1 and S2, respectively
 *    So when we move from S1->S2 we also move to SL2 because L2 is in queue of S2
 *    When we move back to S2 and then to S1 then we also move to SL1 because L1 is in queue of S1
 */
public class Example0LocalEvents extends SMAbstractTest {


    //private SMTrigger e1 = new SMSimpleTrigger("E1");
    //private SMTrigger e2 = new SMSimpleTrigger("E2");

    public Example0LocalEvents() {
        super("Example0LocalEvents");


        sm.defineTriggers(SMTestsCommonTriggers.class);

        SMCompositeState tl = sm.getTopLevel();

        final SMState sl1 = tl.addSimpleState("SL1");
        addStateHandlers(sl1);

        final SMState s1 = tl.addSimpleState("S1");
        addStateHandlers(s1);
        final SMState s2 = tl.addSimpleState("S2");
        addStateHandlers(s2);

        final SMState sl2 = tl.addSimpleState("SL2");
        addStateHandlers(sl2);


        tl.addInitialState(s1);

        sl1.addUTransition(L1, s1);
        s1.addUTransition(L1, sl1);

        SMTransition t1_2 = s1.addUTransition(E1, s2);
        SMTransition t2_1 = s2.addUTransition(E2, s1);

        sl2.addUTransition(L2, s2);
        s2.addUTransition(L2, sl2);

        SMTransitionHandler addL12Action = (info) -> {
            s1.addToLocalEventQueue(L1);
            s2.addToLocalEventQueue(L2);
        };

        t1_2.onDo(addL12Action);

        // for testing local events
        t2_1.onDo(addL12Action);
    }

    public static void main(String[] args) {
        final Example0LocalEvents test = new Example0LocalEvents();

        SMExampleRunner.runGUI(test);
        //SMExampleRunner.run(test, SMExampleLoggerType.NONE, true, CommonTriggers.values());
    }
}