package wf.state_machine.tests.examples;

import wf.state_machine.SMCompositeState;
import wf.state_machine.SMState;
import wf.state_machine.SMTransition;
import wf.state_machine.StateMachine;
import wf.state_machine.tests.infra.SMAbstractTest;
import wf.state_machine.tests.infra.SMExampleLoggerType;
import wf.state_machine.tests.infra.SMExampleRunner;
import wf.state_machine.tests.infra.SMTestsCommonTriggers;

import static wf.state_machine.tests.infra.SMTestsCommonTriggers.E1;
import static wf.state_machine.tests.infra.SMTestsCommonTriggers.E2;

public class Example0UserData extends SMAbstractTest {


    //private SMTrigger e1 = new SMSimpleTrigger("E1");
    //private SMTrigger e2 = new SMSimpleTrigger("E2");

    public Example0UserData() {
        super("Example0UserData");
        SMTransition t;


        sm.defineTriggers(SMTestsCommonTriggers.class);

        SMCompositeState tl = sm.getTopLevel();

        final SMState s1 = tl.addSimpleState("S1");
        addStateHandlers(s1, SMTestsCommonTriggers.values());
        final SMState s2 = tl.addSimpleState("S2");
        addStateHandlers(s2, SMTestsCommonTriggers.values());
        t = tl.addInitialState().addTransition(s1);
        addTranHandlers(t);


        SMTransition t1_2 = s1.addUTransition(E1, s2);
        addTranHandlers(t1_2);
        SMTransition t2_1 = s2.addUTransition(E2, s1);
        addTranHandlers(t2_1);
        t = s1.addUTransition(E2, s1);
        addTranHandlers(t);
        t = s2.addUTransition(E1, s2);
        addTranHandlers(t);


    }

    public static void main(String[] args) {
        final Example0UserData test = new Example0UserData();

        //SMExampleRunner.runGUI(test);
        SMExampleRunner.run(test, SMExampleLoggerType.GUI, false, null);

        StateMachine sm = test.getSM();

        sm.handleTrigger(E1, new Object() {
            @Override
            public String toString() {
                return "E1:data=1";
            }
        });


    }
}