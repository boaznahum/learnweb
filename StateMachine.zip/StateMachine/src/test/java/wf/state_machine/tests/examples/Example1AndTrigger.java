package wf.state_machine.tests.examples;

import wf.state_machine.SMCompositeState;
import wf.state_machine.SMState;
import wf.state_machine.SMTransition;
import wf.state_machine.SMUTrigger;
import wf.state_machine.outputers.SMDOM;
import wf.state_machine.outputers.dot.SMDot;
import wf.state_machine.tests.infra.SMAbstractTest;
import wf.state_machine.tests.infra.SMExampleRunner;

public class Example1AndTrigger extends SMAbstractTest {

    private SMState defineSx(SMCompositeState complex) {
        SMState s2 = complex.addSimpleState("SB");
        SMState s3 = complex.addSimpleState("SC");

        complex.addInitialState().addTransition(s2);

        return s3;
    }

    @SuppressWarnings({"EnumeratedConstantNamingConvention"})
    private enum MyEvents implements SMUTrigger {

        e1,
        e1x,
        e1y,
        e1z,
        e2,
        e3,
        eErr;

        @Override
        public String getName() {
            return super.name();
        }

    }


    Example1AndTrigger() {


        // define 'Events' world
        super("Example1AndTrigger");
        sm.defineTriggers(MyEvents.values());


        SMCompositeState tl = sm.getTopLevel();

        // define events
        tl.defineAndTrigger(MyEvents.e1,
                            MyEvents.e1x,
                                              MyEvents.e1y,
                                              MyEvents.e1z);

        // define states
        SMCompositeState s1 = tl.addCompositeState("S 1");
        SMCompositeState s2 = tl.addCompositeState("S 2");
        SMState s3 = tl.addSimpleState("S3");
        SMState sErr = tl.addSimpleState("Error");

        SMState s1_x = defineSx(s1);
        defineSx(s2);

        if (true) {
            tl.addInitialState().addTransition(s1_x);
        } else {
            tl.addInitialState().addTransition(s1);
        }

        // transitions
        s1.addUTransition(MyEvents.e1,
                          s3);

        s1.addTransition(MyEvents.e2,
                         getGuard(),
                         s2, s3);

        SMTransition t3 = s1.addTransition(MyEvents.e3,
                                           getGuard(0),
                                           s1, s2, s3);

        // twice
        addTranHandlers(t3);
        addTranHandlers(t3);


        tl.addTransitionFromAllSubStates(
            MyEvents.eErr,
            null, // no guard
            sErr);

        s2.addUTransition(
            MyEvents.e2,
            s2.getReturnPoint());


        // attachCondoleLogger();

        sm.init();

        SMDOM.write(null, "Example1.xml", sm);
//
        SMDot.createImageFile(null, sm,
                              "Example1.jpg", "Example1.dot");


    }


    public static void main(String[] args) {
        SMAbstractTest test = new Example1AndTrigger();
        SMExampleRunner.runGUI(test);
    }

}


