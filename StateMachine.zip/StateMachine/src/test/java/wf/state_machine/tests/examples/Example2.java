package wf.state_machine.tests.examples;

import wf.state_machine.*;
import wf.state_machine.tests.infra.SMAbstractTest;
import wf.state_machine.tests.infra.SMExampleRunner;

public class Example2 extends SMAbstractTest {

    private static final SMUTrigger e1 = SMUTrigger.create("E1");
    private static final SMUTrigger e2 = SMUTrigger.create("E2");
    private static final SMUTrigger e3 = SMUTrigger.create("E3");

    private static final SMUTrigger eI = SMUTrigger.create("eI");

    Example2() {
        super("Example2");
        SMTransition t;

        sm.defineTriggers(e1, e2, e3, eI);

        SMCompositeState tl = sm.getTopLevel();


        SMCompositeState s1 = tl.addCompositeState("S1");
        //      {// define "S1"
        SMState sa = s1.addSimpleState("SA");
        SMState sb = s1.addSimpleState("SB");

        SMStateVertex ins = s1.addInitialState("I");
        t = ins.addTransition(sb);
        addTranHandlers(t);

        t = sb.addUTransition(e1, sa);
        addTranHandlers(t);
        t = sb.addUTransition(e3, sb);
        addTranHandlers(t);

        addStateHandlers(sa, eI);
        addStateHandlers(sb, eI);
        //    }

        //t = tl.addInitialState("I").addTransition(s1);
        t = tl.addInitialState("I").addTransition(sb);
        addTranHandlers(t);

        SMState s2 = tl.addSimpleState("S2");

        SMCompositeState s3 = tl.addCompositeState("S3");
        SMState sx = s3.addSimpleState("SX x"); // make it initial state
        t = s3.addInitialState("I").addTransition(sx);
        addTranHandlers(t);


        t = s1.addUTransition(e2, s2);
        addTranHandlers(t);

        // to itself
        s1.addUTransition(eI, s1);


        t = s2.addUTransition(e2, sx);
        addTranHandlers(t);
        t = s2.addUTransition(e3, s3);
        addTranHandlers(t);

        // to itself
        s2.addUTransition(eI, s2);


        t = s3.addUTransition(e3, s1);
        addTranHandlers(t);

        // to itself
        s3.addUTransition(eI, s3);

        t = sx.addUTransition(e1, sx);
        addTranHandlers(t);

        // add handlers to state
        addStateHandlers(s1, eI);
        addStateHandlers(s2, eI);
        addStateHandlers(s3, eI);
        addStateHandlers(sx, eI);

        /*
        try
        {
            Thread.sleep(10 * 1000);
        }
        catch (Exception e)
        {
        }
        */

        //sm.init();
        //SMDOM.write(null, "Example1.xml", sm);
        //SMDot.createImageFile(null, sm,
        //                      "Example1.jpg", "Example1.dot");

//        SMDot.createImageFile(null, sm, "Example2.jpg", "Example2.dot");

/*
        handleEvent(e1);
        handleEvent(e2);
        handleEvent(eI);
        handleEvent(e2);
        handleEvent(eI);
        handleEvent(e3);
*/


    }

    public static void main(String[] args) {
        SMAbstractTest test = new Example2();
        SMExampleRunner.runGUI(test);

    }
}


