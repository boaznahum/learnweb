package wf.state_machine.tests.examples;

import wf.state_machine.*;
import wf.state_machine.tests.infra.SMAbstractTest;
import wf.state_machine.tests.infra.SMExampleRunner;

public class Example3 extends SMAbstractTest {

    private static final SMUTrigger e1 = SMUTrigger.create("E1");
    private static final SMUTrigger e2 = SMUTrigger.create("E2");
    private static final SMUTrigger e3 = SMUTrigger.create("E3");
    private static final SMUTrigger e4 = SMUTrigger.create("E4");

    Example3() {
        super("Example3");
        SMTransition t;

        sm.defineTriggers(e1, e2, e3, e4);

        SMCompositeState tl = sm.getTopLevel();

        SMCompositeState s1 = tl.addCompositeState("S1");
        t = tl.addInitialState().addTransition(s1);
        addTranHandlers(t);
        addStateHandlers(s1);

        SMState sa = s1.addSimpleState("SA");
        t = s1.addInitialState().addTransition(sa);
        addTranHandlers(t);
        addStateHandlers(sa);

        t = sa.addUTransition(e1, s1);
        addTranHandlers(t);
        t = s1.addUTransition(e2, s1);
        addTranHandlers(t);
        t = sa.addUTransition(e3, sa);
        addTranHandlers(t);
        t = s1.addUTransition(e4, sa);
        addTranHandlers(t);


//        sm.init();
//
//        SMDot.createImageFile(null, sm, "Example3.jpg", "Example3.dot");



//        handleEvent(e1);
//        handleEvent(e2);
//        handleEvent(e3);
//        handleEvent(e4);


    }


    public static void main(String[] args) {
        SMAbstractTest test = new Example3();
        SMExampleRunner.runGUI(test);

    }
}


