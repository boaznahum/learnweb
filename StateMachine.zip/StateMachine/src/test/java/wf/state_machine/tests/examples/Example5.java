package wf.state_machine.tests.examples;

import wf.state_machine.*;
import wf.state_machine.tests.infra.SMAbstractTest;
import wf.state_machine.tests.infra.SMExampleRunner;

public class Example5 extends SMAbstractTest {

    private static final SMUTrigger e1 = SMUTrigger.create("E1");
    private static final SMUTrigger e2 = SMUTrigger.create("E2");
    private static final SMUTrigger e3 = SMUTrigger.create("E3");
    private static final SMUTrigger eX = SMUTrigger.create("EX");
    private static final SMUTrigger eY = SMUTrigger.create("EY");

     Example5() {
        super("Example5");
        SMTransition t;

        sm.defineTriggers(e1, e2, eX, eY, e3);

        SMCompositeState tl = sm.getTopLevel();

        SMState s0 = tl.addSimpleState("S0");
        addStateHandlers(s0);

        SMState s1 = tl.addSimpleState("S1");
        t = tl.addInitialState().addTransition(s1);
        addTranHandlers(t);

        addStateHandlers(s1);


        SMCompositeState s2 = tl.addCompositeState("S2");
        addStateHandlers(s2);

        SMState sa = s2.addSimpleState("SA");
        t = s2.addInitialState().addTransition(sa);
        addTranHandlers(t);

        addStateHandlers(sa);

        SMState sFinal = s2.addFinalState("FINAL");
        addStateHandlers(sFinal);

        t = sa.addUTransition(e3, sFinal);
        addTranHandlers(t);


        t = s2.addTransition(s0); // final
        addTranHandlers(t);

        s0.addUTransition(eX, s0.getReturnPoint());
        addTranHandlers(t);

        SMGuard isEntryEvent = new SMNaryGuard() {

            @Override
            public int select(SMTransitionGuardContext info) {

                SMStateVertex sourceState = info.getSource();

                if ( sourceState.isEntryEventIs(e2) ) {
                    return 0;
                } else {
                    return -1;
                }
            }
        };

        t = s0.addTransition(eY, isEntryEvent, s0.getReturnPoint());
        addTranHandlers(t);

        t = s1.addUTransition(e1, s0);
        addTranHandlers(t);
        t = s1.addUTransition(e2, s2);
        addTranHandlers(t);
        t = s2.addUTransition(e1, s0);
        addTranHandlers(t);
        t = sa.addUTransition(e2, s0);
        addTranHandlers(t);


//        sm.init();

//        while (handleEventFromUser()) {
//        }

/*
        handleEvent(e1);
        handleEvent(eY); // will not return - must enter with e2
        handleEvent(eX); // will return
        handleEvent(e2);
        handleEvent(e1);
        handleEvent(eY); // will not return - must enter with e2
        handleEvent(eX); // will return
        handleEvent(e2);
        handleEvent(eY); // will return - entered with e2
        handleEvent(eX); // do nothing

        handleEvent(e3); // go to final state
        handleEvent(eX); // return to s2 !

*/

    }


    public static void main(String[] args) {
        SMAbstractTest test = new Example5();
        SMExampleRunner.runGUI(test);

    }
}




