package wf.state_machine.tests.examples;

import wf.state_machine.*;
import wf.state_machine.tests.infra.SMAbstractTest;
import wf.state_machine.tests.infra.SMExampleRunner;

public class Example6 extends SMAbstractTest {

    private static final SMUTrigger e1 = SMUTrigger.create("E1");
    private static final SMUTrigger e2 = SMUTrigger.create("E2");
    private static final SMUTrigger eX = SMUTrigger.create("EX");
    private static final SMUTrigger eY = SMUTrigger.create("EY");
    private static final SMUTrigger eZ = SMUTrigger.create("EZ");

    Example6() {
        super("Example6");
        SMTransition t;

        sm.defineTriggers(e1, e2, eX, eY, eZ);

        SMCompositeState tl = sm.getTopLevel();

        SMCompositeState s1 = tl.addCompositeState("S1");
        t = tl.addInitialState().addTransition(s1);
        addTranHandlers(t);

        addStateHandlers(s1);

        SMState sa = s1.addSimpleState("SA");
        t = s1.addInitialState().addTransition(sa);
        addTranHandlers(t);

        addStateHandlers(sa);

        SMState sb = s1.addSimpleState("SB");
        addStateHandlers(sb);

        SMState s2 = tl.addSimpleState("S2");
        addStateHandlers(s2);

        SMState s3 = tl.addSimpleState("S3");
        addStateHandlers(s3);

        SMTriggersAnd e1and = SMTriggersAnd.create(eX, eY, eZ);
        s1.defineAndTrigger(e1, e1and);
        s2.defineAndTrigger(e1, e1and);


        t = s1.addUTransition(e2, s3);
        addTranHandlers(t);

        t = sa.addUTransition(e1, sb);
        addTranHandlers(t);

        t = sb.addUTransition(e1, s2);
        addTranHandlers(t);
        t = sb.addUTransition(e2, s3);
        addTranHandlers(t);

        t = s2.addUTransition(e2, sa);
        addTranHandlers(t);
        t = s2.addUTransition(e1, s3);
        addTranHandlers(t);

        t = s3.addUTransition(e1, s2);
        addTranHandlers(t);


//        sm.init();

//        while (handleEventFromUser()) {
//        }


/*        handleEvent(e1);
        handleEvent(eY); // will not return - must enter with e2
        handleEvent(eX); // will return
        handleEvent(e2);
        handleEvent(e1);
        handleEvent(eY); // will not return - must enter with e2
        handleEvent(eX); // will return
        handleEvent(e2);
        handleEvent(eY); // will return - entered with e2
        handleEvent(eX); // do nothing

        handleEvent(e3); // go to final state
    handleEvent(eX); // return to s2 !
*/


    }


    public static void main(String[] args) {
        SMAbstractTest test = new Example6();
        SMExampleRunner.runGUI(test);

    }
}





