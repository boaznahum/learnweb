package wf.state_machine.tests.examples;

import wf.state_machine.*;
import wf.state_machine.tests.infra.SMAbstractTest;
import wf.state_machine.tests.infra.SMExampleRunner;


public class Example8 extends SMAbstractTest {

    private static final SMUTrigger e1 = SMUTrigger.create("E1");
    private static final SMUTrigger e2 = SMUTrigger.create("E2");
    private static final SMUTrigger e3 = SMUTrigger.create("E3");
    private static final SMUTrigger eX = SMUTrigger.create("EX");
    private static final SMUTrigger eY = SMUTrigger.create("EY");
    private static final SMUTrigger eZ = SMUTrigger.create("EZ");

    public Example8() {
        super("Example8");
        SMTransition t;

        sm.defineTriggers(e1, e2, e3, eX, eY, eZ);

        SMCompositeState tl = sm.getTopLevel();

        SMState s1 = tl.addSimpleState("S1");
        addStateHandlers(s1);
        t = tl.addInitialState().addTransition(s1);
        addTranHandlers(t);

        SMState s2 = tl.addSimpleState("S2");
        addStateHandlers(s2);
        SMState s3 = tl.addSimpleState("S3");
        addStateHandlers(s3);


        SMStateVertex cp1 = tl.addStaticChoicePoint("C1");
        SMStateVertex cp2 = tl.addStaticChoicePoint("C2");
        SMStateVertex d2 = tl.addDynamicChoicePoint("D2");
        SMStateVertex d3 = tl.addDynamicChoicePoint("D3");


        t = cp2.addTransition(null,
                getGuard(-1), s2, s3);
        addTranHandlers(t);


        SMCompositeState s4 = tl.addCompositeState("S4");
        addStateHandlers(s4);
        SMState sa = s4.addSimpleState("sa");
        addStateHandlers(sa);
        SMState sb = s4.addSimpleState("sb");
        addStateHandlers(sb);
        t = s4.addInitialState().addTransition(sb);
        addTranHandlers(t);


        t = cp1.addTransition(getGuard("q1",-1), cp2, sa, d2);
        addTranHandlers(t);

        SMStateVertex s4cp1 = s4.addStaticChoicePoint("C1");

        t = s4cp1.addTransition(getGuard(-1), sa, sb, s4, s3, cp1);
        addTranHandlers(t);

        t = sa.addUTransition(e2, s4cp1);
        addTranHandlers(t);


        t = s1.addUTransition(e1, cp1);
        addTranHandlers(t);
        t = s1.addUTransition(e2, d2);
        addTranHandlers(t);

        t = d2.addTransition(getGuard(-1), s1, s4, sa, d3);
        addTranHandlers(t);

        // we add default transition to d2, because dynamic choice point must have at least one path
        t = d2.addTransition(s1);
        addTranHandlers(t);

        t = d3.addTransition(getGuard(-1), s4, cp1, cp2);
        addTranHandlers(t);
        // we add default transition to d3, because dynamic choice point must have at least one path
        t = d3.addTransition(s1);
        addTranHandlers(t);


//        sm.init();

//        SMDOM.write(null, "Example8.xml", sm);
//        SMDot.createImageFile(null, sm, "Example8.jpg", "Example8.dot");



/*        handleEvent(e1);
        handleEvent(eY); // will not return - must enter with e2
        handleEvent(eX); // will return
        handleEvent(e2);
        handleEvent(e1);
        handleEvent(eY); // will not return - must enter with e2
        handleEvent(eX); // will return
        handleEvent(e2);
        handleEvent(eY); // will return - entered with e2
        handleEvent(eX); // do nothing

        handleEvent(e3); // go to final state
    handleEvent(eX); // return to s2 !
*/


    }



    public static void main(String[] args) {
        SMAbstractTest test = new Example8();
        test.setGuardMode(GuardMode.GUI);
        SMExampleRunner.runGUI(test);

    }
}







