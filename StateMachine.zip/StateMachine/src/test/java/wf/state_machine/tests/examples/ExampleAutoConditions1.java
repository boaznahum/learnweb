package wf.state_machine.tests.examples;

import wf.state_machine.SMCompositeState;
import wf.state_machine.SMConcurrentState;
import wf.state_machine.SMState;
import wf.state_machine.SMThreadingModel;
import wf.state_machine.SMUTrigger;
import wf.state_machine.tests.infra.SMAbstractTest;
import wf.state_machine.tests.infra.SMExampleRunner;


/**
 * This test demonstrates auto generated events
 * <pre>
 * ----
 * |CC|
 * --------------------------------------------------------------------
 * | C1                                                               |
 * |      ---------------                   --------------            |
 * |      |             | ----x---[in_(S1)]-|            |            |
 * |      |     A       |        |          |     B      |            |
 * |      |             |        |          |            |            |
 * |      ---------------        |[else]    --------------            |
 * |                             |          --------------            |
 * |                             |          |            |            |
 * |                             -----------|     C      |            |
 * |                                        |            |            |
 * |                                        --------------            |
 * --------------------------------------------------------------------
 * | C2                                                               |
 * |      ---------------            --------------                   |
 * |      |             | --y------> |            |                   |
 * |      |     S1      |            |     S2     |                   |
 * |      |             | <--z------ |            |                   |
 * |      ---------------            --------------                   |
 * --------------------------------------------------------------------
 * </pre>
 */

public class ExampleAutoConditions1 extends SMAbstractTest {

    private static final SMUTrigger x = SMUTrigger.create("x");
    private static final SMUTrigger y = SMUTrigger.create("y");
    private static final SMUTrigger z = SMUTrigger.create("z");

    ExampleAutoConditions1(SMThreadingModel tm) {
        super("Auto Conditions", tm);

        sm.defineTriggers(x, y, z);

        SMCompositeState tl = sm.getTopLevel();

        SMConcurrentState c = tl.addConcurrentState("CC");
        tl.addInitialState(c);

        SMCompositeState c1 = c.addCompositeState("C1");

        SMState sa = c1.addSimpleState("A");
        SMState sb = c1.addSimpleState("B");
        SMState sc = c1.addSimpleState("C");

        c1.addInitialState(sa);


        SMCompositeState c2 = c.addCompositeState("C2");

        SMState s1 = c2.addSimpleState("S1");
        SMState s2 = c2.addSimpleState("S2");

        c2.addInitialState(s1);

        sa.addTransition(x, s1.getIsIn(), sb, sc);

        s1.addUTransition(y, s2);
        s2.addUTransition(z, s1);




    }

    public static void main(String[] args) {
        SMAbstractTest test = new ExampleAutoConditions1(null);
        SMExampleRunner.runGUI(test);

    }
}