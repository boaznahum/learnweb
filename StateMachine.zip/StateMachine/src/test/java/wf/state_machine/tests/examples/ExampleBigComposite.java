package wf.state_machine.tests.examples;

import wf.state_machine.SMCompositeState;
import wf.state_machine.SMState;
import wf.state_machine.SMStateVertex;
import wf.state_machine.SMTransition;
import wf.state_machine.SMUTrigger;
import wf.state_machine.tests.infra.SMAbstractTest;
import wf.state_machine.tests.infra.SMExampleRunner;

public class ExampleBigComposite extends SMAbstractTest {

    private static final SMUTrigger e1 = SMUTrigger.create("E1");
    private static final SMUTrigger e2 = SMUTrigger.create("E2");
    private static final SMUTrigger e3 = SMUTrigger.create("E3");
    private static final SMUTrigger eX = SMUTrigger.create("EX");
    private static final SMUTrigger eY = SMUTrigger.create("EY");
    private static final SMUTrigger eZ = SMUTrigger.create("EZ");
    private static final SMUTrigger eW = SMUTrigger.create("EW");

    ExampleBigComposite()  {
        super("BigComposite");
        SMTransition t;

        sm.defineTriggers(e1, e2, e3, eX, eY, eZ, eW);

        SMCompositeState tl = sm.getTopLevel();

        SMCompositeState s0 = tl.addCompositeState("S0");
        addStateHandlers(s0);
        t = tl.addInitialState("I").addTransition(s0);
        addTranHandlers(t);

        SMCompositeState s1 = s0.addCompositeState("S1");
        addStateHandlers(s1);

        SMState sa = s1.addSimpleState("Sa");
        addStateHandlers(sa);
        SMState sb = s1.addSimpleState("Sb");
        addStateHandlers(sb);
        t = s1.addInitialState("I").addTransition(sb);
        addTranHandlers(t);
        SMState sc = s1.addSimpleState("Sc");
        addStateHandlers(sc);

        SMState sFinal = s1.addFinalState("S1Final");

        t = sa.addUTransition(e1, sb);
        addTranHandlers(t);
        t = sb.addUTransition(e1, sc);
        addTranHandlers(t);
        t = sc.addUTransition(e1, sFinal);
        addTranHandlers(t);

        t = sc.addUTransition(e2, sb);
        addTranHandlers(t);
        t = sb.addUTransition(e2, sa);
        addTranHandlers(t);

        SMStateVertex sh = s1.addShallowHistory("H");
        t = sh.addTransition(sa);
        addTranHandlers(t);


        SMState s2 = s0.addSimpleState("s2");
        addStateHandlers(s2);

        t = s1.addTransition(s2);
        addTranHandlers(t); // final
        t = s1.addUTransition(eX, s2);
        addTranHandlers(t);

        t = s2.addUTransition(eY, sh);
        addTranHandlers(t);

        SMState s3 = tl.addSimpleState("s3");
        addStateHandlers(s3);

        t = s0.addUTransition(eZ, s3);
        addTranHandlers(t);
        t = s1.addUTransition(eW, s3);
        addTranHandlers(t);

        SMStateVertex s0H = s0.addDeepHistory("H*");
        t = s0H.addTransition(sc);
        addTranHandlers(t);
        t = s0.addInitialState("I").addTransition(s0H);
        addTranHandlers(t);


        t = s3.addUTransition(eY, s0H);
        addTranHandlers(t);

        t = s3.addUTransition(e1, s0);
        addTranHandlers(t);

        t = s3.addUTransition(e2, s1);
        addTranHandlers(t);

    }


    public static void main(String[] args) {
        SMAbstractTest test = new ExampleBigComposite();
        SMExampleRunner.runGUI(test);

    }
}








