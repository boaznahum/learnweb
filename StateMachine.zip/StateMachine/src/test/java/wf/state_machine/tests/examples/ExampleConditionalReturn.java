package wf.state_machine.tests.examples;

import wf.state_machine.*;
import wf.state_machine.tests.infra.SMAbstractTest;
import wf.state_machine.tests.infra.SMExampleRunner;

/**
 * Demonstrate:
 * -Return point with conditional
 * -Two transitions withs same trigger
 * 
 *
 */
public class ExampleConditionalReturn extends SMAbstractTest {

    private static final SMUTrigger e1 = SMUTrigger.create("E1");
    private static final SMUTrigger e2 = SMUTrigger.create("E2");
    private static final SMUTrigger eX= SMUTrigger.create("EX");

    private static final SMUTrigger eY = SMUTrigger.create("EY");

    public ExampleConditionalReturn() {
        //super(true, true);

        super("Example4");

        SMTransition t;

        sm.defineTriggers(e1, e2, eX, eY);

        SMCompositeState tl = sm.getTopLevel();

        SMState s0 = tl.addSimpleState("S0");
        addStateHandlers(s0);

        SMState sNR = tl.addSimpleState("NR");

        SMState s1 = tl.addSimpleState("S1");
        t = tl.addInitialState().addTransition(s1);
        addTranHandlers(t);
        addStateHandlers(s1);


        SMCompositeState s2 = tl.addCompositeState("S2");
        addStateHandlers(s2);

        SMState sa = s2.addSimpleState("SA");
        addStateHandlers(sa);
        t = s2.addInitialState().addTransition(sa);
        addTranHandlers(t);
        addStateHandlers(sa);

        s0.addUTransition(eX, s0.getReturnPoint());
        addTranHandlers(t);

        SMGuard isEntryEvent = new SMCondition() {

            @Override
            public String getName() {
                return "entry is e2";
            }

            @Override
            public boolean isTrue(SMTransitionGuardContext info) {

                SMStateVertex sourceState = info.getSource();

                return sourceState.isEntryEventIs(e2);
            }
        };

        t = s0.addTransition(eY, isEntryEvent, s0.getReturnPoint());
        addTranHandlers(t);

        t = s0.addUTransition(eY, sNR);
        addTranHandlers(t);


        t = s1.addUTransition(e1, s0);
        addTranHandlers(t);
        t = s1.addUTransition(e2, s2);
        addTranHandlers(t);
        t = s2.addUTransition(e1, s0);
        addTranHandlers(t);
        t = sa.addUTransition(e2, s0);
        addTranHandlers(t);



        sm.init();

//        SMDot.createImageFile(null, sm, "ExampleConditionalReturn.jpg", "ExampleConditionalReturn.dot");



//        handleEvent(mInternal);

//        handleEvent(e1);
//        handleEvent(eY); // will not return - must enter with e2
//        handleEvent(eX); // will return
//        handleEvent(e2);
//        handleEvent(e1);
//        handleEvent(eY); // will not return - must enter with e2
//        handleEvent(eX); // will return
//        handleEvent(e2);
//        handleEvent(eY); // will return - entered with e2
//        handleEvent(eX); // do nothing

//        while (handleEventFromUser()) {
//        }


    }


    public static void main(String[] args) {
        SMAbstractTest test = new ExampleConditionalReturn();
        SMExampleRunner.runGUI(test);

    }
}



