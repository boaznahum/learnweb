package wf.state_machine.tests.examples;

import wf.state_machine.SMCompositeState;
import wf.state_machine.SMState;
import wf.state_machine.SMStateHandler;
import wf.state_machine.SMUTrigger;
import wf.state_machine.tests.infra.SMAbstractTest;
import wf.state_machine.tests.infra.SMExampleRunner;


public class ExampleInternalTransition extends SMAbstractTest {

    private static final SMUTrigger e1 = SMUTrigger.create("E1");
    private static final SMUTrigger e2 = SMUTrigger.create("E2");
    private static final SMUTrigger e3 = SMUTrigger.create("E3");

    private static final SMUTrigger eI = SMUTrigger.create("eI");

    private ExampleInternalTransition() {
        super("Internal Transition");

        sm.defineTriggers(e1, e2, e3, eI);

        SMCompositeState tl = sm.getTopLevel();


        //      {// define "S1"
        SMState sa = tl.addSimpleState("SA");
        SMState sb = tl.addSimpleState("SB");

        tl.addInitialState(sa);

        sb.addUTransition(e1, sa);
        sa.addUTransition(e3, sb);

        SMStateHandler ih = i -> { };
        sa.onTriggerDo(e1, ih);

        // to itself
        sb.addUTransition(eI, sb);

        SMCompositeState sx = tl.addCompositeState("SX");

        sx.onTriggerDo(e1, ih);
        sx.onTriggerDo(e2, ih);

        sx.addUTransition(eI, sx);

        sa.addUTransition(e2, sx);

        sx.addInitialState(sx.addSimpleState("x"));


    }

    public static void main(String[] args) {
        SMAbstractTest test = new ExampleInternalTransition();
        SMExampleRunner.runGUI(test);

    }
}