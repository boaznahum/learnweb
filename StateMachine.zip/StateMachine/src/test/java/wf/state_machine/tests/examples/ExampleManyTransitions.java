package wf.state_machine.tests.examples;

import wf.state_machine.SMCompositeState;
import wf.state_machine.SMGuard;
import wf.state_machine.SMNaryGuard;
import wf.state_machine.SMState;
import wf.state_machine.SMThreadingModel;
import wf.state_machine.SMTransitionGuardContext;
import wf.state_machine.SMUTrigger;
import wf.state_machine.tests.infra.SMAbstractTest;
import wf.state_machine.tests.infra.SMExampleRunner;


/**
 * This test demonstrates many type of transitions
 * <p/>
 * See  <img src="diagrams/Transitions.png" />
 */

public class ExampleManyTransitions extends SMAbstractTest {

    private static final SMUTrigger x = SMUTrigger.create("x");
    private static final SMUTrigger y = SMUTrigger.create("y");
    private static final SMUTrigger z = SMUTrigger.create("z");


    private static final SMGuard T = new SMNaryGuard() {
        @Override
        public int select(SMTransitionGuardContext info) {
            return 0;
        }
    };

    //private static class MySMCondition extends SMCondition {
    //
    //    @Override
    //    public boolean isTrue(SMTransitionGuardContext info) {
    //        return false;
    //    }
    //
    //    @Override
    //    public String getName() {
    //        return "C";
    //    }
    //}

    ExampleManyTransitions(SMThreadingModel tm) {
        super("MayTransitions", tm);


        final SMGuard cnd = getCondition("C");


        sm.defineTriggers(x, y, z);

        SMCompositeState tl = sm.getTopLevel();


        SMState s1 = tl.addSimpleState("S1");
        tl.addInitialState(s1);
        SMState s2 = tl.addSimpleState("S2");
        SMState s3 = tl.addSimpleState("S3");
        SMState s4 = tl.addSimpleState("S4");

        s1.addUTransition(x, s2);
        s1.addTransition(y, cnd, s2, s3);

        s1.addTransition(y, T, s2, s3, s4);

        SMState s5 = tl.addSimpleState("S5");
        SMCompositeState s6 = tl.addCompositeState("S6");
        SMState s6_1 = s6.addSimpleState("S1");
        s6.addInitialState(s6_1);

        s5.addUTransition(x, s6);
        s5.addUTransition(y, s6_1);

        s5.addTransition(z, cnd, s6, s6_1);


        s1.addUTransition(z, s5);
        s5.addUTransition(z, s1);


    }

    public static void main(String[] args) {
        SMAbstractTest test = new ExampleManyTransitions(null);
        SMExampleRunner.runGUI(test);

    }
}