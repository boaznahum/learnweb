package wf.state_machine.tests.examples;

import wf.state_machine.SMCompositeState;
import wf.state_machine.SMState;
import wf.state_machine.SMUTrigger;
import wf.state_machine.tests.infra.SMAbstractTest;
import wf.state_machine.tests.infra.SMExampleRunner;


/**
 * See  <img src="diagrams/ReturnPoint.jpg" />
 */


public class ExampleReturnPoint extends SMAbstractTest {

    @SuppressWarnings("EnumeratedClassNamingConvention")
    private enum T implements SMUTrigger {
        R,
        X,
        X1,
        X2;

        @Override
        public String getName() {
            return super.name();
        }
    }

    ExampleReturnPoint() {

        // define 'Events' world
        super("Return Point");

        sm.defineTriggers(T.values());

        SMCompositeState tl = sm.getTopLevel();


        SMState sS = tl.addSimpleState("S");
        SMState sNR = tl.addSimpleState("NR");
        SMState sS1 = tl.addSimpleState("S1");
        SMState sS2 = tl.addSimpleState("S2");

        tl.addInitialState(sS);


        sS.addUTransition(T.R, sS.getReturnPoint());
        // add default transition - in case state not yet memorized source state
        sS.addUTransition(T.R, sNR);

        sS.addUTransition(T.X1, sS1);
        sS.addUTransition(T.X2, sS2);

        sS1.addUTransition(T.X, sS);
        sS1.addUTransition(T.X2, sS2);

        sS2.addUTransition(T.X, sS);
        sS2.addUTransition(T.X1, sS1);
    }



    public static void main(String[] args) {
        SMAbstractTest test = new ExampleReturnPoint();
        SMExampleRunner.runGUI(test);
    }

}