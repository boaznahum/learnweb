package wf.state_machine.tests.examples;

import wf.state_machine.*;
import wf.state_machine.tests.infra.SMAbstractTest;
import wf.state_machine.tests.infra.SMExampleRunner;

public class ExampleSmallConcurrentWithDone extends SMAbstractTest {

    private static final SMUTrigger e1 = SMUTrigger.create("E1");
    private static final SMUTrigger e2 = SMUTrigger.create("E2");
    private static final SMUTrigger e3 = SMUTrigger.create("E3");
    private static final SMUTrigger eX = SMUTrigger.create("EX");
    private static final SMUTrigger eY = SMUTrigger.create("EY");
    private static final SMUTrigger eZ = SMUTrigger.create("EZ");

     ExampleSmallConcurrentWithDone() {
        super("Example Small Concurrent With Done");
        SMTransition t;

        sm.defineTriggers(e1, e2, e3, eX, eY, eZ);

        SMCompositeState tl = sm.getTopLevel();

        SMConcurrentState cs = tl.addConcurrentState("SS");
        addStateHandlers(cs);
        t = tl.addInitialState().addTransition(cs);
        addTranHandlers(t);


        SMCompositeState s1 = cs.addCompositeState("S1");
        addStateHandlers(s1);
        SMCompositeState s2 = cs.addCompositeState("S2");
        addStateHandlers(s2);
        SMState s3 = tl.addSimpleState("S3");
        addStateHandlers(s3);
        SMState sDone = tl.addSimpleState("DONE");
        addStateHandlers(sDone);


        {
            // program s1
            SMState sa = s1.addSimpleState("sa");
            addStateHandlers(sa);
            t = s1.addInitialState().addTransition(sa);
            addTranHandlers(t);

            SMState sb = s1.addSimpleState("sb");
            addStateHandlers(sb);
            SMState sc = s1.addSimpleState("sc");
            addStateHandlers(sc);
            SMState f = s1.addFinalState("S1F");
            addStateHandlers(f);

            t = sa.addUTransition(eX, sb);
            addTranHandlers(t);
            t = sb.addUTransition(eX, sc);
            addTranHandlers(t);
            t = sc.addUTransition(eY, sb);
            addTranHandlers(t);
            t = sb.addUTransition(eY, sa);
            addTranHandlers(t);

            t = sa.addUTransition(e2, sb);
            addTranHandlers(t);
            t = sb.addUTransition(e3, sc);
            addTranHandlers(t);

            t = sc.addUTransition(eZ, f);
            addTranHandlers(t);

            t = sc.addUTransition(eX, f);
            addTranHandlers(t);

        }

        {
            // program s2
            SMState sa = s2.addSimpleState("sa");
            addStateHandlers(sa);

            SMState sd = s2.addSimpleState("sd");
            addStateHandlers(sd);
            t = s2.addInitialState().addTransition(sd);
            addTranHandlers(t);


            SMState se = s2.addSimpleState("se");
            addStateHandlers(se);
            SMState f = s2.addFinalState("S2F");
            addStateHandlers(f);

            t = sa.addUTransition(e3, sd);
            addTranHandlers(t);
            t = sd.addUTransition(e2, se);
            addTranHandlers(t);

            t = se.addUTransition(eY, f);
            addTranHandlers(t);

            t = se.addUTransition(eZ, s3);
            addTranHandlers(t);


        }

        t = cs.addUTransition(e1, s3);
        addTranHandlers(t);
        t = s3.addUTransition(e2, s3.getReturnPoint());
        addTranHandlers(t);

        t = cs.addTransition(sDone);
        addTranHandlers(t);



    }


    public static void main(String[] args) {
        SMAbstractTest test = new ExampleSmallConcurrentWithDone();
        SMExampleRunner.runGUI(test);

    }
}






