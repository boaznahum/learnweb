package wf.state_machine.tests.examples;

import wf.state_machine.SMCompositeState;
import wf.state_machine.SMConcurrentState;
import wf.state_machine.SMState;
import wf.state_machine.SMStateVertex;
import wf.state_machine.SMTransition;
import wf.state_machine.SMUTrigger;
import wf.state_machine.tests.infra.SMAbstractTest;

/**
 * @author Boaz Nahum
 * @version WI VX.6, V12.0X, ADC V0.95
 */

class SMBigConcurrentBase extends SMAbstractTest {

    static final SMUTrigger e1 = SMUTrigger.create("E1");
    static final SMUTrigger e2 = SMUTrigger.create("E2");
    private static final SMUTrigger e3 = SMUTrigger.create("E3");
    private static final SMUTrigger e5 = SMUTrigger.create("E5");
    private static final SMUTrigger e6 = SMUTrigger.create("E6");
    private static final SMUTrigger eX = SMUTrigger.create("EX");
    private static final SMUTrigger eY = SMUTrigger.create("EY");

    static final SMUTrigger eF = SMUTrigger.create("EF");
    static final SMUTrigger eZ = SMUTrigger.create("EZ");
    static final SMUTrigger eW = SMUTrigger.create("EW");

    private static final SMUTrigger[] myTriggers = new SMUTrigger[]{
        e1, e2, e3, e5, e6, eF, eX, eY, eZ, eW
    };


    SMBigConcurrentBase(String testName) {
        super(testName);

        sm.defineTriggers(myTriggers);

    }

    void buildBigState(SMCompositeState tl, SMState s22, int index) {
        SMTransition t;
        SMConcurrentState s = tl.addConcurrentState("S" + (index + 1));
        addStateHandlers(s);

        SMCompositeState s1_1 = s.addCompositeState("S1");
        addStateHandlers(s1_1);
        SMCompositeState s1_2 = s.addCompositeState("S2");
        addStateHandlers(s1_2);

        SMState s1a = s1_1.addSimpleState("SA");
        addStateHandlers(s1a);
        t = s1_1.addInitialState().addTransition(s1a);
        addTranHandlers(t);
        SMState s1b = s1_1.addSimpleState("SB");
        addStateHandlers(s1b);

        SMState s2a = s1_2.addSimpleState("SA");
        addStateHandlers(s2a);
        SMState s2c = s1_2.addSimpleState("SC");
        addStateHandlers(s2c);
        t = s1_2.addInitialState().addTransition(s2c);
        addTranHandlers(t);

        SMStateVertex f1_1 = s.addFork("F1");

        t = f1_1.addTransition(s1_1);
        addTranHandlers(t);
        t = f1_1.addTransition(s2a);
        addTranHandlers(t);

        SMStateVertex h1 = s1_1.addDeepHistory("H*");
        t = h1.addTransition(s1b);
        addTranHandlers(t);
        SMStateVertex h2 = s1_2.addDeepHistory("H*");
        t = h2.addTransition(s2a);
        addTranHandlers(t);

        SMStateVertex fHis = s.addFork("FH*");
        t = fHis.addTransition(h1);
        addTranHandlers(t);
        t = fHis.addTransition(h2);
        addTranHandlers(t);

        t = s1a.addUTransition(eX, s1b);
        addTranHandlers(t);
        t = s1b.addUTransition(eX, s1a);
        addTranHandlers(t);

        t = s2a.addUTransition(eY, s2c);
        addTranHandlers(t);
        t = s2c.addUTransition(eY, s2a);
        addTranHandlers(t);

        SMConcurrentState s3 = s1_2.addConcurrentState("S3");
        addStateHandlers(s3);

        SMCompositeState s3_1 = s3.addCompositeState("S1");
        addStateHandlers(s3_1);
        SMCompositeState s3_2 = s3.addCompositeState("S2");
        addStateHandlers(s3_2);

        SMState sx = s3_1.addSimpleState("SX");
        addStateHandlers(sx);

        SMState sz = s3_1.addSimpleState("SZ");
        addStateHandlers(sz);
        SMState sy = s3_2.addSimpleState("SY");
        addStateHandlers(sy);
        SMState sw = s3_2.addSimpleState("SW");
        addStateHandlers(sw);

        SMState f = s3_1.addFinalState("FINAL");
        addStateHandlers(f);
        sz.addUTransition(e3, f);

        f = s3_2.addFinalState("FINAL");
        addStateHandlers(f);
        sw.addUTransition(e3, f);

        t = s3_1.addInitialState().addTransition(sx);
        addTranHandlers(t);
        t = s3_2.addInitialState().addTransition(sy);
        addTranHandlers(t);


        t = sx.addUTransition(e1, sz);
        addTranHandlers(t);
        t = sz.addUTransition(e1, sx);
        addTranHandlers(t);

        t = sy.addUTransition(e2, sw);
        addTranHandlers(t);
        t = sw.addUTransition(e2, sy);
        addTranHandlers(t);

        SMStateVertex s3_j = s3.addJoin("J");
        t = sz.addUTransition(e5, s3_j);
        addTranHandlers(t);
        t = sw.addUTransition(e5, s3_j);
        addTranHandlers(t);
        t = s3_j.addTransition(s22);
        addTranHandlers(t);

        t = s2c.addUTransition(e3, s3);
        addTranHandlers(t);

        SMStateVertex cp1 = s1_1.addStaticChoicePoint("CP1");


        SMStateVertex fcp1 = s.addFork("FCP1");

        t = fcp1.addTransition(cp1);
        addTranHandlers(t);

        SMStateVertex j = s.addJoin("J1");


        t = s1b.addUTransition(e5, j);
        addTranHandlers(t);
        t = s3.addUTransition(e5, j);
        addTranHandlers(t);
        t = s1_2.addUTransition(e6, j);
        addTranHandlers(t);
    }
}
