package wf.state_machine.tests.examples;

import wf.state_machine.SMCompositeState;
import wf.state_machine.SMState;
import wf.state_machine.SMTransition;
import wf.state_machine.tests.infra.SMAbstractTest;
import wf.state_machine.tests.infra.SMExampleRunner;


public class SMExample10Big1Concurrent extends SMBigConcurrentBase {



    SMExample10Big1Concurrent()  {
        super("Big 1 Concurrent");

        SMTransition t;


        SMCompositeState tl = sm.getTopLevel();

        SMState s22 = tl.addSimpleState("S22");
        addStateHandlers(s22);

        buildBigState(tl, s22, 0);

        //SMConcurrentState s1 = (SMConcurrentState) tl.getState("S1");

        t = tl.addInitialState(tl.getState("S1:s1:sb"));
        addTranHandlers(t);

        tl.getStateAssert("S1:J1").addTransition(s22);



    }


    public static void main(String[] args) throws Throwable {
        final SMAbstractTest test = new SMExample10Big1Concurrent();
        //SMExampleRunner.run(test, SMExampleLoggerType.NONE, true, myTriggers);
        SMExampleRunner.runGUI(test);
    }
}