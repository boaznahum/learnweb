package wf.state_machine.tests.examples;

import wf.state_machine.*;
import wf.state_machine.outputers.SMDOM;
import wf.state_machine.outputers.dot.SMDot;
import wf.state_machine.outputers.XMLContext;
import wf.state_machine.outputers.dot.DotContext;
import wf.state_machine.tests.infra.SMAbstractTest;
import wf.state_machine.tests.infra.SMExampleRunner;


public class SMExample10Big2Concurrent extends SMBigConcurrentBase {



    public SMExample10Big2Concurrent()  {
        super("Big 2 Concurrent");

        SMTransition t;


        SMCompositeState tl = sm.getTopLevel();

        SMState s22 = tl.addSimpleState("S22");
        addStateHandlers(s22);

        for (int i = 0; i < 2; ++i) {
            buildBigState(tl, s22, i);
        }

        SMConcurrentState s1 = (SMConcurrentState) tl.getState("S1");
        SMConcurrentState s2 = (SMConcurrentState) tl.getState("S2");

        t = tl.addInitialState().addTransition(tl.getState("S1:s1:sb"));
        addTranHandlers(t);

        {
            SMState s1b = (SMState) s1.getStateAssert("s1:sb");
            SMState s2b = (SMState) s2.getStateAssert("s1:sb");
            t = s1b.addUTransition(e1, s2);
            addTranHandlers(t);
            t = s2b.addUTransition(e1, s1);
            addTranHandlers(t);
        }

        {
            SMState s2_1 = (SMState) s2.getStateAssert("s1");
            SMStateVertex f1 = s1.getStateAssert("F1");
            t = s2_1.addUTransition(e2, f1);
            addTranHandlers(t);
        }

        {
            // set transition between two history forks
            t = s1.addUTransition(eZ, s2.getStateAssert("FH*"));
            addTranHandlers(t);
            t = s2.addUTransition(eZ, s1.getStateAssert("FH*"));
            addTranHandlers(t);

        }

        t = s1.addUTransition(eW, s2);
        addTranHandlers(t);
        t = s2.addUTransition(eW, s1);
        addTranHandlers(t);

        {
            SMStateVertex cp = s1.getStateAssert("s1:cp1");

            SMStateVertex
                    t1 = s1.getStateAssert("s1:sa"),
                    t2 = s1.getStateAssert("s1:sb");

            t = cp.addTransition(getGuard(-1), t1, t2/*, t3, t4, t5 */);

            addTranHandlers(t);

            cp = s2.getStateAssert("s1:cp1");

            t = cp.addTransition(getGuard(-1),
                s2.getStateAssert("s1:sa"),
                s2.getStateAssert("s1:sb"));

            addTranHandlers(t);

            SMStateVertex fcp = s1.getStateAssert("FCP1");
            t = s2.addUTransition(eF, fcp);
            addTranHandlers(t);
        }

        t = s1.getStateAssert("J1").addUTransition(null, s2);
        addTranHandlers(t);
        t = s2.getStateAssert("J1").addUTransition(null, s1);
        addTranHandlers(t);

        //sm.describe("Example10.xml");


        sm.init();

        SMDOM.write(new XMLContext(DotContext.createDefaultConfiguration()), "Example1.xml", sm);

        SMDot.createImageFile(null, sm, "Example1.jpg", "Example1.dot");

    }


    public static void main(String[] args) throws Throwable {
        final SMAbstractTest test = new SMExample10Big2Concurrent();
        //SMExampleRunner.run(test, SMExampleLoggerType.NONE, true, myTriggers);
        test.setGuardMode(GuardMode.GUI);
        SMExampleRunner.runGUI(test);
    }
}








