package wf.state_machine.tests.infra;

import wf.state_machine.SMStateVertex;

/**
 * @author Boaz Nahum
 * @version WI VX.6, V12.0X, ADC V0.95
 */

class SMAbstractPatternWriter {

    @SuppressWarnings({"StringBufferField"})
    final StringBuilder stringBuilder;

    private static final String STATE_IN = "enter_%n,";
    private static final String STATE_EXIT = "exit_%n,";
    private static final String STATE_BEGIN = "begin_%n,";
    private static final String STATE_END = "end_%n,";

    SMAbstractPatternWriter() {
        stringBuilder = new StringBuilder();
    }

    public void reset() {
        stringBuilder.setLength(0);
    }

    public String getGeneratedString() {
        return stringBuilder.toString();
    }

    void impAddStateEnter(SMStateVertex state) {
        addStateEvent(state, STATE_IN);
    }

    void impAddStateExit(SMStateVertex state) {
        addStateEvent(state, STATE_EXIT);
    }

    void impAddStateBegin(SMStateVertex state) {
        addStateEvent(state, STATE_BEGIN);
    }

    void impAddStateEnd(SMStateVertex state) {
        addStateEvent(state, STATE_END);
    }

    private void addStateEvent(SMStateVertex state, String event) {

        String stateName = state.getName();

        event = event.replaceAll("%n", stateName);

        stringBuilder.append(event);
    }

    @Override
    public String toString() {
        return getGeneratedString();
    }
}
