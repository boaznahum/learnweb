package wf.state_machine.tests.infra;

import org.jetbrains.annotations.Nullable;
import wf.state_machine.SMCondition;
import wf.state_machine.SMGuard;
import wf.state_machine.SMNaryGuard;
import wf.state_machine.SMState;
import wf.state_machine.SMStateHandler;
import wf.state_machine.SMStateHandlerType;
import wf.state_machine.SMThreadingModel;
import wf.state_machine.SMTransition;
import wf.state_machine.SMTransitionGuardContext;
import wf.state_machine.SMTransitionHandler;
import wf.state_machine.SMTransitionHandlerContext;
import wf.state_machine.SMTrigger;
import wf.state_machine.SMUTrigger;
import wf.state_machine.StateMachine;
import wf.state_machine.SMTargetSelection;
import wf.state_machine.smlogger.SMJLoggerLogger;
import wf.state_machine.smlogger.guilogger.SMGUIDebugger;
import wf.state_machine.tests.infra.guard_dialog.SMGuardSelectionDialog;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Random;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;
import java.util.logging.ConsoleHandler;
import java.util.logging.Level;
import java.util.logging.Logger;

@SuppressWarnings({"SSBasedInspection", "CallToPrintStackTrace", "UseOfSystemOutOrSystemErr"})
public class SMAbstractTest {

    protected final StateMachine sm;
    private final Random mRandom = new Random();
    //private JFrame debuggerFrame;


    private static final SMUTrigger T_INTERNAL = SMUTrigger.create("INTERNAL");

    /**
     * If true, guard {@link MyGuard} return random value instead of querying user
     */
    private GuardMode guardMode = GuardMode.Random;

    private static final SMThreadingModel threadingModel = SMThreadingModel.Caller;

    private static final WeakHashMap<StateMachine, Object> createdMachines =
        new WeakHashMap<>();

    // for uni tests
    protected final SMPatternGenerator patternWriter =
        new SMPatternGenerator();

    public enum GuardMode {

        Random,
        Console,
        GUI
    }


    protected SMAbstractTest(String testName) {
        this(testName, threadingModel);
    }

    protected SMAbstractTest(String testName, SMThreadingModel tm) {
        sm = StateMachine.createStateMachine(testName, (tm == null) ? threadingModel : tm);
        sm.defineTriggers(T_INTERNAL);

        createdMachines.put(sm, null);
    }

    ///**
    // * Default threading model for all newly created tests.
    // * Default is {@link SMThreadingModel#Caller}
    // * @param threadingModel
    // */
    //public static void setThreadingModel(SMThreadingModel threadingModel) {
    //    SMAbstractTest.threadingModel = threadingModel;
    //}
    //

    public StateMachine getSM() {
        return sm;
    }

    public SMPatternGenerator getPatternWriter() {
        return patternWriter;
    }

    public void attachToGUIDebugger() {

        SMGUIDebugger debugger = SMGUIDebugger.createMM();

        sm.attachTo(debugger);
    }


    public void attachCondoleLogger() {

        Logger logger = Logger.getAnonymousLogger();
        logger.setLevel(Level.ALL);

        ConsoleHandler handler = new ConsoleHandler();
        handler.setLevel(Level.ALL);
        logger.addHandler(handler);

        //Logger.getGlobal().setLevel(Level.ALL);
        sm.attachTo(new SMJLoggerLogger(logger));
    }


    protected static void waitForAllMachinesReleased() {

        // check that sm released
        System.out.println("Waiting for all machines to released");
        while (true) {

            Set<StateMachine> lives = createdMachines.keySet();
            if (lives.isEmpty()) {
                break;
            }

            for (StateMachine sm : lives) {
                System.out.println("  " + sm.getName() + " (TM:" + sm.debugGetThreadingModel() + ")");
            }

            System.out.println("Sleeping ... ");
            System.gc();
            try {
                TimeUnit.MILLISECONDS.sleep(500);
            } catch (InterruptedException ignore) {
            }
            System.out.println("Checking again ... ");
            System.out.println("-------------------------------");
        }

        System.out.println("All machines released");


    }

//=========================================================================
// transition handler

    protected static void addTranHandlers(SMTransition t) {
        SMTransitionHandler h = getTranHandler();
        t.onEndDo(h, SMTargetSelection.ALL);
        t.onDo(h, SMTargetSelection.ALL);
    }


    private static SMTransitionHandler getTranHandler() {
        return new MyTransitionHandler();
    }


    private static class MyTransitionHandler implements SMTransitionHandler {

        @Override
        public void handle(SMTransitionHandlerContext i) {

            i.logUserMsg((i.endOfTransition() ? "End of" : "Begin of") +
                         " transition: " +
                         "'" + i.getSource() + "'" +
                         " --" +
                         "'" + i.getTrigger().getName() + "'" +
                         "-->" +
                         "'" + i.getTarget() + "'");

            //i.cancelThis();
        }
    }

    protected void addStateHandlers(SMState s) {
        addStateHandlers(s, (SMTrigger[])null);
    }

    @SuppressWarnings({"OverloadedVarargsMethod"})
    protected static void addStateHandlers(SMState s, SMTrigger... internalTranEvents) {
        s.onEntryDo(getStateHEnter());
        s.onStateDo(getStateHDoActivity());
        s.onExitDo(getStateHExit());

        if (internalTranEvents != null) {
            for (SMTrigger internalTranEvent : internalTranEvents) {
                s.onTriggerDo(internalTranEvent, getStateHandlerInternal());
            }
        }
    }

    private static SMStateHandler getStateHEnter() {
        return i -> {
            String msg = "Entering state: " + i.getThisState();
            if (i.getTriggerData() != null) {
                msg += ", U.D=" + i.getTriggerData();
            }
            i.logUserMsg(msg);
            //info.cancelThis();
        };
    }

    private static SMStateHandler getStateHExit() {
        return i -> {
            i.logUserMsg("Exiting state: " + i.getThisState());
            //info.cancelThis();
        };
    }


    private static SMStateHandler getStateHDoActivity() {
        return i -> {
            boolean begin = i.getType() == SMStateHandlerType.BEGIN_STATE_ACTIVITY;

            i.logUserMsg((begin ? "Begin " : "End ") +
                                            "'do activity' in state: " + i.getThisState());
            //info.cancelThis();
        };
    }

    private static SMStateHandler getStateHandlerInternal() {
        return i -> i.logUserMsg(
            "Internal transition in state: " + i.getThisState() +
            ", trigger: " + i.getTrigger());
    }


    public void setGuardMode(GuardMode random) {
        guardMode = random;
    }

    protected SMGuard getGuard() {
        return new MyGuard(-1);
    }

    protected SMGuard getGuard(int i) {
        return new MyGuard(i);
    }

    protected SMGuard getGuard(@Nullable String guardName, int i) {
        return new MyGuard(guardName, i);
    }

    protected SMGuard getCondition(@Nullable String guardName) {
        return new MyCondition(guardName, -1);
    }


//    void stateLocalEvent(SMState s, SMTrigger e) {
//        info.logUserMsg(
//                "=============== Sending to state:" +
//                        s + " event:" + e
//                        + " ==================");
//
//        System.out.println("*Before handling, current state: " + sm.getCurrentStatePathTree());
//        s.addToLocalEventQueue(e);
//        System.out.println("*After handling, current state: " + sm.getCurrentStatePathTree());
//
//    }

    //void handleEvent(SMTrigger e) {
    //    sm.logUserMsg("=============== Sending event:" + e + " =======================");
    //    sm.logUserMsg("*Before handling, current state: " + sm.getCurrentStatePathTree());
    //    sm.handleTrigger(e);
    //    sm.logUserMsg("*After handling, current state: " + sm.getCurrentStatePathTree());
    //}

    private static String getLine() {
        String line;

        try {
            BufferedReader rd = new BufferedReader(new InputStreamReader(System.in));

            line = rd.readLine();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

        return line;
    }

    //boolean handleEventFromUser() {
    //
    //    System.out.println("*Current state: " + sm.getCurrentStatePathTree());
    //
    //    while (true) {
    //        System.out.print("Enter event(. to exit):");
    //        System.out.flush();
    //
    //        String line = getLine();
    //
    //        if (line == null || line.equals(".")) {
    //            return false;
    //        }
    //
    //        SMTrigger e = sm.debugGetTriggerByName(line);
    //
    //        if (e != null) {
    //            handleEvent(e);
    //            return true;
    //        } else {
    //            System.out.println("Illegal event");
    //        }
    //    }
    //}

    //void runRandomly(int nTimes) {
    //    SMTrigger[] ids = sm.debugGetAllDefinedTriggers();
    //
    //    int n = ids.length;
    //
    //    inRandomMode = true;
    //
    //    while (nTimes-- > 0) {
    //        int i = mRandom.nextInt(n);
    //        SMTrigger e = ids[i];
    //        handleEvent(e);
    //    }
    //
    //    inRandomMode = false;
    //}

    Future[] attack(boolean waitDone) {


        GuardMode saved = guardMode;

        try {
            setGuardMode(GuardMode.Random);

            int nThreads = 100;
            final int nEventsPerThread = 500;
            final SMUTrigger[] events = sm.debugGetAllDefinedTriggers();
            final Random random = new Random();

            Future[] futures = new Future[nThreads];


            for (int i = 0; i < nThreads; ++i) {
                Runnable command = () -> {

                    int tillNow = 0;

                    try {
                        while (true) {

                            int nEvents = random.nextInt(nEventsPerThread / 10) + 1;
                            for (int j = 0; j < nEvents; ++j) {

                                int eI = random.nextInt(events.length);
                                SMUTrigger trigger = events[eI];
                                sm.handleTrigger(trigger);

                                if (++tillNow > nEventsPerThread) {
                                    return; // end run()
                                }

                            }

                            try {
                                Thread.sleep(random.nextInt(5));
                            } catch (InterruptedException ignore) {
                            }
                        }
                    } finally {
                        System.out.println(
                            "Attack " + Thread.currentThread().getName() + " finished, events=" + tillNow);
                    }
                };

                FutureTask f = new FutureTask<>(command, null);
                futures[i] = f;

                runCommandSepThread(f, false);
            }

            if (waitDone) {
                for (int i = 0; i < nThreads; ++i) {
                    try {
                        futures[i].get();
                    } catch (InterruptedException | ExecutionException e) {
                        e.printStackTrace();
                    }
                }
            }

            return futures;
        } finally {
            setGuardMode(saved);
        }
    }

    private static void runCommandSepThread(Runnable command, boolean daemon) {
        // i'm using new thread for each event because may i'm blocking my self in pause mode

        Thread myEventsSendingThread = new Thread(command);

        myEventsSendingThread.setDaemon(daemon);
        myEventsSendingThread.start();
    }


    private class MyGuard extends SMNaryGuard {

        private int selection;
        private final String guardName;

        /**
         * @param selection negative for user selection
         */
        MyGuard(int selection) {
            this(null, selection);
        }

        /**
         * @param selection _ if non negative, then this value is the return value
         * of {@link SMGuard#select(SMTransitionGuardContext)},
         * otherwise  a selection is generated according to {@link SMAbstractTest#guardMode}
         */
        MyGuard(String guardName, int selection) {
            this.selection = selection;
            this.guardName = guardName;
        }

        @Override
        public int select(SMTransitionGuardContext info) {
            if (selection < 0) {

                switch (guardMode) {
                    case Console:
                        return getConsoleSelection(info);


                    case Random: {
                        int n = info.getN();
                        int i = mRandom.nextInt(n);
                        return i;
                    }

                    case GUI:
                        return getGUISelection(info);
                }
            }

            return selection;
        }


        @Override
        public String getName() {
            return guardName;
        }
    }

    private class MyCondition extends SMCondition {

        private int selection;
        private final String guardName;

        /**
         * @param selection negative for user selection
         */
        MyCondition(int selection) {
            this(null, selection);
        }

        /**
         * @param selection _ if non negative, then this value is the return value
         * of {@link SMGuard#select(SMTransitionGuardContext)},
         * otherwise  a selection is generated according to {@link SMAbstractTest#guardMode}
         */
        MyCondition(String guardName, int selection) {
            this.selection = selection;
            this.guardName = guardName;
        }

        @Override
        public boolean isTrue(SMTransitionGuardContext info) {
            return nSelection(info) == 0;
        }

        private int nSelection(SMTransitionGuardContext info) {
            if (selection < 0) {

                switch (guardMode) {
                    case Console:
                        return getConsoleSelection(info);


                    case Random: {
                        int n = info.getN();
                        int i = mRandom.nextInt(n);
                        return i;
                    }

                    case GUI:
                        return getGUISelection(info);
                }
            }

            return selection;
        }


        @Override
        public String getName() {
            return guardName;
        }

    }

    private static int getGUISelection(SMTransitionGuardContext info) {

        SMGuardSelectionDialog dialog = new SMGuardSelectionDialog(info);
        dialog.pack();
        dialog.setVisible(true);

        return dialog.getSelected();
    }

    private static int getConsoleSelection(SMTransitionGuardContext info) {
        int n = info.getN();

        System.out.println("In " + info.getSource());

        for (int k = 0; k < n; ++k) {
            System.out.println("  " + k + ") " + info.getTarget(k));
        }

        System.out.print("Enter index of branch[0.." + (n - 1) + "]: ");

        int i = -1;

        String line = getLine();
        if (line != null) {
            i = Integer.parseInt(line);
        }

        return i;
    }


}

