package wf.state_machine.tests.infra;

/**
 * @author Boaz Nahum
 * @version x.5
 */

public enum SMExampleLoggerType {
    NONE,
    CONSOLE,
    GUI
}
