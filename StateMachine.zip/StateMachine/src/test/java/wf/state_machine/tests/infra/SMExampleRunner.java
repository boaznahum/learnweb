package wf.state_machine.tests.infra;

import wf.state_machine.SMUTrigger;
import wf.state_machine.outputers.SMDOM;
import wf.state_machine.outputers.dot.SMDot;
import wf.state_machine.StateMachine;
import org.jetbrains.annotations.Nullable;
import wf.state_machine.tests.infra.SMExampleLoggerType;
import wf.state_machine.tests.infra.SMAbstractTest;

/**
 * @author Boaz Nahum
 * @version x.5
 */

@SuppressWarnings({"UseOfSystemOutOrSystemErr"})
public class SMExampleRunner {

    private SMExampleRunner() {
    }


    public static void runGUI(SMAbstractTest test) {
        run(test, SMExampleLoggerType.GUI, false, null);

    }

    /**
     *
     * @param test
     * @param logger
     * @param attack
     * @param triggers if not null then these triggers are submitted to SM after constructing 
     */
    public static void run(SMAbstractTest test, SMExampleLoggerType logger, boolean attack, @Nullable SMUTrigger[] triggers) {

        String name = test.getClass().getSimpleName();

        StateMachine sm = test.getSM();

        if (logger == SMExampleLoggerType.CONSOLE) {
            test.attachCondoleLogger();
        } else if (logger == SMExampleLoggerType.GUI) {
            test.attachToGUIDebugger();
        }

        sm.init();

        SMDOM.write(null, name + ".xml", sm);

        SMDot.createImageFile(null, sm, name + ".jpg", name + ".dot");


        if (triggers != null) {
            for (SMUTrigger t : triggers) {
                sm.handleTrigger(t);
            }
        }

        if (attack) {
            test.attack(false);
        }

        int n;
        do {
            sm.debugWriteStatistics();

            n = sm.debugGetTriggerQueue().length;
            if (n > 0) {
                System.out.println("Sleeping. Still more events:" + n);
                try {
                    Thread.sleep(100);
                } catch (InterruptedException ignore) {
                }
            }
            
        } while (n > 0);

    }

}
