package wf.state_machine.tests.infra;

/**
 * @author Boaz Nahum
 * @version WI VX.6, V12.0X, ADC V0.95
 */

public class SMExpectedGroup extends SMExpectedPatternGenerator {

    private final SMExpectedPatternGenerator parent;
    private final String many;

    SMExpectedGroup(SMExpectedPatternGenerator parent, String many) {
        this.parent = parent;
        this.many = many;
    }

    /**
     * End a non-capturing group
     */
    public void end() {
        parent.addGroup(this);
    }


    String getMany() {
        return many;
    }
}
