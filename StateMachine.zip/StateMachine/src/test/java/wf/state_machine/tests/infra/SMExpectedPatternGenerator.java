package wf.state_machine.tests.infra;

import org.jetbrains.annotations.Nullable;
import wf.state_machine.SMState;
import wf.state_machine.tests.infra.SMAbstractPatternWriter;

/**
 * @author Boaz Nahum
 * @version WI VX.6, V12.0X, ADC V0.95
 */

@SuppressWarnings({"ClassReferencesSubclass"})
public class SMExpectedPatternGenerator extends SMAbstractPatternWriter {

    public static class Many {

        /**
         * X?       X, once or not at all
         * X*       X, zero or more times
         * X+       X, one or more times
         * X{n}     X, exactly n times
         * X{n,}    X, at least n times
         * X{n,m}   X, at least n but not more than m times

         */
        public static final String M_ONCE_OR_NONE = "?";
        public static final String M_ZERO_OR_MORE = "*";
        public static final String M_ONCE_OR_MORE = "+";

        public static final String M_EXACTLY_ONCE= "{1}";

        private Many() {
        }

    }


    void addGroup(SMExpectedGroup group) {
        String many = group.getMany();

        if (many != null) {
            // X, as a non-capturing group
            stringBuilder.append("(?:");
        }
        stringBuilder.append(group.stringBuilder);

        if (many != null) {
            stringBuilder.append(")");
            stringBuilder.append(many);
        }
    }

    /**
     * begin a non-capturing group
     *
     *@param many {@link Many} !!! must match the one that called with {@link #beginGrouping(String)}
     *
     * X?       X, once or not at all
     * X*       X, zero or more times
     * X+       X, one or more times
     * X{n}     X, exactly n times
     * X{n,}    X, at least n times
     * X{n,m}   X, at least n but not more than m times
     *
     */
    public SMExpectedGroup beginGrouping(String many) {
        return new SMExpectedGroup(this, many);
    }


    /**
     *
     * @param state
     * @param withDoActivity If true, then add 'begin do activity'
     * @param many See {@link #beginGrouping(String)}
     */
    public void addStateEntry(SMState state, boolean withDoActivity, @Nullable String many) {

        SMExpectedGroup group = beginGrouping(many);
        group.impAddStateEnter(state);
        if (withDoActivity) {
            group.impAddStateBegin(state);
        }
        group.end();
    }

    public void addStateExit(SMState state, boolean withDoActivity, String many) {

        SMExpectedGroup group = beginGrouping(many);
        if (withDoActivity) {
            group.impAddStateEnd(state);
        }
        group.impAddStateExit(state);
        group.end();
    }

    public void addStateExitEntry(SMState exitFrom, SMState enterTo, boolean withDoActivity, String many) {

        SMExpectedGroup group = beginGrouping(many);
        group.addStateExit(exitFrom, withDoActivity, null);
        group.addStateEntry(enterTo, withDoActivity, null);
        group.end();
    }

    public void addStateBegin(SMState s) {

        SMExpectedGroup group = beginGrouping(null);
        group.impAddStateBegin(s);
        group.end();
    }

    void addStateEnd(SMState s) {
        SMExpectedGroup group = beginGrouping(null);
        group.impAddStateEnd(s);
        group.end();
    }


}
