package wf.state_machine.tests.infra;

import wf.state_machine.SMState;
import wf.state_machine.SMStateHandler;
import wf.state_machine.SMStateHandlerType;

/**
 * @author Boaz Nahum
 * @version WI VX.6, V12.0X, ADC V0.95
 */

public class SMPatternGenerator extends SMAbstractPatternWriter {

    public SMPatternGenerator() {
        super();
    }



    public void addPatternWriter(SMState ... states) {

        SMStateHandler entryHandler = i -> impAddStateEnter(i.getThisState());

        SMStateHandler exitHandler = i -> impAddStateExit(i.getThisState());

        SMStateHandler doActivityHandler = i -> {

            if (i.getType() == SMStateHandlerType.BEGIN_STATE_ACTIVITY) {
                impAddStateBegin(i.getThisState());
            } else {
                impAddStateEnd(i.getThisState());
            }
        };


        for (SMState state : states) {
            state.onEntryDo(entryHandler);
            state.onExitDo(exitHandler);
            state.onStateDo(doActivityHandler);
        }

    }


}
