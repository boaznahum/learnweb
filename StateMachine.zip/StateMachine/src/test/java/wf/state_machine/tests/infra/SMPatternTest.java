package wf.state_machine.tests.infra;

import wf.state_machine.StateMachine;
import wf.state_machine.tests.infra.SMAbstractTest;

/**
 * @author Boaz Nahum
 * @version WI VX.6, V12.0X, ADC V0.95
 */

public class SMPatternTest {

    private final SMAbstractTest smTest;
    private final SMExpectedPatternGenerator expected = new SMExpectedPatternGenerator();

    public SMPatternTest(SMAbstractTest smTest) {
        this.smTest = smTest;
    }

    public StateMachine getSM() {
        return smTest.getSM();
    }

    public SMPatternGenerator patternWriter() {
        return smTest.getPatternWriter();
    }

    public SMExpectedPatternGenerator expected() {
        return expected;
    }
}
