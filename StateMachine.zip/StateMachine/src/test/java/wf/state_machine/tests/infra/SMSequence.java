package wf.state_machine.tests.infra;

import org.jetbrains.annotations.Nullable;
import wf.state_machine.SMUTrigger;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * @author Boaz Nahum
 * @version WI VX.6, V12.0X, ADC V0.95
 */

public abstract class SMSequence {

    public static final Random R = new Random();

    private static final int MAX_N = 300000;


    @Nullable
    abstract SMUTrigger next();

    protected abstract void reset();

    /**
     * One sequence (t1 ... Tn)
     */
    public static SMSequence once(SMUTrigger... t) {

        final List<SMUTrigger> ts = Arrays.asList(t);


        return new SMSequence() {

            private Iterator<SMUTrigger> it = ts.iterator();


            @Override
            SMUTrigger next() {
                if (it.hasNext()) {
                    return it.next();
                } else {
                    return null;
                }
            }

            @Override
            protected void reset() {
                it = ts.iterator();
            }
        };
    }

    /**
     * Partial(or empty) sequence T1 .. Tm, where m <= N 
     */
    public static SMSequence partial(SMUTrigger... t) {

        final List<SMUTrigger> ts = Arrays.asList(t);


        return new SMSequence() {

            private Iterator<SMUTrigger> it;
            { reset();}


            @Override
            SMUTrigger next() {
                if (it.hasNext()) {
                    return it.next();
                } else {
                    return null;
                }
            }

            @Override
            protected void reset() {
                int n = R.nextInt(ts.size());
                it = ts.subList(0, n).iterator();
            }
        };
    }


    /**
     * Partial(or empty) sequence T1 .. Tm, where m <= N
     */
    public static SMSequence partialSeq(final SMSequence sequence) {



        return new SMSequence() {

            private Iterator<SMUTrigger> it;

            {
                reset();
            }


            @Override
            SMUTrigger next() {
                if (it.hasNext()) {
                    return it.next();
                } else {
                    return null;
                }
            }

            @Override
            protected void reset() {

                final List<SMUTrigger> ts = new ArrayList<>();

                sequence.reset();
                SMUTrigger t;
                while ( (t=sequence.next()) != null) {
                    ts.add(t);
                }

                int n = R.nextInt(ts.size());
                it = ts.subList(0, n).iterator();
            }
        };
    }
    /**
     * Peak n random M triggers from sequence  T1 .. Tm, where m <= M
     * @param many If false then M is <= N where N is number of triggers in sequence
     */
    public static SMSequence randomSeq(final boolean many, final SMSequence sequence) {



        return new SMSequence() {

            private Iterator<SMUTrigger> it;

            {
                reset();
            }


            @Override
            SMUTrigger next() {
                if (it.hasNext()) {
                    return it.next();
                } else {
                    return null;
                }
            }

            @Override
            protected void reset() {

                final List<SMUTrigger> ts = new ArrayList<>();

                sequence.reset();
                SMUTrigger t;
                while ( (t=sequence.next()) != null) {
                    ts.add(t);
                }

                int nRandom;
                int sequenceSize = ts.size();
                if (many) {
                    nRandom = R.nextInt(MAX_N);
                } else {
                    if (sequenceSize >0) {
                        nRandom = R.nextInt(sequenceSize) + 1;
                    } else {
                        nRandom = 0;
                    }
                }

                final List<SMUTrigger> random = new ArrayList<>(nRandom);

                for (int i= 0; i < nRandom; ++i) {
                    int p = R.nextInt(sequenceSize);
                    random.add(ts.get(p));
                }
                it = random.iterator();
            }
        };
    }


    /**
     * Complete sequence (t1 ... Tn) x zero or more times
     */
    public static SMSequence zeroOrMore(SMUTrigger... t) {
        return zeroOrMoreSeq(once(t));
    }


    /**
     * Complete sequence (seq) x zero or more times
     */
    private static SMSequence zeroOrMoreSeq(final SMSequence seq) {
        return nOrMoreSeq(0, seq);
    }


    /**
     * Complete N  times
     */
    private static SMSequence nSeq(final int nn, final SMSequence seq) {
        return nOrMoreSeq(nn, 0, seq);
    }

    /**
     * Complete sequence (t1 ... Tn) x N or more times
     */
    public static SMSequence nOrMore(int n, SMUTrigger... t) {
        return nOrMoreSeq(n, once(t));
    }


    /**
     * Complete sequence (seq) N  or more times
     */
    public static SMSequence nOrMoreSeq(final int nn, final SMSequence seq) {
        return nOrMoreSeq(nn, MAX_N, seq);
    }
    /**
     * Complete sequence m times, where m is randomly in [nn, nn+delta)
     * If delta is zero then it is executed nn times.
     * If delta < 0 then {@link #MAX_N} is used.
     */
    public static SMSequence nOrMoreSeq(final int nn, final int delta, final SMSequence seq) {



        return new SMSequence() {
            private int n;

            private SMSequence once;
            {
                reset();
            }

            @Override
            SMUTrigger next() {

                while (true) {
                    if (once == null) {
                        if (n == 0) {
                            return null;
                        } else {
                            seq.reset();
                            once = seq;

                        }
                    } else {
                        SMUTrigger nt = once.next();
                        if (nt == null) {
                            once = null; // prepare to create new one
                            if (n > 0) {
                                --n;
                            }
                            // and try again while loop
                        } else {
                            return nt;
                        }
                    }
                }

            }

            @Override
            protected void reset() {
                int d = (delta < 0) ? MAX_N : delta;
                // if delta == 0 then n == nn;
                n= nn + R.nextInt(d + 1);
            }
        };


    }


}
