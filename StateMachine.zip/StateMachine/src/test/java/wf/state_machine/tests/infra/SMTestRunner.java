package wf.state_machine.tests.infra;

import wf.state_machine.SMTrigger;
import wf.state_machine.SMUTrigger;
import wf.state_machine.StateMachine;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map.Entry;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * @author Boaz Nahum
 * @version WI VX.6, V12.0X, ADC V0.95
 */

@SuppressWarnings({"UseOfSystemOutOrSystemErr", "CallToPrintStackTrace"})
public class SMTestRunner {

    private boolean verbose;
    private final String longName;
    private final SMPatternTest test;

    private ExecutorService executor;
    private final int nTasks;

    private final ConcurrentMap<Thread, AtomicInteger> threadsStatistics;


    /**
     * Start test
     * - Reset the pattern writer
     * - Init state machine
     *
     * @param name
     * @param test
     */
    public SMTestRunner(String name, SMPatternTest test) {
        longName = name + "(TM:" + test.getSM().debugGetThreadingModel() + ")";
        this.test = test;


        System.out.println("Beginning Test:" + longName + " ---------------");


        int nThreads = SMSequence.R.nextInt(20) + 1;
        nTasks = SMSequence.R.nextInt(20) + 1;

        System.out.println("nThreads=" + nThreads);
        System.out.println("nTasks=" + nTasks);

        executor = Executors.newFixedThreadPool(nThreads);

        threadsStatistics = new ConcurrentHashMap<>();


        // init

        SMPatternGenerator patternWriter = test.patternWriter();
        patternWriter.reset();
        StateMachine sm = test.getSM();

        sm.init();


    }


    public void setVerbose(boolean verbose) {
        this.verbose = verbose;
    }

    boolean isVerbose() {
        return verbose;
    }

    /**
     * - Handle all events in sequences
     *
     * @param synchroniseThreads if true, then threads are synchronized according to order of triggers.
     * This is not so good threads, because it hide the problems that may occurred when accessing state machine from different threads.
     * But to use false value, your test should more smarter - brig state machine to known state after randomly triggers
     * or to made regular expression much complicated.
     */
    public void run(boolean synchroniseThreads, SMSequence... sequences) {
        runImp(synchroniseThreads, sequences);

    }


    /**
     * After calling this method, runner is no longer valid
     * Run the given triggers once
     * - Handle all events in array triggers
     * - compare generated pattern against the expected one
     * - Reset verbose to false;
     *
     * @param synchroniseThreads see {@link #run(boolean, SMSequence...)}
     */
    public boolean finishTest(boolean synchroniseThreads,
                              SMSequence... sequences) {

        run(synchroniseThreads, sequences);
        SMPatternGenerator patternWriter = test.patternWriter();
        SMExpectedPatternGenerator expectedPattern = test.expected();

        shutdown();

        boolean result = compare(patternWriter, expectedPattern);
        setVerbose(false);

        if (!result) {
            throw new RuntimeException("Test: '" + longName + "' failed");
        }

        return result;

    }

    private void shutdown() {

        executor.shutdown();

        try {
            executor.awaitTermination(Long.MAX_VALUE, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            //noinspection CallToPrintStackTrace,SSBasedInspection
            e.printStackTrace();
        }

        executor = null;


        test.getSM().debugWriteStatistics();

        // print threads statistics
        System.out.println("Threads Statistics:");
        int total = 0;
        for (Entry<Thread, AtomicInteger> e : threadsStatistics.entrySet()) {

            int c = e.getValue().intValue();
            if (c > 0) {
                System.out.println("   " + e.getKey().getName() + ":  " + e.getValue());
            }
            total += c;
        }
        System.out.println("   ------------------------------------");
        System.out.println("   Total:" + total);

    }


    /**
     * Run the given triggers once
     * - Reset the pattern writer
     * - Init state machine
     * - Handle all events in array triggers
     * - compare generated pattern against the expected one
     *
     * @param synchroniseThreads see {@link #run(boolean, SMSequence...)}
     */
    public boolean runTest(boolean synchroniseThreads,
                           SMSequence... sequences) {


        run(synchroniseThreads, sequences);

        return finishTest(synchroniseThreads);

    }

    private boolean compare(SMPatternGenerator patternWriter,
                            SMExpectedPatternGenerator expectedPattern) {

        String generated = patternWriter.getGeneratedString();
        String expected = expectedPattern.getGeneratedString();

        if (expected.length() < 300) {
            System.out.println(" Expected:" + expected);
        }
        if (generated.length() < 300) {
            System.out.println("Generated:" + generated);
        } else {
            System.out.println("Generated: length=" + generated.length());
            System.out.println(generated.substring(0, 300));
            System.out.println(" ... ");
            System.out.println(generated.substring(generated.length() - 300));

        }

        boolean status = generated.matches(expected);
        System.out.println("Test '" + longName + "' " + (status ? "passed" : "failed"));
        return status;

    }

    private void runImp(final boolean synchroniseThreads, final SMSequence[] sequences) {

        if (sequences.length == 0) {
            return;
        }

        for (SMSequence sequence : sequences) {
            sequence.reset();
        }

        final StateMachine sm = test.getSM();

        ArrayList<Future<?>> tasks = new ArrayList<>(nTasks);
        final List<Future<Object>> triggerTasks = Collections.synchronizedList(new ArrayList<Future<Object>>());

        for (int i = 0; i < nTasks; ++i) {
            Runnable task = new Runnable() {

                private Thread currentThread;

                private void handle(SMTrigger t) {
                    if (isVerbose()) {
                        System.out.println(currentThread.getName() + ": " + t + ", ");
                    }
                    triggerTasks.add(sm.submitTrigger(t));
                }

                private void traceThread() {

                    threadsStatistics.putIfAbsent(currentThread, new AtomicInteger());

                    AtomicInteger atomicInteger = threadsStatistics.get(currentThread);
                    //System.out.println("atomicInteger[" + currentThread.getName() + "]" + atomicInteger);
                    atomicInteger.incrementAndGet();
                }


                @Override
                public void run() {

                    int handledCount = 0;

                    currentThread = Thread.currentThread();

                    for (SMSequence sequence : sequences) {

                        while (true) {
                            SMTrigger t;
                            if (synchroniseThreads) {
                                synchronized (sequences) {
                                    t = sequence.next();
                                    if (t == null) {
                                        break;
                                    }

                                    handle(t);
                                }
                            } else {
                                synchronized (sequences) {
                                    t = sequence.next();
                                }
                                if (t == null) {
                                    break;
                                }

                                handle(t);
                            }

                            traceThread();

                            if (++handledCount > 10) {
                                try {
                                    TimeUnit.NANOSECONDS.sleep(SMSequence.R.nextInt(10));
                                    //Thread.sleep(1);
                                    Thread.yield();
                                } catch (Throwable e) {
                                    e.printStackTrace();
                                }
                                handledCount = 0;
                            }
                        }
                    }
                }
            };
            tasks.add(executor.submit(task));
        }

        System.out.println("Waiting for " + tasks.size() + " threads to complete sending triggers");
        for (Future f : tasks) {
            try {
                f.get();
            } catch (Throwable e) {
                //noinspection CallToPrintStackTrace
                e.printStackTrace();
            }
        }

        // now wait for all triggers to be completed, otherwise we can't check pattern
        System.out.println("Waiting for " + triggerTasks.size() + " triggers to completed");
        for (Future<Object> f : triggerTasks) {
            try {
                f.get();
            } catch (CancellationException ignore) {
            } catch (Throwable e) {
                //noinspection CallToPrintStackTrace
                e.printStackTrace();
            }
        }


        if (isVerbose()) {
            System.out.println();
        }
    }


    public static void performanceTest(SMAbstractTest t, SMSequence sequence) {

        StateMachine sm = t.getSM();

        sm.init();

        long begin = System.nanoTime();

        int n = performanceRun(sm, sequence);

        long end = System.nanoTime();

        System.out.println("Tester sent " + n + " triggers");

        sm.debugWriteStatistics();

        System.out.println("Average time:" + ((double)(end-begin))/n + " nano/trigger");


    }

    /**
     * Do a simple trigger handling to measure performance
     */
    private static int performanceRun(StateMachine sm, final SMSequence... sequences) {

        if (sequences.length == 0) {
            return 0;
        }

        for (SMSequence sequence : sequences) {
            sequence.reset();
        }

        int n = 0;
        for (SMSequence sequence : sequences) {

            while (true) {
                SMUTrigger t;
                t = sequence.next();
                if (t == null) {
                    break;
                }

                sm.handleTrigger(t);
                ++n;
            }
        }

        return n;
    }

}
