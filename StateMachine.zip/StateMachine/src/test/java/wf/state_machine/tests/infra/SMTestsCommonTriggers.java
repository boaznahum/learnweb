package wf.state_machine.tests.infra;

import wf.state_machine.SMUTrigger;

/**
* @author Boaz Nahum
* @version WI VX.6, V12.0X, ADC V0.95
*/
public enum SMTestsCommonTriggers implements SMUTrigger {

    E1,
    E2,
    E3,
    E4,
    L1,
    L2,
    L3,
    L4;

    @Override
    public String getName() {
        return name();
    }
}
