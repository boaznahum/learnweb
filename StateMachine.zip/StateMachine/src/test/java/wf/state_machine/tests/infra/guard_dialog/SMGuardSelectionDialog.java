package wf.state_machine.tests.infra.guard_dialog;

import wf.state_machine.SMGuard;
import wf.state_machine.SMTransitionGuardContext;

import javax.swing.*;

public class SMGuardSelectionDialog extends JDialog {

    private JPanel contentPane;
    private JButton buttonOK;
    private JComboBox<Object> selectionComboBox;
    private JTextField guardNameTextField;
    private JTextField fromStateTextField;
    private JTextField triggerTextField;

    private int selected = -1;


    public SMGuardSelectionDialog(SMTransitionGuardContext guardInfo) {
        super(JOptionPane.getRootFrame(), "Guard Selection", true);
        setContentPane(contentPane);
        getRootPane().setDefaultButton(buttonOK);

        SMGuard guard = guardInfo.getGuard();
        String guardName = guard.getName();
        if (guardName == null) {
            guardName = "Unknown";
        }
        guardNameTextField.setText(guardName);

        fromStateTextField.setText(guardInfo.getSource().getName());
        triggerTextField.setText(guardInfo.getTrigger().getName());

        selectionComboBox.removeAllItems();
        selectionComboBox.addItem("--none--");

        int n = guardInfo.getN();
        for(int i = 0; i < n; ++i) {
            String s = "";
            String branchName = guard.getBranchName(n, i);
            if (branchName != null) {
                s += "[" + branchName + "]";
            }
            s += " --> " + guardInfo.getTarget(i).getName(); 
            selectionComboBox.addItem(s);
        }

        buttonOK.addActionListener(e -> onOK());
        setResizable(false);
    }

    public int getSelected() {
        return selected;
    }

    private void onOK() {

        selected = selectionComboBox.getSelectedIndex() - 1;

// add your code here
        dispose();
    }



}
