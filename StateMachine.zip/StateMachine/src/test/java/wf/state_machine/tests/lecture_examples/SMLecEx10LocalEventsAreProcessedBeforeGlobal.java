package wf.state_machine.tests.lecture_examples;

import wf.state_machine.SMCompositeState;
import wf.state_machine.SMState;
import wf.state_machine.SMUTrigger;
import wf.state_machine.StateMachine;
import wf.state_machine.smlogger.guilogger.SMGUIDebugger;


/**
 * This example demonstrate what happens when broadcasting and event into active state.
 * The event is handled before any other event in the state machine global queue.
 *
 *
 *             |-----------|
 * --ENTER---->|On entry   |-->EXIT
 *             |Broadcast I|
 *             |-----------|
 *
 *
 * @author Boaz Nahum
 */

public class SMLecEx10LocalEventsAreProcessedBeforeGlobal {

    private SMLecEx10LocalEventsAreProcessedBeforeGlobal() {
    }

    enum T implements SMUTrigger {INTERNAL, ENTER, EXIT};

    public static void main(String[] args) {


        // Create the state machine
        StateMachine sm = StateMachine.createStateMachine("");

        //Define the legal set of triggers
        sm.defineTriggers(T.class);

         // Get top level state, for which we are adding states.
        SMCompositeState tl = sm.getTopLevel();

        // Add states
        SMState idle = tl.addSimpleState("Idle");
        SMState processing = tl.addSimpleState("Processing");

        // Define initial state and transitions
        tl.addInitialState(idle);

        SMState finalState = tl.addFinalState();

        idle.addUTransition(T.ENTER, processing);
        processing.addUTransition(T.EXIT, finalState);

        processing.onEntryDo(c->{
            c.handleTrigger(T.EXIT);//this is global
            // Will this event be handled, although we have EXIT on Queue ?
            ((SMState)c.getThisState()).addToLocalEventQueue(T.INTERNAL);
        });

        processing.onTriggerDo(T.INTERNAL, h->{
            h.logUserMsg("Processing internal event");
        });


        // Attach the sm to GUI debugger
        SMGUIDebugger.createMM(sm);
        sm.init();


    }
}
