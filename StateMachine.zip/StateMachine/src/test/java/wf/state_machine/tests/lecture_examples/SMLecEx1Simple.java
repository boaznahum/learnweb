package wf.state_machine.tests.lecture_examples;

import wf.state_machine.SMCompositeState;
import wf.state_machine.SMState;
import wf.state_machine.SMUTrigger;
import wf.state_machine.StateMachine;
import wf.state_machine.smlogger.guilogger.SMGUIDebugger;

import static wf.state_machine.tests.lecture_examples.SMLecEx1Simple.T.*;

/**
 * @author Boaz Nahum
 */

public class SMLecEx1Simple {

    private SMLecEx1Simple() {
    }

    enum T implements SMUTrigger {GO, END};

    public static void main(String[] args) {


        // Create the state machine
        StateMachine sm = StateMachine.createStateMachine("");

        //Define the legal set of triggers
        sm.defineTriggers(T.class);

         // Get top level state, for which we are adding states.
        SMCompositeState tl = sm.getTopLevel();

        // Add states
        SMState idle = tl.addSimpleState("Idle");
        SMState processing = tl.addSimpleState("Processing");

        // Define initial state and transitions
        tl.addInitialState(idle);

        idle.addUTransition(GO, processing);
        processing.addUTransition(END, idle);

        // Attach the sm to GUI debugger
        SMGUIDebugger.createMM(sm);
        sm.init();


    }
}
