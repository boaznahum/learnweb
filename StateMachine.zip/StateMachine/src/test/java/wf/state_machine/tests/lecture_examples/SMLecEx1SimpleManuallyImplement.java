package wf.state_machine.tests.lecture_examples;

/**
 * @author Boaz Nahum
 */

@SuppressWarnings({"InfiniteLoopStatement", "ConstantConditions", "unused"})
public class SMLecEx1SimpleManuallyImplement {


    private enum Trigger { END, GO};

    private enum State { Processing, Idle}

    void run() {

        State current = State.Idle;

        while (true) {
            Trigger t = next();

            switch (current) {

                case Idle:
                    if (t == Trigger.GO) {
                        current = State.Processing;
                    }
                    break;

                case Processing:
                    if (t == Trigger.END) {
                        current = State.Idle;
                    }
                    break;
            }
        }
    }


    private Trigger next() {
        return null;
    }

}
