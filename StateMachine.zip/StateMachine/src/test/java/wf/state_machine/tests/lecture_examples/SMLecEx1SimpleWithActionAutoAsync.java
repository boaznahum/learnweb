package wf.state_machine.tests.lecture_examples;

import wf.state_machine.SMCompositeState;
import wf.state_machine.SMState;
import wf.state_machine.SMStateHandlerContext;
import wf.state_machine.SMUTrigger;
import wf.state_machine.StateMachine;
import wf.state_machine.smlogger.guilogger.SMGUIDebugger;

import java.util.concurrent.TimeUnit;

/**
 * @author Boaz Nahum
 */

public class SMLecEx1SimpleWithActionAutoAsync {

    private SMLecEx1SimpleWithActionAutoAsync() {
    }

    public static void main(String[] args) {


        // Create the state machine
        StateMachine sm = StateMachine.createStateMachine("");

        // Create and define the legal set of triggers
        SMUTrigger go = SMUTrigger.create("GO");
        SMUTrigger end = SMUTrigger.create("END");

        sm.defineTriggers(end, go);

        // Get top level state, for which we are adding states.
        SMCompositeState tl = sm.getTopLevel();

        // Add states
        SMState idle = tl.addSimpleState("Idle");
        SMState processing = tl.addSimpleState("Processing");

        // Define initial state and transitions
        tl.addInitialState(idle);

        idle.addUTransition(go, processing);
        processing.addUTransition(end, idle);

        // add some action:
        processing.betweenEntryExitDo(true, false,
                                      end,
                                      end,
                                      null,
                                      (c) -> process(c));


        // Attach the sm to GUI debugger
        SMGUIDebugger.createMM(sm);
        sm.init();


    }

    private static void process(SMStateHandlerContext i) throws InterruptedException {

        i.logUserMsg("Sleeping ...");

        for (int k = 1; k < 5; ++k) {

            TimeUnit.SECONDS.sleep(1);

            if (i.isCanceled()) {
                i.logUserMsg(".. Processing canceled");
                return;
            }
        }
        i.logUserMsg(".. done sleeping");

    }
}
