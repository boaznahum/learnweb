package wf.state_machine.tests.lecture_examples;

import wf.state_machine.SMCompositeState;
import wf.state_machine.SMHistory;
import wf.state_machine.SMState;
import wf.state_machine.SMUTrigger;
import wf.state_machine.StateMachine;
import wf.state_machine.smlogger.guilogger.SMGUIDebugger;


/**
 * @author Boaz Nahum
 */

public class SMLecEx2Composite {

    private SMLecEx2Composite() {}

    private enum T implements SMUTrigger {

        ON, OFF, TOUT, GO, END, PAUSE,RESUME;

        @Override
        public String getName() {
            return name();

        }
    }

    public static void main(String[] args) {


        // Create the state machine
        StateMachine sm = StateMachine.createStateMachine("");

        // Define the legal set of triggers
        sm.defineTriggers(T.class);

        // Get top level state, for which we are adding states.
        SMCompositeState tl = sm.getTopLevel();

        // Add states
        SMState off = tl.addSimpleState("off");
        SMCompositeState on = tl.addCompositeState("on");

        SMState idle = on.addSimpleState("idle");
        SMState processing = on.addSimpleState("processing");
        on.addInitialState(idle);

        SMHistory history = on.addShallowHistory();
        history.addTransition(idle);

        SMState paused = tl.addSimpleState("paused");


        // Define initial state and transitions
        tl.addInitialState(off);

        off.addUTransition(T.GO, processing);
        off.addUTransition(T.ON, on);

        on.addUTransition(T.OFF, off);
        on.addUTransition(T.PAUSE, paused);

        idle.addUTransition(T.GO, processing);
        idle.addUTransition(T.TOUT, off);
        processing.addUTransition(T.END, idle);

        paused.addUTransition(T.RESUME, history);






        // Attach the sm to GUI debugger
        SMGUIDebugger.createMM(sm);
        sm.init();


    }
}
