package wf.state_machine.tests.lecture_examples;

import wf.state_machine.SMCompositeState;
import wf.state_machine.SMConcurrentState;
import wf.state_machine.SMState;
import wf.state_machine.SMStateVertex;
import wf.state_machine.SMUTrigger;
import wf.state_machine.StateMachine;
import wf.state_machine.smlogger.guilogger.SMGUIDebugger;

import java.util.concurrent.TimeUnit;


/**
 * @author Boaz Nahum
 */

public class SMLecEx3Concurrent {

    private SMLecEx3Concurrent() {}

    private enum T implements SMUTrigger {

        SCAN, INIT_DONE, SCAN_DONE;

        @Override
        public String getName() {
            return name();

        }
    }

    public static void main(String[] args) {


        // Create the state machine
        StateMachine sm = StateMachine.createStateMachine("");

        // Define the legal set of triggers
        sm.defineTriggers(T.class);

        // Get top level state, for which we are adding states.
        SMCompositeState tl = sm.getTopLevel();

        // Add states


        SMConcurrentState devices = tl.addConcurrentState(null);

        SMState idle = tl.addSimpleState("idle");

        tl.addInitialState(idle);

        SMStateVertex fork = devices.addFork();

        idle.addUTransition(T.SCAN, fork);

        SMStateVertex join = devices.addJoin();

        for (int i = 1; i <= 2; ++i) {
            SMCompositeState device = createDevice(devices, i);

            fork.addTransition(device);

            device.addTransition(join);
        }

        SMState scan_done = tl.addSimpleState("scan done");

        join.addTransition(scan_done);

        // Attach the sm to GUI debugger
        SMGUIDebugger.createMM(sm);
        sm.init();

        //sm.handleTrigger(T.SCAN);
        //devicesL[1].addToLocalEventQueue(T.INIT_DONE);


    }

    private static SMCompositeState createDevice(SMConcurrentState devices,
                                                 int i) {

        SMCompositeState device = devices.addCompositeState("Device " + i);

        SMState initializing = device.addSimpleState("initializing");
        SMState scanning = device.addSimpleState("scanning");

        SMState finalState = device.addFinalState("");

        device.addInitialState(initializing);
        initializing.addUTransition(T.INIT_DONE, scanning);
        scanning.addUTransition(T.SCAN_DONE, finalState);


        initializing.betweenEntryExitDo(true, false,
                                        null, null, null,
                                        (c) -> {

                                              TimeUnit.SECONDS.sleep(i * 3L);

                                              //if (i == 1) {
                                                  device.addToLocalEventQueue(T.INIT_DONE);
                                              //}

                                          });


        return device;

    }

}
