package wf.state_machine.tests.lecture_examples;

import wf.state_machine.SMCompositeState;
import wf.state_machine.SMConcurrentState;
import wf.state_machine.SMState;
import wf.state_machine.SMStateHandlerContext;
import wf.state_machine.SMUTrigger;
import wf.state_machine.StateMachine;
import wf.state_machine.smlogger.guilogger.SMGUIDebugger;

import java.util.concurrent.TimeUnit;

/**
 * @author Boaz Nahum
 */

public class SMLecEx4OvenBroadcasting {

    private SMLecEx4OvenBroadcasting() {
    }

    private enum T implements SMUTrigger {
        BAKE, BAKE_OFF, LIGHT_OFF, LIGHT_ON
    }

    public static void main(String[] args) {


        // Create the state machine
        StateMachine sm = StateMachine.createStateMachine("");

        // Create and define the legal set of triggers
        sm.defineTriggers(T.class);

        // Get top level state, for which we are adding states.
        SMCompositeState tl = sm.getTopLevel();

        SMConcurrentState cs = tl.addConcurrentState("");


        SMCompositeState ovenLightState = buildOvenLightState(cs);


        buildOvenState(cs, ovenLightState);


        // Attach the sm to GUI debugger
        SMGUIDebugger.createMM(sm);
        sm.init();


    }

    private static void buildOvenState(SMConcurrentState cs, SMCompositeState ovenLightState) {

        SMCompositeState oven = cs.addCompositeState("Oven");

        SMState off = oven.addSimpleState("off");

        off.onEntryDo(i->ovenLightState.addToLocalEventQueue(T.LIGHT_OFF));

        oven.addInitialState(off);

        SMState baking = oven.addSimpleState("baking");

        baking.onEntryDo(i->ovenLightState.addToLocalEventQueue(T.LIGHT_ON));

        off.addUTransition(T.BAKE, baking);
        baking.addUTransition(T.BAKE_OFF, off);


    }

    private static SMCompositeState buildOvenLightState(SMConcurrentState cs) {

        SMCompositeState oven_light = cs.addCompositeState("Oven_Light");
        SMState oven_light_off = oven_light.addSimpleState("off");
        SMState oven_light_on = oven_light.addSimpleState("on");

        oven_light.addInitialState(oven_light_off);
        oven_light_off.addUTransition(T.LIGHT_ON, oven_light_on);
        oven_light_on.addUTransition(T.LIGHT_OFF, oven_light_off);

        return oven_light;
    }

    private static void process(SMStateHandlerContext i) throws InterruptedException {

        i.logUserMsg("Sleeping ...");

        for (int k = 1; k < 5; ++k) {

            TimeUnit.SECONDS.sleep(1);

            if (i.isCanceled()) {
                i.logUserMsg(".. Processing canceled");
                return;
            }
        }
        i.logUserMsg(".. done sleeping");

    }
}
