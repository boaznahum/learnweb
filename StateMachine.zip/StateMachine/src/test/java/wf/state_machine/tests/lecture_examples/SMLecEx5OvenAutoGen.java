package wf.state_machine.tests.lecture_examples;

import wf.state_machine.SMCompositeState;
import wf.state_machine.SMConcurrentState;
import wf.state_machine.SMState;
import wf.state_machine.SMUTrigger;
import wf.state_machine.StateMachine;
import wf.state_machine.smlogger.guilogger.SMGUIDebugger;

/**
 * @author Boaz Nahum
 */

public class SMLecEx5OvenAutoGen {

    private SMLecEx5OvenAutoGen() {
    }

    @SuppressWarnings("EnumeratedClassNamingConvention")
    private enum T implements SMUTrigger {
        BAKE, BAKE_OFF
    }

    public static void main(String[] args) {


        // Create the state machine
        StateMachine sm = StateMachine.createStateMachine("");

        // Create and define the legal set of triggers
        sm.defineTriggers(T.class);

        // Get top level state, for which we are adding states.
        SMCompositeState tl = sm.getTopLevel();

        SMConcurrentState cs = tl.addConcurrentState("");

        SMCompositeState oven = buildOvenState(cs);


        buildOvenLightState(cs, oven);




        // Attach the sm to GUI debugger
        SMGUIDebugger.createMM(sm);
        sm.init();


    }

    private static SMCompositeState buildOvenState(SMConcurrentState cs) {

        SMCompositeState oven = cs.addCompositeState("Oven");

        SMState off = oven.addSimpleState("off");

        oven.addInitialState(off);

        SMState baking = oven.addSimpleState("baking");

        off.addUTransition(T.BAKE, baking);
        baking.addUTransition(T.BAKE_OFF, off);

        return oven;


    }

    private static SMCompositeState buildOvenLightState(SMConcurrentState cs, SMCompositeState oven) {

        SMCompositeState oven_light = cs.addCompositeState("Oven_Light");
        SMState oven_light_off = oven_light.addSimpleState("light off");
        SMState oven_light_on = oven_light.addSimpleState("light on");



        oven_light.addInitialState(oven_light_off);
        SMState baking = oven.getRealStateAssert("baking");
        oven_light_off.addUTransition(baking.getEnterEvent(),
                                      oven_light_on);

        oven_light_on.addUTransition(oven.getRealStateAssert("off").getEnterEvent(),
                                     oven_light_off);

        return oven_light;
    }

}
