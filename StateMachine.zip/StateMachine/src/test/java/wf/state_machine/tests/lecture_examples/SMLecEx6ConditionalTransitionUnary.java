package wf.state_machine.tests.lecture_examples;

import wf.state_machine.SMCompositeState;
import wf.state_machine.SMState;
import wf.state_machine.SMUTrigger;
import wf.state_machine.StateMachine;
import wf.state_machine.smlogger.guilogger.SMGUIDebugger;

import java.util.Random;

/**
 * @author Boaz Nahum
 */

public class SMLecEx6ConditionalTransitionUnary {

    private SMLecEx6ConditionalTransitionUnary() {
    }

    @SuppressWarnings("EnumeratedClassNamingConvention")
    private enum T implements SMUTrigger {
        E1, E2
    }

    public static void main(String[] args) {


        // Create the state machine
        StateMachine sm = StateMachine.createStateMachine("");

        // Create and define the legal set of triggers
        sm.defineTriggers(T.class);

        // Get top level state, for which we are adding states.
        SMCompositeState tl = sm.getTopLevel();

        SMState idle = tl.addSimpleState("idle");
        tl.addInitialState(idle);

        SMState a = tl.addSimpleState("a");

        idle.addUTransition(T.E1,
                          "c",
                          (i)->new Random().nextBoolean(),
                          a);


        // Attach the sm to GUI debugger
        SMGUIDebugger.createMM(sm);
        sm.init();


    }





}
