package wf.state_machine.tests.lecture_examples;

import wf.state_machine.SMCompositeState;
import wf.state_machine.SMConcurrentState;
import wf.state_machine.SMCondition;
import wf.state_machine.SMState;
import wf.state_machine.SMUTrigger;
import wf.state_machine.StateMachine;
import wf.state_machine.smlogger.guilogger.SMGUIDebugger;

/**
 * @author Boaz Nahum
 */

public class SMLecEx7ConditionalTransitionBinary {

    private SMLecEx7ConditionalTransitionBinary() {
    }

    @SuppressWarnings("EnumeratedClassNamingConvention")
    private enum T implements SMUTrigger {
        E1, NO, YES
    }

    public static void main(String[] args) {


        // Create the state machine
        StateMachine sm = StateMachine.createStateMachine("");

        // Create and define the legal set of triggers
        sm.defineTriggers(T.class);

        // Get top level state, for which we are adding states.
        SMCompositeState tl = sm.getTopLevel();

        SMConcurrentState cs = tl.addConcurrentState("");




        SMCondition yes = buildControl(cs);


        {
            SMCompositeState binary = cs.addCompositeState("binary");

            SMState idle = binary.addSimpleState("idle");
            binary.addInitialState(idle);

            SMState a = binary.addSimpleState("a");
            SMState b = binary.addSimpleState("b");

            idle.addBTransition(T.E1,
                              yes,
                              a, b);
        }

        {
            SMCompositeState twoUnary = cs.addCompositeState("two unary");

            SMState s0 = twoUnary.addSimpleState("idle");
            twoUnary.addInitialState(s0);

            SMState a = twoUnary.addSimpleState("a");
            SMState b = twoUnary.addSimpleState("b");

            // The order is important
            s0.addUTransition(T.E1,
                              yes,
                              a);

            s0.addUTransition(T.E1,
                              b);
        }


        // Attach the sm to GUI debugger
        SMGUIDebugger.createMM(sm);
        sm.init();


    }

    private static SMCondition buildControl(SMConcurrentState cs) {
        SMCompositeState control = cs.addCompositeState("control");

        SMState yesS = control.addSimpleState("yes");

        SMState no = control.addSimpleState("no");

        control.addInitialState(no);

        yesS.addUTransition(T.NO, no);
        no.addUTransition(T.YES, yesS);

        SMCondition yes = yesS.getIsIn();

        return yes;
    }


}
