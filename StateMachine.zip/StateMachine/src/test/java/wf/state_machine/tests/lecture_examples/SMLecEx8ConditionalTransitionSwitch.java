package wf.state_machine.tests.lecture_examples;

import wf.state_machine.SMCompositeState;
import wf.state_machine.SMConcurrentState;
import wf.state_machine.SMState;
import wf.state_machine.SMTargetSelection;
import wf.state_machine.SMUTrigger;
import wf.state_machine.StateMachine;
import wf.state_machine.smlogger.guilogger.SMGUIDebugger;

/**
 * @author Boaz Nahum
 */

public class SMLecEx8ConditionalTransitionSwitch {

    private SMLecEx8ConditionalTransitionSwitch() {
    }

    @SuppressWarnings("EnumeratedClassNamingConvention")
    private enum T implements SMUTrigger {
        E1, NO, A, B, C, YES
    }

    public static void main(String[] args) {


        // Create the state machine
        StateMachine sm = StateMachine.createStateMachine("");

        // Create and define the legal set of triggers
        sm.defineTriggers(T.class);

        // Get top level state, for which we are adding states.
        SMCompositeState tl = sm.getTopLevel();

        SMConcurrentState cs = tl.addConcurrentState("");


        SMCompositeState control = buildControl(cs);


        {
            SMCompositeState binary = cs.addCompositeState("switch");

            SMState s0 = binary.addSimpleState("idle");
            binary.addInitialState(s0);

            SMState a = binary.addSimpleState("a");
            SMState b = binary.addSimpleState("b");
            SMState c = binary.addSimpleState("c");

            s0.addTransition(T.E1,
                             i -> {

                                 String x = control.getUserData().getString("s");

                                 switch (x) {

                                     case "a":
                                         return 0;

                                     case "b":
                                         return i.resolve(b);

                                     case "c":
                                         return 2;

                                     default:
                                         return SMTargetSelection.NONE;
                                 }
                             },
                             a, b, c);
        }

        //{
        //    SMCompositeState twoUnary = cs.addCompositeState("two unary");
        //
        //    SMState s0 = twoUnary.addSimpleState("idle");
        //    twoUnary.addInitialState(s0);
        //
        //    SMState a = twoUnary.addSimpleState("a");
        //    SMState b = twoUnary.addSimpleState("b");
        //
        //    // The order is important
        //    s0.addUTransition(T.E1,
        //                      control,
        //                      a);
        //
        //    s0.addUTransition(T.E1,
        //                      b);
        //}


        // Attach the sm to GUI debugger
        SMGUIDebugger.createMM(sm);
        sm.init();


    }

    private static SMCompositeState buildControl(SMConcurrentState cs) {
        SMCompositeState control = cs.addCompositeState("control");

        SMState a = control.addSimpleState("a");

        SMState b = control.addSimpleState("b");

        SMState c = control.addSimpleState("c");

        control.addInitialState(a);

        a.addTransitionsFromMany(T.A, null, a, b, c);
        b.addTransitionsFromMany(T.B, null, a, b, c);
        c.addTransitionsFromMany(T.C, null, a, b, c);

        a.onEntryDo(x -> control.getUserData().setString("s", "a"));
        b.onEntryDo(x -> control.getUserData().setString("s", "b"));
        c.onEntryDo(x -> control.getUserData().setString("s", "c"));


        return control;
    }


}
