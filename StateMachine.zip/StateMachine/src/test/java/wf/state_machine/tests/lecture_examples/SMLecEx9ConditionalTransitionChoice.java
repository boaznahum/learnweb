package wf.state_machine.tests.lecture_examples;

import wf.state_machine.SMCompositeState;
import wf.state_machine.SMConcurrentState;
import wf.state_machine.SMState;
import wf.state_machine.SMStateVertex;
import wf.state_machine.SMTargetSelection;
import wf.state_machine.SMUTrigger;
import wf.state_machine.StateMachine;
import wf.state_machine.smlogger.guilogger.SMGUIDebugger;

/**
 * @author Boaz Nahum
 */

public class SMLecEx9ConditionalTransitionChoice {

    private SMLecEx9ConditionalTransitionChoice() {
    }

    @SuppressWarnings("EnumeratedClassNamingConvention")
    private enum T implements SMUTrigger {
        E1, NO, A, B, C, YES, S1, S2
    }

    public static void main(String[] args) {


        // Create the state machine
        StateMachine sm = StateMachine.createStateMachine("");

        // Create and define the legal set of triggers
        sm.defineTriggers(T.class);

        // Get top level state, for which we are adding states.
        SMCompositeState tl = sm.getTopLevel();

        SMConcurrentState cs = tl.addConcurrentState("");


        SMCompositeState control = buildControl(cs);


        {
            SMCompositeState binary = cs.addCompositeState(null);

            SMState s1 = binary.addSimpleState("s1");
            binary.addInitialState(s1);


            SMState s2 = binary.addSimpleState("s2");

            SMStateVertex cp = binary.addStaticChoicePoint(null);

            SMCompositeState ss = binary.addCompositeState("");

            ss.addUTransition(T.S1, s1);
            ss.addUTransition(T.S2, s2);

            SMState a = ss.addSimpleState("a");
            SMState b = ss.addSimpleState("b");
            SMState c = ss.addSimpleState("c");

            s1.addUTransition(T.E1, cp);
            s2.addUTransition(T.E1, cp);


            cp.addTransition(i -> {

                                 String x = control.getUserData().getString("s");

                                 switch (x) {

                                     case "a":
                                         return 0;

                                     case "b":
                                         return i.resolve(b);

                                     case "c":
                                         return 2;

                                     default:
                                         return SMTargetSelection.NONE;
                                 }
                             },
                             a, b, c);
        }

        //{
        //    SMCompositeState twoUnary = cs.addCompositeState("two unary");
        //
        //    SMState s0 = twoUnary.addSimpleState("idle");
        //    twoUnary.addInitialState(s0);
        //
        //    SMState a = twoUnary.addSimpleState("a");
        //    SMState b = twoUnary.addSimpleState("b");
        //
        //    // The order is important
        //    s0.addUTransition(T.E1,
        //                      control,
        //                      a);
        //
        //    s0.addUTransition(T.E1,
        //                      b);
        //}


        // Attach the sm to GUI debugger
        SMGUIDebugger.createMM(sm);
        sm.init();


    }

    private static SMCompositeState buildControl(SMConcurrentState cs) {
        SMCompositeState control = cs.addCompositeState("control");

        SMState a = control.addSimpleState("a");

        SMState b = control.addSimpleState("b");

        SMState c = control.addSimpleState("c");

        control.addInitialState(a);

        a.addTransitionsFromMany(T.A, null, a, b, c);
        b.addTransitionsFromMany(T.B, null, a, b, c);
        c.addTransitionsFromMany(T.C, null, a, b, c);

        a.onEntryDo(x -> control.getUserData().setString("s", "a"));
        b.onEntryDo(x -> control.getUserData().setString("s", "b"));
        c.onEntryDo(x -> control.getUserData().setString("s", "c"));


        return control;
    }


}
