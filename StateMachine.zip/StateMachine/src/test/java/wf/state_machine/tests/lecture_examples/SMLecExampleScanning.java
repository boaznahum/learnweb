package wf.state_machine.tests.lecture_examples;

import wf.state_machine.SMCompositeState;
import wf.state_machine.SMConcurrentState;
import wf.state_machine.SMState;
import wf.state_machine.SMUTrigger;
import wf.state_machine.StateMachine;
import wf.state_machine.smlogger.guilogger.SMGUIDebugger;

import java.util.concurrent.TimeUnit;

/**
 * @author Boaz Nahum
 */

public class SMLecExampleScanning {

    private SMLecExampleScanning() {
    }

    public static void main(String[] args) {


        // Create the state machine
        StateMachine sm = StateMachine.createStateMachine("Scanning");

        // Create and define the legal set of triggers
        SMUTrigger reset = SMUTrigger.create("reset");
        SMUTrigger scan = SMUTrigger.create("scan");
        SMUTrigger suc = SMUTrigger.create("scan-suc");
        SMUTrigger failed = SMUTrigger.create("scan-failed");
        SMUTrigger okToScan = SMUTrigger.create("ok");
        SMUTrigger notOK = SMUTrigger.create("notOk");

        sm.defineTriggers(reset, scan, suc, failed, okToScan, notOK);

        // Get top level state, for which we are adding states.
        SMCompositeState tl = sm.getTopLevel();

        SMConcurrentState cs = tl.addConcurrentState("");

        tl.addInitialState(cs);

        SMCompositeState main = cs.addCompositeState("main");

        // Add states
        SMState ready = main.addSimpleState("Ready");
        SMState scanning = main.addSimpleState("Scanning");
        SMState done = main.addSimpleState("Done");
        SMState failure = main.addSimpleState("Failure");

        // set ready to be initial state in top level state
        main.addInitialState(ready);

        ready.addUTransition(scan, scanning);
        scanning.addUTransition(suc, done);
        scanning.addUTransition(failed, failure);

        ready.addTransitionsFromMany(reset, null,
                                     scanning,
                                     done, failure);


        SMCompositeState control = cs.addCompositeState("control");
        SMState ok = control.addSimpleState("OK");
        SMState notOk = control.addSimpleState("NotOk");

        control.addInitialState(ok);
        ok.addUTransition(notOK, notOk);
        notOk.addUTransition(okToScan, ok);

        scanning.betweenEntryExitDo(true, false, suc, failed, null,
                                    (i) -> {

                                          if (!ok.debugIsActive()) {
                                              throw new RuntimeException();
                                          }

                                          try {
                                              i.logUserMsg("Sleeping ...");

                                              for (int k = 1; k < 5; ++k) {
                                                  TimeUnit.SECONDS.sleep(1);

                                                  if (i.isCanceled()) {
                                                      i.logUserMsg(".. Scanning canceled:" + i);
                                                      return;
                                                  }
                                              }
                                              i.logUserMsg(".. done sleeping");
                                          } catch (InterruptedException ignore) {
                                              i.logUserMsg(".. Scanning interrupted");

                                          }


                                      }
        );


        // Attach the sm to GUI debugger so we can play with
        SMGUIDebugger.createMM(sm);
        sm.init();


    }
}
