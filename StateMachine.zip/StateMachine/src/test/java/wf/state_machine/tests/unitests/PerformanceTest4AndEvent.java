package wf.state_machine.tests.unitests;

import wf.state_machine.SMCompositeState;
import wf.state_machine.SMState;
import wf.state_machine.SMThreadingModel;
import wf.state_machine.SMUTrigger;
import wf.state_machine.tests.infra.SMAbstractTest;
import wf.state_machine.tests.infra.SMSequence;
import wf.state_machine.tests.infra.SMTestRunner;


/**
 *
 * e1 = e1x * e1y * e1z
 * e2 = e2x * e2y * e2z
 *
 *  * ---------------         --------------
 * |             | --E1--> |            |
 * |     A       |         |     B      |
 * |             | <-E2--- |            |
 * ---------------         --------------

 *
 * @author Boaz Nahum
 * @version WI VX.6, V12.0X, ADC V0.95
 */

public class PerformanceTest4AndEvent extends SMAbstractTest {

    private enum MyEvents implements SMUTrigger {

        E1,
        E1x,
        E1y,
        E1z,
        E2,
        E2x,
        E2y,
        E2z;

        @Override
        public String getName() {
            return super.name();
        }

    }


    private PerformanceTest4AndEvent(SMThreadingModel tm) {
        super("PerformanceTest4AndEvent", tm);

        sm.defineTriggers(MyEvents.class);

        SMCompositeState tl = sm.getTopLevel();

        tl.defineAndTrigger(MyEvents.E1, MyEvents.E1x, MyEvents.E1y, MyEvents.E1z);
        tl.defineAndTrigger(MyEvents.E2, MyEvents.E2x, MyEvents.E2y, MyEvents.E2z);

        final SMState a = tl.addSimpleState("A");
        final SMState b = tl.addSimpleState("B");

        tl.addInitialState().addTransition(a);


        a.addUTransition(MyEvents.E1, b);
        b.addUTransition(MyEvents.E2, a);
    }

    public static void main(String[] args) {
        //for (SMThreadingModel tm : SMThreadingModel.values()) {
            runTests(SMThreadingModel.Caller);
        //}

        waitForAllMachinesReleased();
    }

    private static void runTests(SMThreadingModel tm) {
        SMAbstractTest t = new PerformanceTest4AndEvent(tm);

        SMSequence one = SMSequence.once(MyEvents.E1x, MyEvents.E1y, MyEvents.E1z,
                                         MyEvents.E2x, MyEvents.E2y, MyEvents.E2z);



        SMSequence randomMany = SMSequence.nOrMoreSeq(1000000, one);

        SMTestRunner.performanceTest(t, randomMany);

    }


}
