package wf.state_machine.tests.unitests;

import org.testng.annotations.Test;

/**
 * @author Boaz Nahum
 */

public class RunTests {

    @Test
    public void test0() {

        Test0.main(new String[]{});

    }

}
