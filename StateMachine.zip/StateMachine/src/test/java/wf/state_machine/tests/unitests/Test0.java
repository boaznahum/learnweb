package wf.state_machine.tests.unitests;

import wf.state_machine.SMCompositeState;
import wf.state_machine.SMState;
import wf.state_machine.SMThreadingModel;
import wf.state_machine.tests.infra.SMAbstractTest;
import wf.state_machine.tests.infra.SMExpectedGroup;
import wf.state_machine.tests.infra.SMExpectedPatternGenerator;
import wf.state_machine.tests.infra.SMPatternTest;
import wf.state_machine.tests.infra.SMSequence;
import wf.state_machine.tests.infra.SMTestRunner;

import static wf.state_machine.tests.infra.SMTestsCommonTriggers.E1;
import static wf.state_machine.tests.infra.SMTestsCommonTriggers.E2;
import static wf.state_machine.tests.infra.SMExpectedPatternGenerator.Many.M_EXACTLY_ONCE;
import static wf.state_machine.tests.infra.SMExpectedPatternGenerator.Many.M_ZERO_OR_MORE;

/**
 * ---------------         --------------
 * |             | --E1--> |            |
 * |     A       |         |     B      |
 * |             | <-E2--- |            |
 * ---------------         --------------
 *
 * @author Boaz Nahum
 * @version WI VX.6, V12.0X, ADC V0.95
 */

public class Test0 extends SMAbstractTest {

    private Test0(SMThreadingModel tm) {
        super("Test0", tm);

        sm.defineTriggers(E1, E2);

        SMCompositeState tl = sm.getTopLevel();

        final SMState a = tl.addSimpleState("A");
        final SMState b = tl.addSimpleState("B");

        tl.addInitialState().addTransition(a);


        a.addUTransition(E1, b);
        b.addUTransition(E2, a);


        patternWriter.addPatternWriter(a, b);


    }

    private SMPatternTest buildT1() {

        SMPatternTest t = new SMPatternTest(this);
        SMExpectedPatternGenerator expected = t.expected();

        final SMState a = (SMState)sm.getTopLevel().getState("A");
        final SMState b = (SMState)sm.getTopLevel().getState("B");

        // we assume at least one entry to A
        expected.reset();
        expected.addStateEntry(a, true, M_EXACTLY_ONCE);


        // first try complete  A--B--A cycle
        SMExpectedGroup group = expected.beginGrouping(M_ZERO_OR_MORE);
        group.addStateExitEntry(a, b, true, null);
        group.addStateExitEntry(b, a, true, null);
        group.end();

        // otherwise A--B
        group = expected.beginGrouping(M_ZERO_OR_MORE);
        group.addStateExitEntry(a, b, true, null);
        group.end();

        return t;
    }

    public static void main(String[] args) {
        for (SMThreadingModel tm : SMThreadingModel.values()) {
            runTests(tm);
        }

        waitForAllMachinesReleased();
    }

    private static void runTests(SMThreadingModel tm) {
        Test0 t = new Test0(tm);

        SMPatternTest t1 = t.buildT1();

        SMSequence one = SMSequence.once(E1, E2);

        new SMTestRunner("Test0:1", t1).runTest(true,
                                               SMSequence.partialSeq(one));

        new SMTestRunner("Test0:2", t1).runTest(true,
                                               one);

        new SMTestRunner("Test0:3", t1).runTest(true,
                                               SMSequence.nOrMoreSeq(2, one),
                                               SMSequence.partial(E1, E2));
    }
}
