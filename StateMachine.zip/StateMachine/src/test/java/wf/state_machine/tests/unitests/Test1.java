package wf.state_machine.tests.unitests;

import wf.state_machine.SMCompositeState;
import wf.state_machine.SMState;
import wf.state_machine.SMThreadingModel;
import wf.state_machine.tests.infra.SMAbstractTest;
import wf.state_machine.tests.infra.SMExpectedGroup;
import wf.state_machine.tests.infra.SMExpectedPatternGenerator;
import wf.state_machine.tests.infra.SMPatternTest;
import wf.state_machine.tests.infra.SMSequence;
import wf.state_machine.tests.infra.SMTestRunner;
import static wf.state_machine.tests.infra.SMTestsCommonTriggers.E1;
import static wf.state_machine.tests.infra.SMTestsCommonTriggers.E2;
import static wf.state_machine.tests.infra.SMTestsCommonTriggers.E3;
import static wf.state_machine.tests.infra.SMExpectedPatternGenerator.Many.*;

/**
 * <pre>
 *                           -------------------------------
 *                           | B                           |
 *                           |   -----------------------   |
 *                           |   |C                    |   |
 *   ---------------         |   |       -----------   |   |
 *   |      A      |----E1-------------->|   D     |   |   |
 *   ---------------         |   |       -----------   |   |
 *          ^                |   ------------ | --------   |
 *          |                ---------------- | ------------
 *          |                                 |
 *          E3                                E2
 *          |                                 |
 *          |                                 V
 *          |                            ----------
 *          -----------------------------|   E    |
 *                                       ----------
 * </pre>
 * *
 *
 * @author Boaz Nahum
 * @version WI VX.6, V12.0X, ADC V0.95
 */

public class Test1 extends SMAbstractTest {

    private final SMState a;
    private final SMCompositeState b;
    private final SMCompositeState c;
    private final SMState d;
    private final SMState e;

    private Test1(SMThreadingModel tm) {
        super("Test1", tm);

        sm.defineTriggers(E1, E2, E3);

        SMCompositeState tl = sm.getTopLevel();

        a = tl.addSimpleState("A");
        b = tl.addCompositeState("B");
        c = b.addCompositeState("C");
        d = c.addSimpleState("D");
        e = tl.addSimpleState("E");


        tl.addInitialState().addTransition(a);


        a.addUTransition(E1, d);
        d.addUTransition(E2, e);
        e.addUTransition(E3, a);


        patternWriter.addPatternWriter(a, b, c, d, e);


    }

    private SMPatternTest buildT1() {

        SMPatternTest t = new SMPatternTest(this);
        SMExpectedPatternGenerator expected = t.expected();


        // we assume at least one entry to A
        expected.reset();

        expected.addStateEntry(a, true, M_EXACTLY_ONCE);

        // we only test complete cycle A-->D-->E-->A
        SMExpectedGroup group = expected.beginGrouping(M_ZERO_OR_MORE);
        group.addStateExit(a, true, null);
        group.addStateEntry(b, false, null);
        group.addStateEntry(c, false, null);
        group.addStateEntry(d, true, null);
        group.addStateBegin(c);
        group.addStateBegin(b);

        group.addStateExit(d, true, null);
        group.addStateExit(c, true, null);
        group.addStateExit(b, true, null);

        group.addStateEntry(e, true, null);
        group.addStateExitEntry(e, a, true, null);

        group.end();

        return t;

    }

    public static void main(String[] args) {

        //setThreadingModel(SMThreadingModel.SingleThread);

        for (SMThreadingModel tm : SMThreadingModel.values()) {

            Test1 t = new Test1(tm);

            SMPatternTest t1 = t.buildT1();

            SMSequence one = SMSequence.once(E1, E2, E3);

            // Test 1
            SMTestRunner tr1 = new SMTestRunner("Test1:1", t1);
            tr1.runTest(true,
                        one);


            // Test 2
            //SMTestRunner.runTest(t,
            //                     true, false,
            //                     SMSequence.nOrMoreSeq(2, one));

            // Test 3
            for (int i = 0; i < 10; ++i) {
                SMTestRunner tr3 = new SMTestRunner("Test1:3:" + i, t1);
                boolean test3Long = true;
                tr3.setVerbose(!test3Long);
                tr3.run(false,
                        SMSequence.randomSeq(test3Long, one));

                tr3.finishTest(true,
                               one);
            }
        }

        waitForAllMachinesReleased();

    }
}