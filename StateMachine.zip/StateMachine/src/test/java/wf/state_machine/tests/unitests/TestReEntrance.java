package wf.state_machine.tests.unitests;

import wf.state_machine.SMCompositeState;
import wf.state_machine.SMState;
import wf.state_machine.SMThreadingModel;
import wf.state_machine.SMTransition;
import wf.state_machine.StateMachine;
import wf.state_machine.tests.infra.SMAbstractTest;
import wf.state_machine.tests.infra.SMExpectedGroup;
import wf.state_machine.tests.infra.SMExpectedPatternGenerator;
import wf.state_machine.tests.infra.SMPatternTest;
import wf.state_machine.tests.infra.SMSequence;
import wf.state_machine.tests.infra.SMTestRunner;

import java.lang.ref.WeakReference;

import static wf.state_machine.tests.infra.SMExpectedPatternGenerator.Many.M_EXACTLY_ONCE;
import static wf.state_machine.tests.infra.SMExpectedPatternGenerator.Many.M_ONCE_OR_MORE;
import static wf.state_machine.tests.infra.SMTestsCommonTriggers.E1;
import static wf.state_machine.tests.infra.SMTestsCommonTriggers.E2;

/**
 * This test check that we never reach state C because the transition from A to B call init()
 * <p/>
 * ---------------              --------------          --------------
 * |             | --E1/init--> |            |  --E2--> |            |
 * |     A       |              |     B      |          |     C      |
 * |             |              |            |          |            |
 * ---------------              --------------          --------------
 *
 * @author Boaz Nahum
 * @version WI VX.6, V12.0X, ADC V0.95
 */

public class TestReEntrance extends SMAbstractTest {

    private TestReEntrance(SMThreadingModel tm) {
        super("InitReEntranceTest", tm);

        sm.defineTriggers(E1, E2);

        SMCompositeState tl = sm.getTopLevel();

        final SMState a = tl.addSimpleState("A");
        final SMState b = tl.addSimpleState("B");
        final SMState c = tl.addSimpleState("C");

        tl.addInitialState().addTransition(a);


        final SMTransition a2b = a.addUTransition(E1, b);
        b.addUTransition(E2, c);

        a2b.onDo((info) -> sm.init());


        patternWriter.addPatternWriter(a, b, c);


    }

    private SMPatternTest buildT1() {
        SMPatternTest t = new SMPatternTest(this);
        SMExpectedPatternGenerator expected = t.expected();


        final SMState a = (SMState)sm.getTopLevel().getState("A");
        final SMState b = (SMState)sm.getTopLevel().getState("B");

        expected.reset();
        // first init cause entry to state A
        expected.addStateEntry(a, true, M_EXACTLY_ONCE);


        // Each E1 event cause:
        // --- Begin of step E1 ----
        //  End(A)
        //  Exit(A)
        //  Enter(B)
        //  Begin(B)
        //  trigger init()
        // --- End of step
        //
        // --- Begin of step init()
        // Enter(A)
        // Begin(A)

        SMExpectedGroup group = expected.beginGrouping(M_ONCE_OR_MORE);
        group.addStateExitEntry(a, b, true, null);
        // we don't exit B !!! 
        group.addStateEntry(a, true, null);
        group.end();

        return t;


    }

    public static void main(String[] args) {

        for (SMThreadingModel tm : SMThreadingModel.values()) {
            runTests(tm);
        }

        waitForAllMachinesReleased();
    }

    private static WeakReference<StateMachine> runTests(SMThreadingModel tm) {
        WeakReference<StateMachine> smRef;

        {
            TestReEntrance t = new TestReEntrance(tm);

            smRef = new WeakReference<>(t.getSM());

            SMPatternTest t1 = t.buildT1();

            SMSequence one = SMSequence.once(E1, E2);

            new SMTestRunner("InitReEntranceTest:1", t1).runTest(true,
                                                                one);

            new SMTestRunner("InitReEntranceTest:2", t1).runTest(true,
                                                                SMSequence.nOrMoreSeq(5, one),
                                                                SMSequence.partialSeq(one));
        }
        return smRef;
    }
}